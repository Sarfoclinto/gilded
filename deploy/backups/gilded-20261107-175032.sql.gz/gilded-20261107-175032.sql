--
-- PostgreSQL database dump
--

\restrict toQnRXmSx9vQRgV771LxnkYizUalTMGs8gMTAYVS6dfbM2FCwOP4O8xEFmssEAV

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: gold; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA gold;


--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: apply_payment(uuid, uuid, uuid, timestamp with time zone, uuid, text, jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.apply_payment(p_tx uuid, p_branch uuid, p_day uuid, p_at timestamp with time zone, p_customer uuid, p_ref text, p jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant();
  v_user uuid := gold.require_actor();
  v_method text := p->>'method';
  v_amount numeric := (p->>'amount')::numeric;
  v_pay uuid := gen_random_uuid();
  v_debt uuid; v_repay uuid; d record; v_payer uuid;
begin
  if v_amount is null or v_amount <= 0 or v_amount <> trunc(v_amount) then
    perform gold.fail(422, 'VALIDATION_FAILED', 'Each part of the payment must be a whole number of cedis above zero.');
  end if;

  if v_method = 'cash' then
    if gold.lines_total(p->'lines') <> v_amount then perform gold.fail(422, 'PAYOUT_MISMATCH', 'The notes do not add up to the cash amount.'); end if;
    insert into gold.transaction_payments (id, tenant_id, transaction_id, method, amount, recorded_by) values (v_pay, v_tenant, p_tx, 'cash', v_amount, v_user);
    perform gold.post_cash(p_branch, p_day, p_at, p->'lines', -1, 'transaction_payout', p_tx, 'Paid for ' || p_ref);

  elsif v_method = 'mobile_money' then
    v_payer := nullif(p->>'paidByBranchId', '')::uuid;
    if v_payer is null then perform gold.fail(422, 'VALIDATION_FAILED', 'Say which branch sends the mobile money.'); end if;
    perform 1 from gold.branches where id = v_payer and is_active;
    if not found then perform gold.fail(404, 'NOT_FOUND', 'The sending branch was not found.'); end if;
    insert into gold.transaction_payments (id, tenant_id, transaction_id, method, amount, paid_by_branch_id, external_ref, status, recorded_by, note)
    values (v_pay, v_tenant, p_tx, 'mobile_money', v_amount, v_payer, nullif(trim(p->>'externalRef'), ''),
            coalesce(nullif(p->>'status', ''), 'pending'), v_user, nullif(trim(p->>'note'), ''));

  elsif v_method = 'owed' then
    if p_customer is null then
      perform gold.fail(422, 'CUSTOMER_REQUIRED', 'A name and phone number are needed when the branch will owe the customer.');
    end if;
    if exists (select 1 from gold.debts where source_transaction_id = p_tx and direction = 'payable') then
      perform gold.fail(409, 'ALREADY_OWED_RECORDED', 'An owed amount is already recorded for this purchase.');
    end if;
    v_debt := gen_random_uuid();
    insert into gold.debts (id, tenant_id, branch_id, customer_id, party_name, party_type, principal, reason, issued_at, issued_by, due_date,
                            direction, source_transaction_id)
    select v_debt, v_tenant, p_branch, p_customer, c.name, 'customer', v_amount, 'Still owed for gold bought (' || p_ref || ')', p_at, v_user,
           nullif(p->>'dueDate', '')::date, 'payable', p_tx
    from gold.customers c where c.id = p_customer;
    insert into gold.transaction_payments (id, tenant_id, transaction_id, method, amount, debt_id, recorded_by, note)
    values (v_pay, v_tenant, p_tx, 'owed', v_amount, v_debt, v_user, nullif(trim(p->>'note'), ''));
    perform gold.post_value('payable', p_branch, p_day, p_at, v_amount, 'payable_issued', v_debt, 'Owed to the customer for ' || p_ref);

  elsif v_method = 'debt_offset' then
    v_debt := nullif(p->>'debtId', '')::uuid;
    perform 1 from gold.debts where id = v_debt for update;
    select * into d from gold.v_debts_outstanding where id = v_debt;
    if not found then perform gold.fail(404, 'NOT_FOUND', 'Debt was not found.'); end if;
    if d.direction <> 'receivable' or d.status <> 'open' then perform gold.fail(409, 'DEBT_CLOSED', 'That debt is not open.'); end if;
    if d.branch_id <> p_branch then perform gold.fail(422, 'VALIDATION_FAILED', 'The debt belongs to another branch.'); end if;
    if p_customer is null or d.customer_id is distinct from p_customer then
      perform gold.fail(422, 'DEBT_NOT_CUSTOMERS', 'That debt is not this customer''s. Check the name and phone.');
    end if;
    if v_amount > d.outstanding then perform gold.fail(422, 'OVERPAYMENT', 'That is more than the customer owes (' || gold.ts(d.outstanding) || ').'); end if;
    v_repay := gen_random_uuid();
    insert into gold.debt_repayments (id, tenant_id, debt_id, amount, received_at, received_by, method, source_transaction_id, note)
    values (v_repay, v_tenant, v_debt, v_amount, p_at, v_user, 'gold', p_tx, 'Settled with gold ' || p_ref);
    insert into gold.transaction_payments (id, tenant_id, transaction_id, method, amount, debt_id, recorded_by)
    values (v_pay, v_tenant, p_tx, 'debt_offset', v_amount, v_debt, v_user);
    perform gold.post_value('debt', p_branch, p_day, p_at, -v_amount, 'debt_repayment', v_repay, 'Settled with gold ' || p_ref);
    if v_amount = d.outstanding then update gold.debts set status = 'settled', closed_at = p_at, closed_by = v_user where id = v_debt; end if;
  else
    perform gold.fail(422, 'VALIDATION_FAILED', 'Unknown payment method.');
  end if;
end $$;


--
-- Name: approve_margin(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.approve_margin(p_branch uuid) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare v_user uuid := gold.require_actor(); l gold.branch_prices;
begin
  select * into l from gold.branch_prices where branch_id = p_branch order by effective_from desc, created_at desc limit 1;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'No price has been set for this branch.'); end if;
  if l.status = 'provisional' then
    insert into gold.branch_prices (tenant_id, branch_id, snapshot_id, margin, status, set_by, approved_by, approved_at, effective_from, created_at)
    values (l.tenant_id, l.branch_id, l.snapshot_id, l.margin, 'approved', l.set_by, v_user, now(), clock_timestamp(), clock_timestamp());
  end if;
  return gold.current_price(p_branch);
end $$;


--
-- Name: audit(text, text, text, jsonb, jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.audit(p_action text, p_entity_type text, p_entity_id text, p_before jsonb, p_after jsonb) RETURNS void
    LANGUAGE sql
    AS $$
  insert into gold.audit_events (tenant_id, actor_user_id, action, entity_type, entity_id, before, after)
  values (gold.current_tenant(), gold.current_actor(), p_action, p_entity_type, p_entity_id, p_before, p_after)
$$;


--
-- Name: audit_search_json(uuid[], jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.audit_search_json(p_scope uuid[], p_f jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare
  v_q text := nullif(btrim(coalesce(p_f->>'q', '')), '');
  v_cat text := nullif(p_f->>'category', '');
  v_act text := nullif(p_f->>'action', '');
  v_actor uuid := nullif(p_f->>'actorId', '')::uuid;
  v_branch uuid := nullif(p_f->>'branchId', '')::uuid;
  v_from timestamptz := nullif(p_f->>'from', '')::timestamptz;
  v_to timestamptz := nullif(p_f->>'to', '')::timestamptz;
  v_min numeric := nullif(p_f->>'minAmount', '')::numeric;
  v_sort text := coalesce(nullif(p_f->>'sort', ''), 'newest');
  v_size int := least(greatest(coalesce(nullif(p_f->>'size', '')::int, 25), 1), 100);
  v_page int := greatest(coalesce(nullif(p_f->>'page', '')::int, 1), 1);
  v_total int; v_items jsonb; v_cats jsonb; v_actors jsonb;
begin
  if v_branch is not null and p_scope is not null and not (v_branch = any(p_scope)) then
    perform gold.fail(403, 'FORBIDDEN', 'That branch is not one of yours.');
  end if;

  with base as materialized (
    select f.uid, f.at, f.actor_id, u.display_name as actor_name, f.branch_id, b.name as branch_name, f.category, f.action,
           f.entity_type, f.entity_id, f.summary, f.amount, f.detail
      from gold.activity_feed f
      left join gold.users u on u.id = f.actor_id
      left join gold.branches b on b.id = f.branch_id
     where f.at is not null
       and (p_scope is null or f.branch_id = any(p_scope))
       and (v_branch is null or f.branch_id = v_branch)
       and (v_actor is null or f.actor_id = v_actor)
       and (v_from is null or f.at >= v_from)
       and (v_to is null or f.at < v_to)
       and (v_min is null or coalesce(f.amount, 0) >= v_min)
       and (v_q is null or f.summary ilike '%' || v_q || '%' or coalesce(u.display_name, '') ilike '%' || v_q || '%'
            or coalesce(b.name, '') ilike '%' || v_q || '%' or f.detail::text ilike '%' || v_q || '%')
  ), filt as (
    select * from base where (v_cat is null or category = v_cat) and (v_act is null or action = v_act)
  ), page as (
    select * from filt
     order by case v_sort when 'amount' then coalesce(amount, -1) when 'oldest' then -extract(epoch from at) else extract(epoch from at) end desc,
              at desc, uid
     offset (v_page - 1) * v_size limit v_size
  )
  select (select count(*) from filt),
         -- Counts for the filter chips ignore the category and action filters themselves, so choosing one does not hide the others.
         (select coalesce(jsonb_object_agg(category, n), '{}'::jsonb) from (select category, count(*) n from base group by category) c),
         (select coalesce(jsonb_agg(jsonb_build_object('id', actor_id, 'name', actor_name, 'count', n) order by n desc, actor_name), '[]'::jsonb)
            from (select actor_id, actor_name, count(*) n from base where actor_id is not null group by actor_id, actor_name order by n desc limit 50) a),
         (select coalesce(jsonb_agg(jsonb_build_object(
                  'id', uid, 'at', gold.iso(at), 'actor', case when actor_id is null then null else jsonb_build_object('id', actor_id, 'displayName', actor_name) end,
                  'branch', case when branch_id is null then null else jsonb_build_object('id', branch_id, 'name', branch_name) end,
                  'category', category, 'action', action, 'entityType', entity_type, 'entityId', entity_id, 'summary', summary,
                  'amount', gold.ts(amount), 'detail', detail)
                order by case v_sort when 'amount' then coalesce(amount, -1) when 'oldest' then -extract(epoch from at) else extract(epoch from at) end desc, at desc, uid), '[]'::jsonb)
            from page)
    into v_total, v_cats, v_actors, v_items;

  return jsonb_build_object('asOf', gold.iso(now()), 'total', v_total, 'page', v_page, 'size', v_size, 'items', v_items, 'categories', v_cats, 'actors', v_actors);
end $$;


--
-- Name: branch_admin_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.branch_admin_json(p_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object('id', b.id, 'name', b.name, 'code', b.code, 'isMain', b.is_main, 'timezone', b.timezone, 'isActive', b.is_active,
                            'dayOpen', exists (select 1 from gold.business_days d where d.branch_id = b.id and d.status = 'open'))
  from gold.branches b where b.id = p_id
$$;


--
-- Name: branch_balance(uuid, bigint); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.branch_balance(p_branch uuid, p_upto_seq bigint DEFAULT NULL::bigint) RETURNS TABLE(cash_value numeric, cash_lines jsonb, goods_top numeric, goods_down numeric, goods_value numeric, debt_value numeric, payable_value numeric, custody_top numeric)
    LANGUAGE sql STABLE
    AS $$
  with e as (
    select * from gold.ledger_entries
    where branch_id = p_branch and (p_upto_seq is null or seq <= p_upto_seq)
  ), notes as (
    select denomination, sum(delta_count) as n from e where asset = 'cash' group by denomination having sum(delta_count) <> 0
  )
  select
    coalesce((select sum(delta_value) from e where asset = 'cash'), 0),
    coalesce((select jsonb_object_agg(denomination::text, n) from notes), '{}'::jsonb),
    coalesce((select sum(delta_top)   from e where asset = 'goods'), 0),
    coalesce((select sum(delta_down)  from e where asset = 'goods'), 0),
    coalesce((select sum(delta_value) from e where asset = 'goods'), 0),
    coalesce((select sum(delta_value) from e where asset = 'debt'), 0),
    coalesce((select sum(delta_value) from e where asset = 'payable'), 0),
    coalesce((select sum(delta_top)   from e where asset = 'custody'), 0)
$$;


--
-- Name: branch_overview_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.branch_overview_json(p_branch uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare
  b gold.branches; bal record; v_now timestamptz := now(); v_today date;
  v_workers jsonb; v_today_j jsonb; v_open jsonb; v_attention jsonb; v_days jsonb; v_recent jsonb; v_debts jsonb;
begin
  select * into b from gold.branches where id = p_branch;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Branch was not found.'); end if;
  select * into bal from gold.branch_balance(p_branch);
  v_today := (v_now at time zone b.timezone)::date;

  select coalesce(jsonb_agg(jsonb_build_object(
      'id', u.id, 'name', u.display_name, 'username', u.username::text, 'phone', u.phone,
      'role', jsonb_build_object('key', r.key, 'name', r.name), 'isPrimary', ub.is_primary,
      'lastLoginAt', case when u.last_login_at is null then null else gold.iso(u.last_login_at) end)
    order by r.name, lower(u.display_name)), '[]'::jsonb)
  into v_workers
  from gold.user_branches ub join gold.users u on u.id = ub.user_id and u.is_active
  join gold.roles r on r.id = u.role_id and r.tenant_id = u.tenant_id
  where ub.branch_id = p_branch;

  select jsonb_build_object('count', count(*) filter (where t.status <> 'void'), 'paid', gold.ts(coalesce(sum(t.payable) filter (where t.status <> 'void'), 0)),
                            'voided', count(*) filter (where t.status = 'void'))
  into v_today_j
  from gold.transactions t where t.branch_id = p_branch and (t.captured_at at time zone b.timezone)::date = v_today;

  select jsonb_build_object('id', d.id, 'businessDate', d.business_date, 'openedAt', gold.iso(d.opened_at), 'openedBy', gold.person_json(d.opened_by))
  into v_open from gold.business_days d where d.branch_id = p_branch and d.status = 'open';

  select jsonb_build_object(
    'signoffPending', (select count(*) from gold.business_days d where d.branch_id = p_branch and d.signoff_status = 'pending'),
    'openDifferences', (select count(*) from gold.discrepancies x where x.branch_id = p_branch and x.status in ('open', 'under_review')),
    'transfersComing', (select count(*) from gold.transfers x where x.destination_branch_id = p_branch and x.status = 'released'),
    'transfersGoing', (select count(*) from gold.transfers x where x.origin_branch_id = p_branch and x.status = 'released'),
    'moneyWaiting', (select count(*) from gold.transaction_payments p join gold.transactions t on t.id = p.transaction_id
                     where p.status = 'pending' and t.branch_id = p_branch),
    'moneyToSend', (select count(*) from gold.transaction_payments p where p.status = 'pending' and p.paid_by_branch_id = p_branch))
  into v_attention;

  select jsonb_build_object('owedToUs', gold.ts(coalesce(sum(outstanding) filter (where direction = 'receivable'), 0)),
                            'weOwe', gold.ts(coalesce(sum(outstanding) filter (where direction = 'payable'), 0)),
                            'overdue', count(*) filter (where direction = 'receivable' and due_date < v_today))
  into v_debts from gold.v_debts_outstanding where branch_id = p_branch and status = 'open' and outstanding > 0;

  select coalesce(jsonb_agg(jsonb_build_object(
      'id', d.id, 'date', d.business_date, 'status', d.status, 'signoff', d.signoff_status,
      'differences', (select count(*) from gold.day_reconciliations r where r.business_day_id = d.id and r.phase = 'closing' and r.difference <> 0),
      'cashDifference', gold.ts(coalesce((select sum(r.difference) from gold.day_reconciliations r where r.business_day_id = d.id and r.phase = 'closing' and r.asset = 'cash'), 0)))
    order by d.business_date desc), '[]'::jsonb)
  into v_days from (select * from gold.business_days x where x.branch_id = p_branch order by x.business_date desc limit 6) d;

  select coalesce(jsonb_agg(jsonb_build_object('id', t.id, 'reference', t.reference, 'customerName', t.customer_name, 'payable', gold.ts(t.payable),
                                               'status', t.status, 'capturedAt', gold.iso(t.captured_at)) order by t.captured_at desc), '[]'::jsonb)
  into v_recent from (select * from gold.transactions x where x.branch_id = p_branch order by x.captured_at desc limit 5) t;

  return jsonb_build_object(
    'asOf', gold.iso(v_now),
    'branch', gold.branch_admin_json(p_branch),
    'workers', v_workers,
    'snapshot', jsonb_build_object('cash', gold.ts(bal.cash_value), 'goodsTop', gold.ts(bal.goods_top), 'goodsDown', gold.ts(bal.goods_down),
                                    'goodsValue', gold.ts(bal.goods_value), 'debt', gold.ts(bal.debt_value), 'payable', gold.ts(bal.payable_value),
                                    'custodyTop', gold.ts(bal.custody_top)),
    'today', v_today_j, 'openDay', v_open, 'attention', v_attention, 'debts', v_debts, 'recentDays', v_days, 'recent', v_recent);
end $$;


--
-- Name: branch_timeline_json(uuid, timestamp with time zone, timestamp with time zone, text, bigint, integer); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.branch_timeline_json(p_branch uuid, p_from timestamp with time zone, p_to timestamp with time zone, p_asset text, p_before bigint, p_limit integer DEFAULT 100) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare v_limit int := least(greatest(coalesce(p_limit, 100), 1), 300); v_rows jsonb; v_n int;
begin
  if p_asset is not null and p_asset not in ('cash', 'goods', 'debt', 'payable') then
    perform gold.fail(422, 'VALIDATION_FAILED', 'asset must be cash, goods, debt or payable.');
  end if;
  select coalesce(jsonb_agg(j order by (j->>'seq')::bigint desc), '[]'::jsonb), count(*) into v_rows, v_n
  from (select jsonb_build_object(
          'seq', t.seq, 'occurredAt', gold.iso(t.occurred_at), 'recordedAt', gold.iso(t.recorded_at),
          'recordedBy', case when t.recorded_by is null then null else gold.person_json(t.recorded_by) end,
          'dayId', t.business_day_id, 'asset', t.asset, 'denomination', t.denomination, 'deltaCount', t.delta_count,
          'deltaTop', gold.ts(t.delta_top), 'deltaDown', gold.ts(t.delta_down), 'deltaValue', gold.ts(t.delta_value),
          'sourceType', t.source_type, 'sourceId', t.source_id, 'memo', t.memo,
          'running', jsonb_build_object('cash', gold.ts(t.running_cash), 'goodsTop', gold.ts(t.running_goods_top), 'goodsDown', gold.ts(t.running_goods_down),
                                        'goodsValue', gold.ts(t.running_goods_value), 'debt', gold.ts(t.running_debt), 'payable', gold.ts(t.running_payable))) j
        from gold.v_branch_timeline t
        where t.branch_id = p_branch
          and (p_from is null or t.occurred_at >= p_from) and (p_to is null or t.occurred_at < p_to)
          and (p_asset is null or t.asset = p_asset)
          and (p_before is null or t.seq < p_before)
        order by t.seq desc limit v_limit) x;
  return jsonb_build_object('entries', v_rows, 'nextBefore', case when v_n = v_limit then (v_rows->(v_n - 1)->>'seq')::bigint else null end);
end $$;


--
-- Name: branches_admin_json(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.branches_admin_json() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(gold.branch_admin_json(id) order by is_main desc, is_active desc, name), '[]'::jsonb) from gold.branches
$$;


--
-- Name: branches_cash_json(uuid[], uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.branches_cash_json(p_scope uuid[], p_branch uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare v_out jsonb;
begin
  if p_branch is not null and not (p_branch = any (coalesce(p_scope, '{}'))) then
    perform gold.fail(403, 'FORBIDDEN', 'You do not have access to that branch.');
  end if;
  select coalesce(jsonb_agg(jsonb_build_object(
      'branchId', b.id, 'name', b.name, 'isMain', b.is_main,
      'cashValue', gold.ts(bal.cash_value), 'lines', bal.cash_lines,
      'day', coalesce(d.status, 'none'), 'dayDate', d.business_date,
      'lastEntryAt', case when l.last_at is null then null else gold.iso(l.last_at) end)
    order by b.is_main desc, b.name), '[]'::jsonb)
  into v_out
  from gold.branches b
  cross join lateral gold.branch_balance(b.id) bal
  left join lateral (select x.status, x.business_date from gold.business_days x where x.branch_id = b.id order by x.business_date desc limit 1) d on true
  left join lateral (select max(e.recorded_at) as last_at from gold.ledger_entries e where e.branch_id = b.id and e.asset = 'cash') l on true
  where b.is_active and b.id = any (coalesce(p_scope, '{}')) and (p_branch is null or b.id = p_branch);
  return jsonb_build_object('asOf', gold.iso(now()), 'branches', v_out);
end $$;


--
-- Name: cancel_transfer(uuid, text, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.cancel_transfer(p_id uuid, p_reason text, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare t gold.transfers;
begin
  t := gold.transfer_for(p_id, 'origin', p_scope);
  if t.status <> 'draft' then perform gold.fail(409, 'TRANSFER_LOCKED', 'Only a draft can be cancelled. Once it is released it must be received.'); end if;
  if not gold.has_text(p_reason, 5) then perform gold.fail(422, 'VALIDATION_FAILED', 'Write the reason (at least a few words).'); end if;
  update gold.transfers set status = 'cancelled', cancelled_at = now(), cancelled_by = gold.require_actor(), cancel_reason = trim(p_reason) where id = p_id;
  perform gold.transfer_event(p_id, 'cancelled', jsonb_build_object('reason', trim(p_reason)));
  return gold.transfer_json(p_id);
end $$;


--
-- Name: carry_branch_prices(uuid, uuid, boolean); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.carry_branch_prices(p_snap uuid, p_actor uuid, p_keep_status boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  insert into gold.branch_prices (tenant_id, branch_id, snapshot_id, margin, status, set_by, approved_by, approved_at, effective_from, created_at)
  select b.tenant_id, b.id, p_snap, coalesce(l.margin, 0),
         case when l.id is not null and p_keep_status then l.status else 'provisional' end, p_actor,
         case when l.id is not null and p_keep_status then l.approved_by end,
         case when l.id is not null and p_keep_status then l.approved_at end,
         clock_timestamp(), clock_timestamp()
  from gold.branches b
  left join lateral (select * from gold.branch_prices where branch_id = b.id order by effective_from desc, created_at desc limit 1) l on true
  where b.is_active;
end $$;


--
-- Name: change_my_password(text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.change_my_password(p_hash text) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare v_me uuid := gold.require_actor();
begin
  update gold.users set password_hash = p_hash, must_change_password = false where id = v_me;
  perform gold.audit('user.password_changed', 'user', v_me::text, null, null);
end $$;


--
-- Name: check_payment_split(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.check_payment_split() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare paid numeric; due numeric;
begin
  select coalesce(sum(amount) filter (where status <> 'failed'), 0) into paid from gold.transaction_payments where transaction_id = new.transaction_id;
  select payable into due from gold.transactions where id = new.transaction_id;
  if paid <> due then
    raise exception 'the payments (%) must add up to the amount payable (%) for transaction %', paid, due, new.transaction_id
      using errcode = 'check_violation';
  end if;
  return null;
end $$;


--
-- Name: clean_permissions(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.clean_permissions(p jsonb) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
declare v text[]; x text;
begin
  if p is null or jsonb_typeof(p) <> 'array' then perform gold.fail(422, 'VALIDATION_FAILED', 'Choose what this role allows.'); end if;
  select coalesce(array_agg(distinct e), '{}') into v from jsonb_array_elements_text(p) e;
  if cardinality(v) = 0 then perform gold.fail(422, 'VALIDATION_FAILED', 'Choose at least one thing this role allows.'); end if;
  foreach x in array v loop
    if x !~ '^[a-z][a-z0-9-]*:[a-z][a-z0-9-]*$' then perform gold.fail(422, 'VALIDATION_FAILED', format('"%s" is not a permission.', x)); end if;
  end loop;
  return v;
end $_$;


--
-- Name: close_day(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.close_day(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant();
  v_user uuid := gold.require_actor();
  v_id uuid := (p->>'id')::uuid;
  v_day uuid := (p->>'dayId')::uuid;
  v_branch uuid := (p->>'branchId')::uuid;
  v_at timestamptz := least((p->>'capturedAt')::timestamptz, now());
  v_lines jsonb := coalesce(p#>'{declared,cash}', '{}'::jsonb);
  v_ver text := nullif(trim(coalesce(p#>>'{confirmation,version}', '')), '');
  v_txt text := nullif(trim(coalesce(p#>>'{confirmation,text}', '')), '');
  d gold.business_days; bal record; r record;
  v_seq bigint; v_declared numeric; v_detail jsonb := '{}'::jsonb; v_pos jsonb := '{}'::jsonb; v_neg jsonb := '{}'::jsonb;
  v_assets text[] := array['cash','goods_top','goods_down','goods_value','debt','payable','custody_top'];
  v_a text; v_exp numeric; v_act numeric; v_expl text; v_missing text[] := '{}'; v_needs boolean; v_any boolean := false;
  v_goods_memo text[] := '{}'; v_rec uuid;
  d_top numeric; d_down numeric; d_gval numeric; d_debt numeric; d_pay numeric; d_cus numeric;
begin
  if exists (select 1 from gold.business_days where closing_command_id = v_id) then
    return jsonb_build_object('replayed', true, 'data', gold.day_json(v_day));
  end if;
  select * into d from gold.business_days where id = v_day and branch_id = v_branch for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That day was not found.'); end if;
  if d.status <> 'open' then perform gold.fail(409, 'DAY_ALREADY_CLOSED', 'This day is already closed.'); end if;
  if coalesce(p#>>'{confirmation,accepted}', 'false') <> 'true' or v_ver is null or v_txt is null then
    perform gold.fail(422, 'CONFIRMATION_REQUIRED', 'Tick the confirmation that you physically verified everything reported.');
  end if;
  perform 1 from gold.branches where id = v_branch for update;   -- one closing at a time per branch

  select * into bal from gold.branch_balance(v_branch);
  select max(seq) into v_seq from gold.ledger_entries where branch_id = v_branch;

  v_declared := gold.lines_total(v_lines);
  d_top := gold.declared(p, 'goodsTop'); d_down := gold.declared(p, 'goodsDown'); d_gval := gold.declared(p, 'goodsValue');
  d_debt := gold.declared(p, 'debt'); d_pay := gold.declared(p, 'payable'); d_cus := gold.declared(p, 'custodyTop');

  -- cash by note: what to add and what to take away so the ledger matches the count
  for r in
    select coalesce(e.k, c.k) as denom, coalesce(c.n, 0) - coalesce(e.n, 0) as delta
    from (select key::int as k, value::int as n from jsonb_each_text(bal.cash_lines)) e
    full join (select key::int as k, value::int as n from jsonb_each_text(v_lines)) c on c.k = e.k
    where coalesce(c.n, 0) <> coalesce(e.n, 0)
  loop
    v_detail := v_detail || jsonb_build_object(r.denom::text, r.delta);
    if r.delta > 0 then v_pos := v_pos || jsonb_build_object(r.denom::text, r.delta);
    else v_neg := v_neg || jsonb_build_object(r.denom::text, -r.delta); end if;
  end loop;

  -- every figure that differs needs its own written reason
  foreach v_a in array v_assets loop
    v_exp := case v_a when 'cash' then bal.cash_value when 'goods_top' then bal.goods_top when 'goods_down' then bal.goods_down
             when 'goods_value' then bal.goods_value when 'debt' then bal.debt_value when 'payable' then bal.payable_value else bal.custody_top end;
    v_act := case v_a when 'cash' then v_declared when 'goods_top' then d_top when 'goods_down' then d_down
             when 'goods_value' then d_gval when 'debt' then d_debt when 'payable' then d_pay else d_cus end;
    v_needs := case when v_a = 'cash' then v_detail <> '{}'::jsonb else v_act <> v_exp end;
    v_expl := nullif(trim(coalesce(p->'explanations'->>v_a, '')), '');
    if v_needs and (v_expl is null or not gold.has_text(v_expl, 5)) then v_missing := v_missing || v_a; end if;
  end loop;
  if cardinality(v_missing) > 0 then
    perform gold.fail(422, 'EXPLANATION_REQUIRED', 'Write why (at least 5 characters) for: ' || array_to_string(v_missing, ', ') || '.');
  end if;

  -- snapshots: what the books said, and what was reported
  insert into gold.day_balances (tenant_id, business_day_id, kind, cash_lines, cash_value, goods_top, goods_down, goods_value, debt_value,
                                 payable_value, custody_top, ledger_seq, captured_by)
  values (v_tenant, v_day, 'closing_expected', bal.cash_lines, bal.cash_value, bal.goods_top, bal.goods_down, bal.goods_value, bal.debt_value,
          bal.payable_value, bal.custody_top, v_seq, v_user);
  insert into gold.day_balances (tenant_id, business_day_id, kind, cash_lines, cash_value, goods_top, goods_down, goods_value, debt_value,
                                 payable_value, custody_top, captured_by)
  values (v_tenant, v_day, 'closing_declared', v_lines, v_declared, d_top, d_down, d_gval, d_debt, d_pay, d_cus, v_user);

  -- adjustments, so the ledger now agrees with what was reported
  if v_detail <> '{}'::jsonb then
    perform gold.post_cash(v_branch, v_day, v_at, v_pos, 1, 'closing_adjustment', v_day, p->'explanations'->>'cash');
    perform gold.post_cash(v_branch, v_day, v_at, v_neg, -1, 'closing_adjustment', v_day, p->'explanations'->>'cash');
  end if;
  if (d_top, d_down, d_gval) is distinct from (bal.goods_top, bal.goods_down, bal.goods_value) then
    foreach v_a in array array['goods_top','goods_down','goods_value'] loop
      if p->'explanations'->>v_a is not null then v_goods_memo := v_goods_memo || (v_a || ': ' || trim(p->'explanations'->>v_a)); end if;
    end loop;
    perform gold.post_goods(v_branch, v_day, v_at, d_top - bal.goods_top, d_down - bal.goods_down, d_gval - bal.goods_value,
                            'closing_adjustment', v_day, array_to_string(v_goods_memo, '; '));
  end if;
  if d_debt <> bal.debt_value then
    perform gold.post_value('debt', v_branch, v_day, v_at, d_debt - bal.debt_value, 'closing_adjustment', v_day, p->'explanations'->>'debt');
  end if;
  if d_pay <> bal.payable_value then
    perform gold.post_value('payable', v_branch, v_day, v_at, d_pay - bal.payable_value, 'closing_adjustment', v_day, p->'explanations'->>'payable');
  end if;
  if d_cus <> bal.custody_top then
    perform gold.post_custody(v_branch, v_day, v_at, d_cus - bal.custody_top, 'closing_adjustment', v_day, p->'explanations'->>'custody_top');
  end if;

  -- one reconciliation row per figure; a case for review for each real difference
  foreach v_a in array v_assets loop
    v_exp := case v_a when 'cash' then bal.cash_value when 'goods_top' then bal.goods_top when 'goods_down' then bal.goods_down
             when 'goods_value' then bal.goods_value when 'debt' then bal.debt_value when 'payable' then bal.payable_value else bal.custody_top end;
    v_act := case v_a when 'cash' then v_declared when 'goods_top' then d_top when 'goods_down' then d_down
             when 'goods_value' then d_gval when 'debt' then d_debt when 'payable' then d_pay else d_cus end;
    v_needs := case when v_a = 'cash' then v_detail <> '{}'::jsonb else v_act <> v_exp end;
    v_expl := case when v_needs then trim(p->'explanations'->>v_a) else null end;
    v_any := v_any or v_needs;
    insert into gold.day_reconciliations (tenant_id, business_day_id, phase, asset, expected, actual, detail, explanation, explained_by)
    values (v_tenant, v_day, 'closing', v_a, v_exp, v_act, case when v_a = 'cash' and v_needs then v_detail else null end, v_expl,
            case when v_needs then v_user end)
    returning id into v_rec;
    if v_act <> v_exp then
      insert into gold.discrepancies (tenant_id, branch_id, business_day_id, kind, asset, reconciliation_id, expected, actual, difference,
                                      reported_explanation, opened_by)
      values (v_tenant, v_branch, v_day, 'closing_variance', v_a, v_rec, v_exp, v_act, v_act - v_exp, v_expl, v_user);
    end if;
  end loop;

  update gold.business_days
     set status = 'closed', closed_at = greatest(v_at, opened_at), closed_by = v_user, closing_confirmed = true,
         closing_confirmation_version = v_ver, closing_confirmation_text = v_txt, closing_command_id = v_id,
         signoff_status = case when v_any then 'pending' else 'not_required' end
   where id = v_day;

  return jsonb_build_object('replayed', false, 'data', gold.day_json(v_day));
end $$;


--
-- Name: closing_preview(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.closing_preview(p_day uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare d gold.business_days; bal record;
begin
  select * into d from gold.business_days where id = p_day;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That day was not found.'); end if;
  if d.status <> 'open' then perform gold.fail(409, 'DAY_ALREADY_CLOSED', 'This day is already closed.'); end if;
  select * into bal from gold.branch_balance(d.branch_id);
  return jsonb_build_object(
    'dayId', d.id, 'branchId', d.branch_id,
    'expected', jsonb_build_object(
        'cash', jsonb_build_object('lines', bal.cash_lines, 'value', gold.ts(bal.cash_value)),
        'goodsTop', gold.ts(bal.goods_top), 'goodsDown', gold.ts(bal.goods_down), 'goodsValue', gold.ts(bal.goods_value),
        'debt', gold.ts(bal.debt_value), 'payable', gold.ts(bal.payable_value), 'custodyTop', gold.ts(bal.custody_top)),
    'pendingPayments', (select count(*) from gold.transaction_payments p join gold.transactions t on t.id = p.transaction_id
                        where t.branch_id = d.branch_id and p.status = 'pending'),
    'asOf', gold.iso(now()));
end $$;


--
-- Name: collateral_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.collateral_json(p_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'id', h.id, 'branchId', h.branch_id, 'debtId', h.debt_id, 'status', h.status, 'topWeight', gold.ts(h.top_weight),
    'description', h.description, 'receivedAt', gold.iso(h.received_at), 'receivedBy', gold.person_json(h.received_by),
    'customer', jsonb_build_object('id', c.id, 'name', c.name, 'phone', c.phone),
    'debtOutstanding', (select gold.ts(outstanding) from gold.v_debts_outstanding where id = h.debt_id),
    'convertedTransactionId', h.converted_transaction_id, 'closedAt', case when h.closed_at is null then null else gold.iso(h.closed_at) end,
    'closeNote', h.close_note)
  from gold.collateral_holdings h join gold.customers c on c.id = h.customer_id
  where h.id = p_id
$$;


--
-- Name: collateral_list_json(uuid, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.collateral_list_json(p_branch uuid, p_status text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(gold.collateral_json(id) order by received_at desc), '[]'::jsonb)
  from (select id, received_at from gold.collateral_holdings
        where branch_id = p_branch and (p_status is null or status = p_status) order by received_at desc limit 200) x
$$;


--
-- Name: create_branch(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.create_branch(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $_$
declare
  v_id uuid := coalesce((p->>'id')::uuid, gen_random_uuid());
  v_code text := upper(trim(coalesce(p->>'code', '')));
  v_name text := trim(coalesce(p->>'name', ''));
  v_tz text := coalesce(nullif(trim(coalesce(p->>'timezone', '')), ''), 'Africa/Accra');
  v_snap uuid;
begin
  perform gold.require_actor();
  if exists (select 1 from gold.branches where id = v_id) then
    return jsonb_build_object('replayed', true, 'data', gold.branch_admin_json(v_id));
  end if;
  if v_code !~ '^[A-Z0-9]{2,6}$' then perform gold.fail(422, 'VALIDATION_FAILED', 'The branch code must be 2 to 6 letters or digits.'); end if;
  if char_length(v_name) < 2 or char_length(v_name) > 80 then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the branch name.'); end if;
  if not exists (select 1 from pg_timezone_names where name = v_tz) then perform gold.fail(422, 'VALIDATION_FAILED', 'That time zone is not known.'); end if;
  if exists (select 1 from gold.branches where code = v_code) then perform gold.fail(409, 'CODE_TAKEN', 'That branch code is already used.'); end if;
  insert into gold.branches (id, tenant_id, code, name, is_main, timezone) values (v_id, gold.current_tenant(), v_code, v_name, false, v_tz);
  select id into v_snap from gold.price_snapshots order by published_at desc, fetched_at desc limit 1;
  if v_snap is not null then
    insert into gold.branch_prices (tenant_id, branch_id, snapshot_id, margin, status, set_by, effective_from, created_at)
    values (gold.current_tenant(), v_id, v_snap, 0, 'provisional', gold.current_actor(), clock_timestamp(), clock_timestamp());
  end if;
  perform gold.audit('branch.created', 'branch', v_id::text, null, gold.branch_admin_json(v_id));
  return jsonb_build_object('replayed', false, 'data', gold.branch_admin_json(v_id));
end $_$;


--
-- Name: create_customer(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.create_customer(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_id uuid := coalesce((p->>'id')::uuid, gen_random_uuid());
  v_name text := trim(coalesce(p->>'name', ''));
  v_phone text := nullif(regexp_replace(coalesce(p->>'phone', ''), '\s', '', 'g'), '');
begin
  perform gold.require_actor();
  if exists (select 1 from gold.customers where id = v_id) then
    return jsonb_build_object('replayed', true, 'data', gold.customer_detail_json(v_id));
  end if;
  if char_length(v_name) < 2 or char_length(v_name) > 120 then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the customer''s name.'); end if;
  if v_phone is null or char_length(v_phone) < 6 then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the customer''s phone number.'); end if;
  if exists (select 1 from gold.customers where lower(name) = lower(v_name) and phone = v_phone) then
    perform gold.fail(409, 'DUPLICATE_CUSTOMER', 'A customer with this name and phone number already exists.');
  end if;
  insert into gold.customers (id, tenant_id, name, phone, notes, created_by)
  values (v_id, gold.current_tenant(), v_name, v_phone, nullif(trim(coalesce(p->>'notes', '')), ''), gold.current_actor());
  perform gold.audit('customer.created', 'customer', v_id::text, null, gold.customer_detail_json(v_id));
  return jsonb_build_object('replayed', false, 'data', gold.customer_detail_json(v_id));
end $$;


--
-- Name: create_role(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.create_role(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant();
  v_id uuid := (p->>'id')::uuid;
  v_name text := trim(coalesce(p->>'name', ''));
  v_perms text[]; v_key text; v_base text; n int := 1;
begin
  perform gold.require_actor();
  if exists (select 1 from gold.roles where id = v_id) then
    return jsonb_build_object('replayed', true, 'data', gold.role_json((select key from gold.roles where id = v_id)));
  end if;
  if char_length(v_name) < 2 or char_length(v_name) > 40 then perform gold.fail(422, 'VALIDATION_FAILED', 'Give the role a name of 2 to 40 characters.'); end if;
  if exists (select 1 from gold.roles where lower(name) = lower(v_name)) then perform gold.fail(409, 'ROLE_EXISTS', 'A role with that name already exists.'); end if;
  v_perms := gold.clean_permissions(p->'permissions');
  v_base := trim(both '-' from lower(regexp_replace(v_name, '[^a-zA-Z0-9]+', '-', 'g')));
  if v_base = '' then v_base := 'role'; end if;
  v_key := v_base;
  while exists (select 1 from gold.roles where key = v_key) loop n := n + 1; v_key := v_base || '-' || n; end loop;
  insert into gold.roles (id, tenant_id, key, name, is_system, description) values (v_id, v_tenant, v_key, v_name, false, nullif(trim(coalesce(p->>'description', '')), ''));
  insert into gold.role_permissions (tenant_id, role_id, permission) select v_tenant, v_id, x from unnest(v_perms) x;
  perform gold.audit('role.created', 'role', v_key, null, gold.role_json(v_key));
  return jsonb_build_object('replayed', false, 'data', gold.role_json(v_key));
end $$;


--
-- Name: create_town(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.create_town(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare v_id uuid;
begin
  perform gold.require_actor();
  if p is null or not gold.has_text(p->>'name', 2) then perform gold.fail(422, 'VALIDATION_FAILED', 'Write the town name.'); end if;
  v_id := gold.resolve_town(p);
  return (select jsonb_build_object('id', o.id, 'name', o.name, 'uses', (select count(*) from gold.transactions t where t.origin_town_id = o.id)) from gold.origin_towns o where o.id = v_id);
end $$;


--
-- Name: create_transfer(jsonb, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.create_transfer(p jsonb, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant(); v_user uuid := gold.require_actor(); v_id uuid := (p->>'id')::uuid;
  v_origin uuid := (p->>'originBranchId')::uuid; v_dest uuid := (p->>'destinationBranchId')::uuid;
  v_kind text := coalesce(p->>'kind', 'goods'); b gold.branches; v_local date; v_n int; v_ref text; x jsonb; v_item text;
begin
  if exists (select 1 from gold.transfers where id = v_id) then return jsonb_build_object('replayed', true, 'data', gold.transfer_json(v_id)); end if;
  perform gold.in_scope(v_origin, p_scope);
  if v_kind not in ('goods', 'cash') then perform gold.fail(422, 'VALIDATION_FAILED', 'kind must be goods or cash.'); end if;
  if v_origin = v_dest then perform gold.fail(422, 'VALIDATION_FAILED', 'The sending and receiving branch must be different.'); end if;
  perform 1 from gold.branches where id = v_dest and is_active;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'The receiving branch was not found.'); end if;
  select * into b from gold.branches where id = v_origin and is_active;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'The sending branch was not found.'); end if;

  v_local := (now() at time zone b.timezone)::date;
  v_n := gold.next_document_number(v_tenant, 'transfer', v_origin, v_local);
  v_ref := 'TRF-' || b.code || '-' || to_char(v_local, 'YYYYMMDD') || '-' || lpad(v_n::text, 4, '0');
  insert into gold.transfers (id, tenant_id, reference, kind, origin_branch_id, destination_branch_id, purpose, purpose_note, method,
                              expected_arrival_at, created_by)
  values (v_id, v_tenant, v_ref, v_kind, v_origin, v_dest, coalesce(p->>'purpose', 'other'), nullif(trim(coalesce(p->>'purposeNote', '')), ''),
          coalesce(p->>'method', 'other'), nullif(p->>'expectedArrivalAt', '')::timestamptz, v_user);
  perform gold.transfer_event(v_id, 'created', jsonb_build_object('kind', v_kind, 'from', v_origin, 'to', v_dest, 'purpose', p->>'purpose'));
  if v_kind = 'goods' then
    for v_item in select jsonb_array_elements_text(coalesce(p->'itemIds', '[]'::jsonb)) loop perform gold.transfer_add_item(v_id, v_item::uuid); end loop;
  end if;
  if p->'collector' is not null and jsonb_typeof(p->'collector') = 'object' then perform gold.transfer_set_collector_row(v_id, p->'collector'); end if;
  return jsonb_build_object('replayed', false, 'data', gold.transfer_json(v_id));
end $$;


--
-- Name: create_user(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.create_user(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $_$
declare
  v_tenant uuid := gold.current_tenant();
  v_id uuid := (p->>'id')::uuid;
  v_username text := lower(trim(coalesce(p->>'username', '')));
  v_name text := trim(coalesce(p->>'displayName', ''));
  v_role uuid; v_branches uuid[]; o jsonb; i int := 0; b uuid; v_all boolean;
begin
  perform gold.require_actor();
  if exists (select 1 from gold.users where id = v_id) then
    return jsonb_build_object('replayed', true, 'data', gold.user_admin_json(v_id));
  end if;
  if v_username !~ '^[a-z0-9][a-z0-9._-]{2,39}$' then
    perform gold.fail(422, 'VALIDATION_FAILED', 'The username must be 3 to 40 letters, digits, dots, dashes or underscores.');
  end if;
  if char_length(v_name) < 2 or char_length(v_name) > 80 then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the person''s name.'); end if;
  if coalesce(p->>'passwordHash', '') = '' then perform gold.fail(422, 'VALIDATION_FAILED', 'A temporary password is needed.'); end if;
  if exists (select 1 from gold.users where username = v_username::citext) then
    perform gold.fail(409, 'USERNAME_TAKEN', 'That username is already used.');
  end if;
  select id into v_role from gold.roles where key = p->>'roleKey';
  if v_role is null then perform gold.fail(422, 'VALIDATION_FAILED', 'Choose a role.'); end if;
  v_branches := gold.valid_branch_ids(p->'branchIds');

  insert into gold.users (id, tenant_id, username, display_name, email, phone, password_hash, role_id, must_change_password)
  values (v_id, v_tenant, v_username, v_name, nullif(trim(coalesce(p->>'email', '')), ''), nullif(trim(coalesce(p->>'phone', '')), ''),
          p->>'passwordHash', v_role, true);
  foreach b in array v_branches loop
    i := i + 1;
    insert into gold.user_branches (tenant_id, user_id, branch_id, is_primary) values (v_tenant, v_id, b, i = 1);
  end loop;
  for o in select * from jsonb_array_elements(coalesce(p->'overrides', '[]'::jsonb)) loop
    insert into gold.user_permission_overrides (tenant_id, user_id, permission, effect) values (v_tenant, v_id, o->>'permission', o->>'effect')
    on conflict (user_id, permission) do update set effect = excluded.effect;
  end loop;

  select exists (select 1 from gold.effective_permissions(v_id) e where e = 'branches:all') into v_all;
  if cardinality(v_branches) = 0 and not v_all then
    perform gold.fail(422, 'BRANCH_REQUIRED', 'Choose at least one branch for this person.');
  end if;
  perform gold.audit('user.created', 'user', v_id::text, null, gold.user_admin_json(v_id));
  return jsonb_build_object('replayed', false, 'data', gold.user_admin_json(v_id));
end $_$;


--
-- Name: current_actor(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.current_actor() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select nullif(current_setting('app.user_id', true), '')::uuid
$$;


--
-- Name: current_price(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.current_price(p_branch uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'branchId', bp.branch_id, 'basePrice', gold.ts(s.base_price), 'margin', gold.ts(bp.margin),
    'effectivePrice', gold.ts(s.base_price + bp.margin), 'source', s.source, 'status', bp.status, 'asOf', gold.iso(s.published_at))
  from gold.branch_prices bp join gold.price_snapshots s on s.id = bp.snapshot_id
  where bp.branch_id = p_branch
  order by bp.effective_from desc, bp.created_at desc
  limit 1
$$;


--
-- Name: current_tenant(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.current_tenant() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select nullif(current_setting('app.tenant_id', true), '')::uuid
$$;


--
-- Name: customer_detail_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.customer_detail_json(p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare c gold.customers;
begin
  select * into c from gold.customers where id = p_id;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Customer was not found.'); end if;
  return gold.customer_row_json(c) || jsonb_build_object(
    'transactions', coalesce((select jsonb_agg(jsonb_build_object(
        'id', t.id, 'reference', t.reference, 'branchId', t.branch_id, 'branchName', b.name, 'payable', gold.ts(t.payable),
        'capturedAt', gold.iso(t.captured_at), 'customerName', t.customer_name) order by t.captured_at desc)
      from (select * from gold.transactions where customer_id = p_id order by captured_at desc limit 20) t
      join gold.branches b on b.id = t.branch_id), '[]'::jsonb),
    'debts', coalesce((select jsonb_agg(gold.debt_json(d.id) order by d.issued_at desc) from gold.debts d where d.customer_id = p_id), '[]'::jsonb),
    'held', coalesce((select jsonb_agg(gold.collateral_json(h.id) order by h.received_at desc) from gold.collateral_holdings h where h.customer_id = p_id), '[]'::jsonb));
end $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customers; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.customers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    phone text,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY gold.customers FORCE ROW LEVEL SECURITY;


--
-- Name: customer_row_json(gold.customers); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.customer_row_json(c gold.customers) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'id', c.id, 'name', c.name, 'phone', c.phone, 'notes', c.notes, 'createdAt', gold.iso(c.created_at),
    'purchases', (select count(*) from gold.transactions t where t.customer_id = c.id and t.status <> 'void'),
    'lifetimePaid', gold.ts(coalesce((select sum(t.payable) from gold.transactions t where t.customer_id = c.id and t.status <> 'void'), 0)),
    'firstPurchaseAt', (select case when min(t.captured_at) is null then null else gold.iso(min(t.captured_at)) end from gold.transactions t where t.customer_id = c.id and t.status <> 'void'),
    'lastPurchaseAt', (select case when max(t.captured_at) is null then null else gold.iso(max(t.captured_at)) end from gold.transactions t where t.customer_id = c.id and t.status <> 'void'),
    'owesUs', gold.ts(coalesce((select sum(d.outstanding) from gold.v_debts_outstanding d where d.customer_id = c.id and d.status = 'open' and d.direction = 'receivable'), 0)),
    'weOwe', gold.ts(coalesce((select sum(d.outstanding) from gold.v_debts_outstanding d where d.customer_id = c.id and d.status = 'open' and d.direction = 'payable'), 0)))
$$;


--
-- Name: customers_json(text, integer); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.customers_json(p_q text, p_limit integer DEFAULT 20) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(jsonb_build_object('id', id, 'name', name, 'phone', phone)), '[]'::jsonb)
  from (select * from gold.customers
        where p_q is null or lower(name) like '%' || lower(p_q) || '%' or phone like '%' || p_q || '%'
        order by name limit least(coalesce(p_limit, 20), 50)) c
$$;


--
-- Name: customers_lookup_json(text, uuid, integer); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.customers_lookup_json(p_q text, p_branch uuid, p_limit integer DEFAULT 25) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(jsonb_build_object('id', id, 'name', name, 'phone', phone, 'atBranch', last_here is not null) order by exact desc, (last_here is not null) desc, last_here desc nulls last, name), '[]'::jsonb)
  from (
    select c.id, c.name, c.phone,
           (select max(t.captured_at) from gold.transactions t where t.customer_id = c.id and t.branch_id = p_branch) as last_here,
           (nullif(p_q, '') is not null and c.phone = regexp_replace(p_q, '\s', '', 'g')) as exact
    from gold.customers c
    where nullif(trim(coalesce(p_q, '')), '') is null
       or lower(c.name) like '%' || lower(trim(p_q)) || '%'
       or c.phone like '%' || regexp_replace(p_q, '\s', '', 'g') || '%'
    order by 5 desc, 4 desc nulls last, c.name
    limit least(coalesce(p_limit, 25), 1000)
  ) x
$$;


--
-- Name: customers_page_json(text, integer, integer); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.customers_page_json(p_q text, p_limit integer, p_offset integer) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  with f as (
    select * from gold.customers c
    where p_q is null or lower(c.name) like '%' || lower(p_q) || '%' or c.phone like '%' || p_q || '%'
  )
  select jsonb_build_object(
    'total', (select count(*) from f),
    'items', coalesce((select jsonb_agg(gold.customer_row_json(x) order by lower(x.name), x.id)
                       from (select * from f order by lower(name), id limit least(greatest(coalesce(p_limit, 25), 1), 100) offset greatest(coalesce(p_offset, 0), 0)) x), '[]'::jsonb))
$$;


--
-- Name: customers_query_json(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.customers_query_json(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare
  v_q text := nullif(trim(coalesce(p->>'q', '')), '');
  v_like text;
  v_filter text := coalesce(nullif(p->>'filter', ''), 'all');
  v_sort text := coalesce(nullif(p->>'sort', ''), 'name');
  v_limit int := least(greatest(coalesce((p->>'limit')::int, 25), 1), 100);
  v_offset int := greatest(coalesce((p->>'offset')::int, 0), 0);
  v_total bigint; v_items jsonb; v_summary jsonb;
begin
  if v_filter not in ('all', 'owes_us', 'we_owe', 'active', 'inactive') then perform gold.fail(422, 'VALIDATION_FAILED', 'That filter is not known.'); end if;
  if v_sort not in ('name', 'recent', 'purchases', 'paid', 'owes') then perform gold.fail(422, 'VALIDATION_FAILED', 'That sort order is not known.'); end if;
  v_like := case when v_q is null then null else '%' || replace(replace(replace(lower(v_q), '\', '\\'), '%', '\%'), '_', '\_') || '%' end;

  with st as (
    select c.id, c.name,
           (select count(*) from gold.transactions t where t.customer_id = c.id and t.status <> 'void') as purchases,
           (select max(t.captured_at) from gold.transactions t where t.customer_id = c.id and t.status <> 'void') as last_at,
           coalesce((select sum(t.payable) from gold.transactions t where t.customer_id = c.id and t.status <> 'void'), 0) as paid,
           coalesce((select sum(d.outstanding) from gold.v_debts_outstanding d where d.customer_id = c.id and d.status = 'open' and d.direction = 'receivable'), 0) as owes_us,
           coalesce((select sum(d.outstanding) from gold.v_debts_outstanding d where d.customer_id = c.id and d.status = 'open' and d.direction = 'payable'), 0) as we_owe
    from gold.customers c
  ), hits as (
    select st.* from st join gold.customers c on c.id = st.id
    where (v_like is null or lower(c.name) like v_like escape '\' or coalesce(c.phone, '') like v_like escape '\')
      and case v_filter
            when 'owes_us' then st.owes_us > 0
            when 'we_owe' then st.we_owe > 0
            when 'active' then st.last_at >= now() - interval '30 days'
            when 'inactive' then st.last_at is null or st.last_at < now() - interval '90 days'
            else true end
  ), ranked as (
    select id, row_number() over (order by
      case when v_sort = 'recent' then last_at end desc nulls last,
      case when v_sort = 'purchases' then purchases end desc,
      case when v_sort = 'paid' then paid end desc,
      case when v_sort = 'owes' then owes_us + we_owe end desc,
      lower(name), id) as rn
    from hits
  )
  select (select count(*) from hits),
         coalesce((select jsonb_agg(gold.customer_row_json(c) order by o.rn)
                   from ranked o join gold.customers c on c.id = o.id where o.rn > v_offset and o.rn <= v_offset + v_limit), '[]'::jsonb),
         (select jsonb_build_object('customers', count(*), 'active', count(*) filter (where last_at >= now() - interval '30 days'),
                                    'owesUs', gold.ts(coalesce(sum(owes_us), 0)), 'weOwe', gold.ts(coalesce(sum(we_owe), 0))) from st)
  into v_total, v_items, v_summary;
  return jsonb_build_object('total', v_total, 'items', v_items, 'summary', v_summary);
end $$;


--
-- Name: daily_account_json(uuid, date); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.daily_account_json(p_branch uuid, p_date date) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare
  b gold.branches; d gold.business_days; pd gold.business_days; c gold.day_balances; pc gold.day_balances;
  v_seq bigint; v_t timestamptz; v_pt timestamptz;
  v_debtors jsonb; v_listed numeric; v_bundles jsonb; v_loose jsonb; v_bt numeric := 0; v_lt numeric := 0;
  v_last_out date; v_goods_rows jsonb; v_goods_sum numeric; v_sent jsonb;
  v_allow numeric; v_people int; v_closing numeric; v_prev_closing numeric;
begin
  select * into b from gold.branches where id = p_branch;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Branch was not found.'); end if;
  select * into d from gold.business_days where branch_id = p_branch and business_date = p_date and status = 'closed' order by session_no desc limit 1;
  if not found then
    return jsonb_build_object('branchId', b.id, 'name', b.name, 'isMain', b.is_main, 'businessDate', p_date,
      'status', case when exists (select 1 from gold.business_days x where x.branch_id = p_branch and x.business_date = p_date) then 'open' else 'none' end);
  end if;
  select * into c from gold.day_balances where business_day_id = d.id and kind = 'closing_declared';
  v_t := d.closed_at;
  select max(seq) into v_seq from gold.ledger_entries where branch_id = p_branch and business_day_id = d.id;
  select * into pd from gold.business_days x
   where x.branch_id = p_branch and x.status = 'closed' and (x.business_date, x.session_no) < (d.business_date, d.session_no)
   order by x.business_date desc, x.session_no desc limit 1;
  if found then
    select * into pc from gold.day_balances where business_day_id = pd.id and kind = 'closing_declared';
    v_pt := pd.closed_at;
  end if;

  -- debtors, with what changed since the previous closed day
  select coalesce(jsonb_agg(jsonb_build_object('id', x.id, 'name', x.name, 'amount', gold.ts(x.amount),
           'change', case when v_pt is null then null else gold.ts(x.amount - coalesce(p.amount, 0)) end,
           'isNew', v_pt is not null and p.id is null) order by x.amount desc, lower(x.name)), '[]'::jsonb),
         coalesce(sum(x.amount), 0)
  into v_debtors, v_listed
  from gold.debtors_at(p_branch, v_t) x left join gold.debtors_at(p_branch, coalesce(v_pt, v_t)) p on p.id = x.id and v_pt is not null;

  -- cash: whole bundles of 100 notes, and the loose rest
  select coalesce(jsonb_agg(jsonb_build_object('denomination', k, 'count', (n / 100) * 100, 'value', gold.ts(k * (n / 100) * 100)) order by k desc) filter (where n >= 100), '[]'::jsonb),
         coalesce(jsonb_agg(jsonb_build_object('denomination', k, 'count', n % 100, 'value', gold.ts(k * (n % 100))) order by k desc) filter (where n % 100 > 0), '[]'::jsonb),
         coalesce(sum(k * (n / 100) * 100), 0), coalesce(sum(k * (n % 100)), 0)
  into v_bundles, v_loose, v_bt, v_lt
  from (select key::int as k, (value #>> '{}')::int as n from jsonb_each(c.cash_lines)) z where n > 0;

  -- goods: the days since the last time goods were sent out, newest first; the rest is "brought forward"
  select max(dt) into v_last_out from (
    select coalesce(bd.business_date, (e.occurred_at at time zone b.timezone)::date) as dt
    from gold.ledger_entries e left join gold.business_days bd on bd.id = e.business_day_id
    where e.branch_id = p_branch and e.asset = 'goods' and e.source_type = 'transfer_release' and e.delta_value < 0 and e.seq <= coalesce(v_seq, 9223372036854775807)) o;
  select coalesce(jsonb_agg(jsonb_build_object('date', g.dt, 'value', gold.ts(g.v)) order by g.dt desc), '[]'::jsonb), coalesce(sum(g.v), 0)
  into v_goods_rows, v_goods_sum
  from (select coalesce(bd.business_date, (e.occurred_at at time zone b.timezone)::date) as dt, sum(e.delta_value) as v
        from gold.ledger_entries e left join gold.business_days bd on bd.id = e.business_day_id
        where e.branch_id = p_branch and e.asset = 'goods' and e.seq <= coalesce(v_seq, 9223372036854775807)
        group by 1 having sum(e.delta_value) <> 0) g
  where v_last_out is null or g.dt > v_last_out;
  select coalesce(jsonb_agg(jsonb_build_object('reference', t.reference, 'date', (t.released_at at time zone b.timezone)::date, 'value', gold.ts(coalesce(t.declared_value, 0)),
           'to', (select name from gold.branches x where x.id = t.destination_branch_id)) order by t.released_at desc), '[]'::jsonb)
  into v_sent
  from (select * from gold.transfers where origin_branch_id = p_branch and kind = 'goods' and released_at is not null and released_at <= v_t order by released_at desc limit 15) t;

  -- office allowance paid from the drawer on this date
  select coalesce(sum(-e.delta_value), 0), coalesce(max(m.people), 0) into v_allow, v_people
  from gold.drawer_movements m join gold.business_days x on x.id = m.business_day_id and x.branch_id = p_branch and x.business_date = p_date
  left join gold.ledger_entries e on e.source_type = 'drawer_movement' and e.source_id = m.id and e.asset = 'cash'
  where m.kind = 'allowance';

  v_closing := c.cash_value + c.debt_value + c.goods_value - c.payable_value;
  v_prev_closing := case when pc.id is null then null else pc.cash_value + pc.debt_value + pc.goods_value - pc.payable_value end;

  return jsonb_build_object(
    'branchId', b.id, 'name', b.name, 'isMain', b.is_main, 'businessDate', p_date, 'status', 'closed',
    'day', jsonb_build_object('id', d.id, 'openedAt', gold.iso(d.opened_at), 'closedAt', gold.iso(d.closed_at), 'closedBy', gold.person_json(d.closed_by),
                              'signoff', d.signoff_status, 'sessions', (select count(*) from gold.business_days x where x.branch_id = p_branch and x.business_date = p_date)),
    'debtors', v_debtors, 'debtTotal', gold.ts(c.debt_value), 'debtUnlisted', gold.ts(c.debt_value - v_listed),
    'cash', jsonb_build_object('bundles', v_bundles, 'bundlesTotal', gold.ts(v_bt), 'loose', v_loose, 'looseTotal', gold.ts(v_lt), 'total', gold.ts(c.cash_value)),
    'goods', jsonb_build_object('total', gold.ts(c.goods_value), 'days', v_goods_rows, 'broughtForward', gold.ts(c.goods_value - v_goods_sum),
                                'lastSentOn', v_last_out, 'sent', v_sent),
    'owedToCustomers', gold.ts(c.payable_value),
    'allowance', jsonb_build_object('paid', gold.ts(v_allow), 'people', v_people),
    'closing', gold.ts(v_closing),
    'previous', case when v_prev_closing is null then null else jsonb_build_object('date', pd.business_date, 'closing', gold.ts(v_prev_closing)) end,
    'change', case when v_prev_closing is null then null else gold.ts(v_closing - v_prev_closing) end);
end $$;


--
-- Name: daily_accounts_json(uuid[], uuid, date); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.daily_accounts_json(p_scope uuid[], p_branch uuid, p_date date) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare v_out jsonb;
begin
  if p_branch is not null and not (p_branch = any (coalesce(p_scope, '{}'))) then
    perform gold.fail(403, 'FORBIDDEN', 'You do not have access to that branch.');
  end if;
  select coalesce(jsonb_agg(gold.daily_account_json(b.id, p_date) order by b.is_main desc, b.name), '[]'::jsonb) into v_out
  from gold.branches b where b.is_active and b.id = any (coalesce(p_scope, '{}')) and (p_branch is null or b.id = p_branch);
  return jsonb_build_object('date', p_date, 'branches', v_out);
end $$;


--
-- Name: dash_base(uuid[], integer, timestamp with time zone); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.dash_base(p_ids uuid[], p_days integer, p_now timestamp with time zone) RETURNS TABLE(id uuid, branch_id uuid, local_date date, payable numeric, status text, flags text[], created_by uuid, customer_id uuid, customer_name text, reference text, captured_at timestamp with time zone)
    LANGUAGE sql STABLE
    AS $$
  select t.id, t.branch_id, (t.captured_at at time zone b.timezone)::date, t.payable, t.status, t.flags, t.created_by, t.customer_id, t.customer_name, t.reference, t.captured_at
  from gold.transactions t join gold.branches b on b.id = t.branch_id
  where t.branch_id = any (p_ids)
    and (t.captured_at at time zone b.timezone)::date >= (p_now at time zone b.timezone)::date - (p_days - 1)
$$;


--
-- Name: dashboard_json(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.dashboard_json(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare
  v_scope uuid[] := array(select jsonb_array_elements_text(coalesce(p->'scope', '[]'::jsonb))::uuid);
  v_branch uuid := nullif(p->>'branchId', '')::uuid;
  v_days int := least(greatest(coalesce((p->>'days')::int, 14), 7), 60);
  v_now timestamptz := coalesce(nullif(p->>'asOf', '')::timestamptz, now());
  v_mine uuid := nullif(p->>'mine', '')::uuid;
  v_ids uuid[];
  v_today jsonb; v_yday jsonb; v_series jsonb; v_branches jsonb; v_tellers jsonb; v_pay jsonb; v_stock jsonb; v_transfers jsonb;
  v_debts jsonb; v_customers jsonb; v_flags jsonb; v_cash jsonb; v_mine_j jsonb; v_pending int; v_signoff int;
begin
  if v_branch is not null and not (v_branch = any (v_scope)) then perform gold.fail(403, 'FORBIDDEN', 'You do not have access to that branch.'); end if;
  v_ids := case when v_branch is null then v_scope else array[v_branch] end;

  select jsonb_build_object(
    'count', count(*) filter (where x.status <> 'void'),
    'paid', coalesce(sum(x.payable) filter (where x.status <> 'void'), 0),
    'voided', count(*) filter (where x.status = 'void'),
    'flagged', count(*) filter (where x.status <> 'void' and cardinality(x.flags) > 0),
    'pounds', coalesce((select sum(i.pounds) from gold.transaction_items i where i.transaction_id in
        (select y.id from gold.dash_base(v_ids, v_days, v_now) y join gold.branches yb on yb.id = y.branch_id where y.status <> 'void' and y.local_date = (v_now at time zone yb.timezone)::date)), 0))
  into v_today
  from gold.dash_base(v_ids, v_days, v_now) x join gold.branches b on b.id = x.branch_id where x.local_date = (v_now at time zone b.timezone)::date;

  select jsonb_build_object('count', count(*) filter (where x.status <> 'void'), 'paid', coalesce(sum(x.payable) filter (where x.status <> 'void'), 0))
  into v_yday
  from gold.dash_base(v_ids, v_days, v_now) x join gold.branches b on b.id = x.branch_id where x.local_date = (v_now at time zone b.timezone)::date - 1;

  -- one row per calendar day of the window, empty days included
  select coalesce(jsonb_agg(jsonb_build_object('date', d.day, 'count', coalesce(s.n, 0), 'paid', gold.ts(coalesce(s.paid, 0)), 'pounds', gold.ts(coalesce(s.lb, 0))) order by d.day), '[]'::jsonb)
  into v_series
  from (select generate_series((v_now at time zone 'Africa/Accra')::date - (v_days - 1), (v_now at time zone 'Africa/Accra')::date, interval '1 day')::date as day) d
  left join (
    select x.local_date, count(*) as n, sum(x.payable) as paid,
           (select sum(i.pounds) from gold.transaction_items i where i.transaction_id = any (array_agg(x.id))) as lb
    from gold.dash_base(v_ids, v_days, v_now) x where x.status <> 'void' group by x.local_date
  ) s on s.local_date = d.day;

  select coalesce(jsonb_agg(row order by (row->>'periodPaid')::numeric desc), '[]'::jsonb) into v_branches from (
    select jsonb_build_object(
      'branchId', b.id, 'name', b.name,
      'todayCount', count(x.id) filter (where x.status <> 'void' and x.local_date = (v_now at time zone b.timezone)::date),
      'todayPaid', gold.ts(coalesce(sum(x.payable) filter (where x.status <> 'void' and x.local_date = (v_now at time zone b.timezone)::date), 0)),
      'periodCount', count(x.id) filter (where x.status <> 'void'),
      'periodPaid', gold.ts(coalesce(sum(x.payable) filter (where x.status <> 'void'), 0)),
      'flagged', count(x.id) filter (where x.status <> 'void' and cardinality(x.flags) > 0),
      'voided', count(x.id) filter (where x.status = 'void'),
      'day', coalesce((select bd.status from gold.business_days bd where bd.branch_id = b.id and bd.business_date = (v_now at time zone b.timezone)::date), 'none'),
      'signoffPending', (select count(*) from gold.business_days bd where bd.branch_id = b.id and bd.signoff_status = 'pending'),
      'goldOnHand', gold.ts(coalesce((select sum(i.pounds) from gold.transaction_items i join gold.transactions tt on tt.id = i.transaction_id
                          where i.location_branch_id = b.id and i.location_state = 'on_hand' and tt.status <> 'void'), 0))
    ) as row
    from gold.branches b left join gold.dash_base(v_ids, v_days, v_now) x on x.branch_id = b.id
    where b.id = any (v_ids) and b.is_active
    group by b.id, b.name, b.timezone
  ) q;

  select coalesce(jsonb_agg(row order by (row->>'paid')::numeric desc), '[]'::jsonb) into v_tellers from (
    select jsonb_build_object('userId', u.id, 'name', u.display_name, 'count', count(*), 'paid', gold.ts(sum(x.payable)),
                              'flagged', count(*) filter (where cardinality(x.flags) > 0)) as row
    from gold.dash_base(v_ids, v_days, v_now) x join gold.users u on u.id = x.created_by
    where x.status <> 'void' group by u.id, u.display_name order by sum(x.payable) desc limit 8
  ) q;

  select jsonb_build_object(
    'cash', gold.ts(coalesce(sum(pm.amount) filter (where pm.method = 'cash'), 0)),
    'mobileMoney', gold.ts(coalesce(sum(pm.amount) filter (where pm.method = 'mobile_money'), 0)),
    'owed', gold.ts(coalesce(sum(pm.amount) filter (where pm.method = 'owed'), 0)))
  into v_pay
  from gold.transaction_payments pm where pm.status <> 'failed' and pm.transaction_id in (select id from gold.dash_base(v_ids, v_days, v_now) where status <> 'void');

  select count(*) into v_pending from gold.transaction_payments pm
   where pm.status = 'pending' and pm.transaction_id in (select id from gold.dash_base(v_ids, v_days, v_now) where status <> 'void');

  select count(*) into v_signoff from gold.business_days bd where bd.branch_id = any (v_ids) and bd.signoff_status = 'pending';

  select jsonb_build_object(
    'onHand', gold.ts(coalesce(sum(i.pounds) filter (where i.location_state = 'on_hand'), 0)),
    'inTransit', gold.ts(coalesce(sum(i.pounds) filter (where i.location_state = 'in_transit'), 0)))
  into v_stock
  from gold.transaction_items i join gold.transactions tt on tt.id = i.transaction_id
  where i.location_branch_id = any (v_ids) and tt.status <> 'void';

  select jsonb_build_object('onTheRoad', count(*), 'value', gold.ts(coalesce(sum(declared_value), 0)))
  into v_transfers
  from gold.transfers where status = 'released' and (origin_branch_id = any (v_ids) or destination_branch_id = any (v_ids));

  select jsonb_build_object('owedToUs', gold.ts(coalesce(sum(outstanding), 0)), 'count', count(*), 'overdue', count(*) filter (where due_date < (v_now at time zone 'Africa/Accra')::date))
  into v_debts from gold.v_debts_outstanding where status = 'open' and outstanding > 0 and branch_id = any (v_ids);

  select coalesce(jsonb_agg(row), '[]'::jsonb) into v_customers from (
    select jsonb_build_object('customerId', x.customer_id, 'name', max(x.customer_name), 'count', count(*), 'paid', gold.ts(sum(x.payable))) as row
    from gold.dash_base(v_ids, v_days, v_now) x where x.status <> 'void' and x.customer_id is not null
    group by x.customer_id order by sum(x.payable) desc limit 5
  ) q;

  select coalesce(jsonb_object_agg(f, n), '{}'::jsonb) into v_flags from (
    select f, count(*) as n from gold.dash_base(v_ids, v_days, v_now) x, unnest(x.flags) f where x.status <> 'void' group by f
  ) q;

  -- cash counted at closing that did not match, within the window
  select jsonb_build_object('days', count(*), 'net', gold.ts(coalesce(sum(r.difference), 0)),
    'recent', coalesce(jsonb_agg(jsonb_build_object('branch', b.name, 'date', bd.business_date, 'difference', gold.ts(r.difference)) order by bd.business_date desc) filter (where true), '[]'::jsonb))
  into v_cash
  from gold.day_reconciliations r join gold.business_days bd on bd.id = r.business_day_id join gold.branches b on b.id = bd.branch_id
  where r.phase = 'closing' and r.asset = 'cash' and r.difference <> 0 and bd.branch_id = any (v_ids)
    and bd.business_date >= (v_now at time zone 'Africa/Accra')::date - (v_days - 1);

  if v_mine is not null then
    select jsonb_build_object(
      'todayCount', count(*) filter (where x.status <> 'void' and x.local_date = (v_now at time zone b.timezone)::date),
      'todayPaid', gold.ts(coalesce(sum(x.payable) filter (where x.status <> 'void' and x.local_date = (v_now at time zone b.timezone)::date), 0)),
      'periodCount', count(*) filter (where x.status <> 'void'),
      'recent', coalesce((select jsonb_agg(jsonb_build_object('reference', y.reference, 'customerName', y.customer_name, 'payable', gold.ts(y.payable), 'capturedAt', y.captured_at, 'status', y.status) order by y.captured_at desc)
                          from (select * from gold.dash_base(v_ids, v_days, v_now) where created_by = v_mine order by captured_at desc limit 5) y), '[]'::jsonb))
    into v_mine_j
    from gold.dash_base(v_ids, v_days, v_now) x join gold.branches b on b.id = x.branch_id where x.created_by = v_mine;
  end if;

  return jsonb_build_object(
    'asOf', v_now, 'days', v_days,
    'today', jsonb_set(v_today, '{paid}', to_jsonb(gold.ts((v_today->>'paid')::numeric))),
    'yesterday', jsonb_set(v_yday, '{paid}', to_jsonb(gold.ts((v_yday->>'paid')::numeric))),
    'series', v_series, 'branches', v_branches, 'tellers', v_tellers, 'payments', v_pay, 'pendingMoney', v_pending, 'signoffPending', v_signoff,
    'stock', v_stock, 'transfers', v_transfers, 'debts', v_debts, 'topCustomers', v_customers, 'flags', v_flags, 'cashDifferences', v_cash,
    'mine', coalesce(v_mine_j, jsonb_build_object('todayCount', 0, 'todayPaid', '0', 'periodCount', 0, 'recent', '[]'::jsonb)));
end $$;


--
-- Name: day_activity_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.day_activity_json(p_day uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare d gold.business_days; v_open jsonb;
begin
  select * into d from gold.business_days where id = p_day;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That day was not found.'); end if;
  v_open := coalesce((select cash_lines from gold.day_balances where business_day_id = d.id and kind = 'opening_declared'), '{}'::jsonb);
  return jsonb_build_object(
    'dayId', d.id, 'branchId', d.branch_id, 'businessDate', d.business_date, 'status', d.status,
    'cash', jsonb_build_object(
        'opening', v_open,
        'in',  coalesce((select jsonb_object_agg(k::text, n) from (select denomination k, sum(delta_count) n from gold.ledger_entries
                          where business_day_id = d.id and source_type not in ('go_live_balance', 'opening_adjustment') and asset = 'cash' and delta_count > 0 group by denomination) x), '{}'::jsonb),
        'out', coalesce((select jsonb_object_agg(k::text, n) from (select denomination k, -sum(delta_count) n from gold.ledger_entries
                          where business_day_id = d.id and source_type not in ('go_live_balance', 'opening_adjustment') and asset = 'cash' and delta_count < 0 group by denomination) x), '{}'::jsonb),
        'net', coalesce((select jsonb_object_agg(k::text, n) from (select denomination k, sum(delta_count) n from gold.ledger_entries
                          where business_day_id = d.id and source_type not in ('go_live_balance', 'opening_adjustment') and asset = 'cash' group by denomination having sum(delta_count) <> 0) x), '{}'::jsonb),
        'netValue', gold.ts(coalesce((select sum(delta_value) from gold.ledger_entries where business_day_id = d.id and source_type not in ('go_live_balance', 'opening_adjustment') and asset = 'cash'), 0))),
    'goods', (select jsonb_build_object('top', gold.ts(coalesce(sum(delta_top), 0)), 'down', gold.ts(coalesce(sum(delta_down), 0)),
                                        'value', gold.ts(coalesce(sum(delta_value), 0)))
              from gold.ledger_entries where business_day_id = d.id and source_type not in ('go_live_balance', 'opening_adjustment') and asset = 'goods'),
    'debts', jsonb_build_object(
        'net', gold.ts(coalesce((select sum(delta_value) from gold.ledger_entries where business_day_id = d.id and source_type not in ('go_live_balance', 'opening_adjustment') and asset = 'debt'), 0)),
        'debtors', coalesce((
          select jsonb_agg(jsonb_build_object('customerId', customer_id, 'name', party_name, 'issued', gold.ts(issued), 'repaid', gold.ts(repaid), 'net', gold.ts(issued - repaid))
                           order by issued - repaid desc, party_name)
          from (select db.customer_id, db.party_name,
                       sum(case when l.delta_value > 0 then l.delta_value else 0 end) as issued,
                       sum(case when l.delta_value < 0 then -l.delta_value else 0 end) as repaid
                from gold.ledger_entries l
                join gold.debts db on db.id = case l.source_type when 'debt_issued' then l.source_id
                                               else (select r.debt_id from gold.debt_repayments r where r.id = l.source_id) end
                where l.business_day_id = d.id and l.source_type not in ('go_live_balance', 'opening_adjustment') and l.asset = 'debt' and l.source_type in ('debt_issued', 'debt_repayment')
                group by db.customer_id, db.party_name) x), '[]'::jsonb)),
    'payable', gold.ts(coalesce((select sum(delta_value) from gold.ledger_entries where business_day_id = d.id and source_type not in ('go_live_balance', 'opening_adjustment') and asset = 'payable'), 0)));
end $$;


--
-- Name: day_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.day_json(p_day uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'id', d.id, 'branchId', d.branch_id, 'businessDate', d.business_date, 'status', d.status,
    'opening', jsonb_build_object(
        'lines', coalesce((select cash_lines from gold.day_balances where business_day_id = d.id and kind = 'opening_declared'), '{}'::jsonb),
        'source', d.opening_source),
    'openedAt', gold.iso(d.opened_at), 'openedBy', gold.person_json(d.opened_by),
    'closing', case when d.status <> 'closed' then null else jsonb_build_object(
        'closedAt', gold.iso(d.closed_at), 'closedBy', gold.person_json(d.closed_by),
        'confirmation', jsonb_build_object('version', d.closing_confirmation_version, 'text', d.closing_confirmation_text),
        'figures', coalesce((select jsonb_agg(jsonb_build_object(
              'asset', r.asset, 'expected', gold.ts(r.expected), 'actual', gold.ts(r.actual), 'difference', gold.ts(r.difference),
              'outcome', r.outcome, 'explanation', r.explanation, 'detail', r.detail)
              order by array_position(array['cash','goods_top','goods_down','goods_value','debt','payable','custody_top'], r.asset))
            from gold.day_reconciliations r where r.business_day_id = d.id and r.phase = 'closing'), '[]'::jsonb),
        'cash', jsonb_build_object(
            'expected', coalesce((select cash_lines from gold.day_balances where business_day_id = d.id and kind = 'closing_expected'), '{}'::jsonb),
            'counted',  coalesce((select cash_lines from gold.day_balances where business_day_id = d.id and kind = 'closing_declared'), '{}'::jsonb)),
        'signoff', jsonb_build_object('status', d.signoff_status, 'by', case when d.signoff_by is null then null else gold.person_json(d.signoff_by) end,
                                      'at', case when d.signoff_at is null then null else gold.iso(d.signoff_at) end, 'note', d.signoff_note)) end,
    'flags', to_jsonb(array_remove(array[
        case when d.opened_offline then 'OFFLINE_ENTRY' end,
        case when exists (select 1 from gold.day_reconciliations r where r.business_day_id = d.id and r.phase = 'opening' and r.detail is not null)
             then 'OPENING_DIFFERS' end,
        case when d.signoff_status <> 'not_required' then 'CLOSING_DIFFERS' end], null)))
  from gold.business_days d where d.id = p_day
$$;


--
-- Name: day_state(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.day_state(p_branch uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare d gold.business_days; bal record; v_carry jsonb := null;
begin
  select * into d from gold.business_days where branch_id = p_branch order by (status = 'open') desc, business_date desc, opened_at desc limit 1;
  select * into bal from gold.branch_balance(p_branch);
  if exists (select 1 from gold.ledger_entries where branch_id = p_branch) then
    select coalesce(jsonb_object_agg(key, value), '{}'::jsonb) into v_carry from jsonb_each(bal.cash_lines) where (value #>> '{}')::int > 0;
  end if;
  return jsonb_build_object(
    'day', case when d.id is null then null else gold.day_json(d.id) end,
    'balance', case when d.status = 'open' then bal.cash_lines else null end,
    'movements', case when d.id is null then '[]'::jsonb else
        coalesce((select jsonb_agg(gold.movement_json(m.id) order by m.occurred_at, m.created_at)
                  from gold.drawer_movements m where m.business_day_id = d.id), '[]'::jsonb) end,
    'appliedIds', case when d.id is null then '[]'::jsonb else
        coalesce((select jsonb_agg(x) from (
           select d.id::text as x
           union select source_id::text from gold.ledger_entries
                 where business_day_id = d.id and source_type in ('transaction_payout', 'drawer_movement', 'debt_issued', 'debt_repayment', 'payable_settlement')
        ) ids), '[]'::jsonb) end,
    'carryOver', v_carry,
    'asOf', gold.iso(now()));
end $$;


--
-- Name: days_json(uuid, date, date, text, integer); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.days_json(p_branch uuid, p_from date, p_to date, p_signoff text, p_limit integer) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(gold.day_json(id) order by business_date desc), '[]'::jsonb)
  from (select id, business_date from gold.business_days
        where branch_id = p_branch
          and (p_from is null or business_date >= p_from) and (p_to is null or business_date <= p_to)
          and (p_signoff is null or signoff_status = p_signoff)
        order by business_date desc limit least(coalesce(p_limit, 60), 200)) x
$$;


--
-- Name: debt_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.debt_json(p_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'id', d.id, 'branchId', d.branch_id, 'direction', d.direction,
    'party', jsonb_build_object('type', d.party_type, 'name', d.party_name, 'customerId', d.customer_id, 'phone', c.phone),
    'principal', gold.ts(d.principal), 'repaid', gold.ts(d.principal - d.outstanding), 'outstanding', gold.ts(d.outstanding),
    'reason', d.reason, 'issuedAt', gold.iso(d.issued_at), 'dueDate', d.due_date, 'status', d.status,
    'sourceTransactionId', d.source_transaction_id,
    'collateral', (select jsonb_build_object('id', h.id, 'topWeight', gold.ts(h.top_weight), 'status', h.status, 'description', h.description)
                   from gold.collateral_holdings h where h.debt_id = d.id limit 1),
    'repayments', coalesce((select jsonb_agg(jsonb_build_object(
        'id', r.id, 'amount', gold.ts(r.amount), 'method', r.method, 'receivedAt', gold.iso(r.received_at),
        'receivedBy', gold.person_json(r.received_by), 'paidByBranchId', r.paid_by_branch_id, 'externalRef', r.external_ref,
        'transactionId', r.source_transaction_id, 'note', r.note) order by r.received_at, r.id)
        from gold.debt_repayments r where r.debt_id = d.id), '[]'::jsonb))
  from gold.v_debts_outstanding d left join gold.customers c on c.id = d.customer_id
  where d.id = p_id
$$;


--
-- Name: debtors_at(uuid, timestamp with time zone); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.debtors_at(p_branch uuid, p_t timestamp with time zone) RETURNS TABLE(id uuid, name text, amount numeric, issued_at timestamp with time zone)
    LANGUAGE sql STABLE
    AS $$
  select x.id, x.party_name, x.amt, x.issued_at from (
    select d.id, d.party_name, d.issued_at,
           d.principal - coalesce((select sum(r.amount) from gold.debt_repayments r where r.debt_id = d.id and r.received_at <= p_t), 0) as amt
    from gold.debts d
    where d.branch_id = p_branch and d.direction = 'receivable' and d.issued_at <= p_t and (d.status = 'open' or d.closed_at > p_t)
  ) x where x.amt > 0
$$;


--
-- Name: debts_json(uuid, text, boolean, uuid, integer); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.debts_json(p_branch uuid, p_direction text, p_open_only boolean, p_customer uuid, p_limit integer DEFAULT 100) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(gold.debt_json(id) order by issued_at desc), '[]'::jsonb)
  from (select id, issued_at from gold.debts
        where branch_id = p_branch and (p_direction is null or direction = p_direction)
          and (not coalesce(p_open_only, false) or status = 'open')
          and (p_customer is null or customer_id = p_customer)
        order by issued_at desc limit least(coalesce(p_limit, 100), 200)) x
$$;


--
-- Name: declared(jsonb, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.declared(p jsonb, p_key text) RETURNS numeric
    LANGUAGE plpgsql IMMUTABLE
    AS $$
declare v numeric := nullif(p #>> array['declared', p_key], '')::numeric;
begin
  if v is null or v < 0 then perform gold.fail(422, 'VALIDATION_FAILED', format('Report %s as a number, zero or more.', p_key)); end if;
  return v;
end $$;


--
-- Name: delete_role(text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.delete_role(p_key text) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare r gold.roles; v_before jsonb; n int;
begin
  perform gold.require_actor();
  select * into r from gold.roles where key = p_key for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Role was not found.'); end if;
  if r.is_system then perform gold.fail(409, 'SYSTEM_ROLE', 'The standard roles cannot be deleted.'); end if;
  select count(*) into n from gold.users where role_id = r.id;
  if n > 0 then perform gold.fail(409, 'ROLE_IN_USE', format('%s %s still hold this role. Move them to another role first.', n, case when n = 1 then 'person' else 'people' end)); end if;
  v_before := gold.role_json(p_key);
  delete from gold.roles where id = r.id;
  perform gold.audit('role.deleted', 'role', p_key, v_before, null);
end $$;


--
-- Name: device_key(uuid, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.device_key(p_user uuid, p_device text) RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select public_key from gold.device_keys where user_id = p_user and device_id = p_device and revoked_at is null
$$;


--
-- Name: discrepancies_json(uuid[], text, uuid, integer); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.discrepancies_json(p_scope uuid[], p_status text, p_branch uuid, p_limit integer DEFAULT 100) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(gold.discrepancy_summary(d) order by d.opened_at desc), '[]'::jsonb)
  from (select * from gold.discrepancies x
        where x.branch_id = any(coalesce(p_scope, '{}'))
          and (p_branch is null or x.branch_id = p_branch)
          and case coalesce(p_status, 'active') when 'active' then x.status in ('open', 'under_review')
                                                when 'all' then true else x.status = p_status end
        order by x.opened_at desc limit least(coalesce(p_limit, 100), 300)) d
$$;


--
-- Name: discrepancy_act(uuid, jsonb, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.discrepancy_act(p_id uuid, p jsonb, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_user uuid := gold.require_actor(); d gold.discrepancies;
  v_action text := p->>'action'; v_note text := nullif(trim(coalesce(p->>'note', '')), '');
  v_type text := p->>'resolutionType'; v_sum text := nullif(trim(coalesce(p->>'summary', '')), '');
begin
  select * into d from gold.discrepancies where id = p_id and branch_id = any(coalesce(p_scope, '{}')) for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That case was not found.'); end if;

  if v_action = 'note' then
    if not gold.has_text(v_note, 3) then perform gold.fail(422, 'VALIDATION_FAILED', 'Write the note (at least 3 characters).'); end if;
    insert into gold.discrepancy_actions (tenant_id, discrepancy_id, action_type, note, actor_user_id)
    values (d.tenant_id, d.id, 'note', v_note, v_user);
  elsif v_action = 'take' then
    if d.status not in ('open', 'under_review') then perform gold.fail(409, 'CASE_CLOSED', 'This case is already closed.'); end if;
    update gold.discrepancies set status = 'under_review', assigned_to = v_user where id = d.id;
    if d.assigned_to is distinct from v_user and d.status = 'under_review' then
      insert into gold.discrepancy_actions (tenant_id, discrepancy_id, action_type, note, actor_user_id)
      values (d.tenant_id, d.id, 'assigned', 'Taken over', v_user);
    end if;
  elsif v_action = 'resolve' then
    if d.status not in ('open', 'under_review') then perform gold.fail(409, 'CASE_CLOSED', 'This case is already closed.'); end if;
    if v_type is null or v_type not in ('explained', 'found', 'recovered', 'corrected_entry', 'written_off') then
      perform gold.fail(422, 'VALIDATION_FAILED', 'Choose how the case was resolved.');
    end if;
    if not gold.has_text(v_sum, 10) then perform gold.fail(422, 'VALIDATION_FAILED', 'Write what was found and decided (at least 10 characters).'); end if;
    update gold.discrepancies set status = case when v_type = 'written_off' then 'written_off' else 'resolved' end,
      resolved_at = now(), resolved_by = v_user, resolution_type = v_type, resolution_summary = v_sum where id = d.id;
  elsif v_action = 'reopen' then
    if d.status not in ('resolved', 'written_off') then perform gold.fail(409, 'CASE_NOT_CLOSED', 'Only a closed case can be reopened.'); end if;
    if not gold.has_text(v_note, 5) then perform gold.fail(422, 'VALIDATION_FAILED', 'Say why it is reopened (at least 5 characters).'); end if;
    update gold.discrepancies set status = 'under_review', assigned_to = v_user, resolved_at = null, resolved_by = null,
      resolution_type = null, resolution_summary = null where id = d.id;
    insert into gold.discrepancy_actions (tenant_id, discrepancy_id, action_type, note, actor_user_id)
    values (d.tenant_id, d.id, 'note', 'Reopened: ' || v_note, v_user);
  else
    perform gold.fail(422, 'VALIDATION_FAILED', 'action must be take, note, resolve or reopen.');
  end if;
  return gold.discrepancy_json(p_id, p_scope);
end $$;


--
-- Name: discrepancy_guard(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.discrepancy_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if tg_op = 'DELETE' then
    raise exception 'discrepancies cannot be deleted' using errcode = 'integrity_constraint_violation';
  end if;
  if tg_op = 'INSERT' then
    insert into gold.discrepancy_actions (tenant_id, discrepancy_id, action_type, to_status, note, actor_user_id)
    values (new.tenant_id, new.id, 'opened', new.status, new.reported_explanation, coalesce(new.opened_by, gold.current_actor()));
    return new;
  end if;
  -- UPDATE: the facts of the case are frozen; only workflow fields may change.
  if (new.tenant_id, new.branch_id, new.business_day_id, new.kind, new.asset, new.reconciliation_id, new.transfer_id,
      new.transfer_line_id, new.expected, new.actual, new.difference, new.reported_explanation, new.opened_at)
     is distinct from
     (old.tenant_id, old.branch_id, old.business_day_id, old.kind, old.asset, old.reconciliation_id, old.transfer_id,
      old.transfer_line_id, old.expected, old.actual, old.difference, old.reported_explanation, old.opened_at) then
    raise exception 'the recorded facts of a discrepancy cannot be changed' using errcode = 'integrity_constraint_violation';
  end if;
  if new.status is distinct from old.status then
    insert into gold.discrepancy_actions (tenant_id, discrepancy_id, action_type, from_status, to_status, note, actor_user_id)
    values (new.tenant_id, new.id,
            case when old.status in ('resolved', 'written_off') then 'reopened'
                 when new.status in ('resolved', 'written_off') then 'resolved' else 'status_changed' end,
            old.status, new.status, new.resolution_summary, gold.current_actor());
  end if;
  return new;
end $$;


--
-- Name: discrepancy_json(uuid, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.discrepancy_json(p_id uuid, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare d gold.discrepancies;
begin
  select * into d from gold.discrepancies where id = p_id and branch_id = any(coalesce(p_scope, '{}'));
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That case was not found.'); end if;
  return gold.discrepancy_summary(d) || jsonb_build_object('actions', coalesce((
    select jsonb_agg(jsonb_build_object('id', a.id, 'type', a.action_type, 'fromStatus', a.from_status, 'toStatus', a.to_status,
             'note', a.note, 'by', case when a.actor_user_id is null then null else gold.person_json(a.actor_user_id) end,
             'at', gold.iso(a.occurred_at)) order by a.id)
    from gold.discrepancy_actions a where a.discrepancy_id = d.id), '[]'::jsonb));
end $$;


--
-- Name: has_text(text, integer); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.has_text(value text, min_chars integer DEFAULT 1) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $$ select coalesce(length(trim(value)), 0) >= min_chars $$;


--
-- Name: discrepancies; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.discrepancies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    business_day_id uuid,
    kind text NOT NULL,
    asset text,
    reconciliation_id uuid,
    transfer_id uuid,
    transfer_line_id uuid,
    expected numeric(18,4),
    actual numeric(18,4),
    difference numeric(18,4),
    reported_explanation text,
    status text DEFAULT 'open'::text NOT NULL,
    assigned_to uuid,
    opened_at timestamp with time zone DEFAULT now() NOT NULL,
    opened_by uuid,
    resolved_at timestamp with time zone,
    resolved_by uuid,
    resolution_type text,
    resolution_summary text,
    CONSTRAINT closed_case_is_documented CHECK (((status = ANY (ARRAY['open'::text, 'under_review'::text])) OR ((resolved_at IS NOT NULL) AND (resolved_by IS NOT NULL) AND (resolution_type IS NOT NULL) AND gold.has_text(resolution_summary, 10)))),
    CONSTRAINT discrepancies_asset_check CHECK ((asset = ANY (ARRAY['cash'::text, 'goods_top'::text, 'goods_down'::text, 'goods_value'::text, 'debt'::text, 'payable'::text, 'custody_top'::text]))),
    CONSTRAINT discrepancies_check CHECK (((reconciliation_id IS NOT NULL) OR (transfer_id IS NOT NULL) OR (kind = 'other'::text))),
    CONSTRAINT discrepancies_kind_check CHECK ((kind = ANY (ARRAY['opening_variance'::text, 'closing_variance'::text, 'transfer_receipt'::text, 'other'::text]))),
    CONSTRAINT discrepancies_resolution_type_check CHECK ((resolution_type = ANY (ARRAY['explained'::text, 'found'::text, 'recovered'::text, 'corrected_entry'::text, 'written_off'::text]))),
    CONSTRAINT discrepancies_status_check CHECK ((status = ANY (ARRAY['open'::text, 'under_review'::text, 'resolved'::text, 'written_off'::text])))
);

ALTER TABLE ONLY gold.discrepancies FORCE ROW LEVEL SECURITY;


--
-- Name: discrepancy_summary(gold.discrepancies); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.discrepancy_summary(d gold.discrepancies) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'id', d.id, 'branchId', d.branch_id, 'branchName', (select name from gold.branches b where b.id = d.branch_id),
    'kind', d.kind, 'asset', d.asset, 'status', d.status,
    'expected', gold.ts(d.expected), 'actual', gold.ts(d.actual), 'difference', gold.ts(d.difference),
    'reportedExplanation', d.reported_explanation,
    'businessDate', (select business_date from gold.business_days x where x.id = d.business_day_id),
    'dayId', d.business_day_id,
    'transferId', d.transfer_id, 'transferReference', (select reference from gold.transfers t where t.id = d.transfer_id),
    'openedAt', gold.iso(d.opened_at), 'openedBy', case when d.opened_by is null then null else gold.person_json(d.opened_by) end,
    'assignedTo', case when d.assigned_to is null then null else gold.person_json(d.assigned_to) end,
    'resolvedAt', case when d.resolved_at is null then null else gold.iso(d.resolved_at) end,
    'resolvedBy', case when d.resolved_by is null then null else gold.person_json(d.resolved_by) end,
    'resolutionType', d.resolution_type, 'resolutionSummary', d.resolution_summary)
$$;


--
-- Name: effective_permissions(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.effective_permissions(p_user uuid) RETURNS SETOF text
    LANGUAGE sql STABLE
    AS $$
  select p.permission
  from (
    select rp.permission
    from gold.users u
    join gold.role_permissions rp on rp.role_id = u.role_id and rp.tenant_id = u.tenant_id
    where u.id = p_user
    union
    select o.permission from gold.user_permission_overrides o where o.user_id = p_user and o.effect = 'allow'
  ) p
  where not exists (
    select 1 from gold.user_permission_overrides d
    where d.user_id = p_user and d.effect = 'deny' and d.permission = p.permission
  )
  order by 1
$$;


--
-- Name: ensure_customer(uuid, text, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.ensure_customer(p_id uuid, p_name text, p_phone text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare v_phone text := nullif(regexp_replace(coalesce(p_phone, ''), '\s', '', 'g'), ''); v_id uuid;
begin
  if p_id is not null then
    if exists (select 1 from gold.customers where id = p_id) then return p_id; end if;
    -- A new customer made on a device with its own id (it may have been offline). Needs a phone so they can be found again.
    if v_phone is null or not gold.has_text(p_name, 1) then perform gold.fail(404, 'NOT_FOUND', 'Customer was not found.'); end if;
    select id into v_id from gold.customers where lower(name) = lower(trim(p_name)) and phone = v_phone limit 1;
    if v_id is not null then return v_id; end if;   -- another branch or device already added the same person
    insert into gold.customers (id, tenant_id, name, phone, created_by) values (p_id, gold.current_tenant(), trim(p_name), v_phone, gold.current_actor());
    return p_id;
  end if;
  if v_phone is null then return null; end if;
  select id into v_id from gold.customers where lower(name) = lower(trim(p_name)) and phone = v_phone limit 1;
  if v_id is null then
    insert into gold.customers (tenant_id, name, phone, created_by) values (gold.current_tenant(), trim(p_name), v_phone, gold.current_actor())
    returning id into v_id;
  end if;
  return v_id;
end $$;


--
-- Name: ensure_customer(uuid, text, text, boolean); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.ensure_customer(p_id uuid, p_name text, p_phone text, p_create boolean) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare v_phone text := nullif(regexp_replace(coalesce(p_phone, ''), '\s', '', 'g'), ''); v_id uuid;
begin
  if p_create then return gold.ensure_customer(p_id, p_name, p_phone); end if;
  if p_id is not null and exists (select 1 from gold.customers where id = p_id) then return p_id; end if;
  if v_phone is null or not gold.has_text(p_name, 1) then return null; end if;
  select id into v_id from gold.customers where lower(name) = lower(trim(p_name)) and phone = v_phone limit 1;
  return v_id;
end $$;


--
-- Name: exchanges_json(uuid, integer); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.exchanges_json(p_branch uuid, p_limit integer DEFAULT 20) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(x.j order by x.at desc), '[]'::jsonb) from (
    select m.occurred_at as at, gold.movement_json(m.id) || jsonb_build_object('branchId', m.branch_id,
             'value', gold.ts(gold.lines_total(gold.lines_json('drawer_movement', m.id)) / 2)) as j
    from gold.drawer_movements m
    where m.branch_id = p_branch and m.kind = 'exchange' and m.transaction_id is null
    order by m.occurred_at desc limit greatest(1, least(coalesce(p_limit, 20), 100))
  ) x
$$;


--
-- Name: expect_json(uuid, uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.expect_json(p_town uuid, p_customer uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare v_town jsonb := null; v_cust jsonb := null; v_items uuid[]; v_name text;
begin
  if p_town is not null then
    select name into v_name from gold.origin_towns where id = p_town;
    if v_name is not null then
      select coalesce(array_agg(i.id), '{}') into v_items from gold.transaction_items i join gold.transactions t on t.id = i.transaction_id
      where t.origin_town_id = p_town and t.status <> 'void';
      v_town := gold.karat_stats_json(v_items) || jsonb_build_object('id', p_town, 'name', v_name);
    end if;
  end if;
  if p_customer is not null then
    select coalesce(array_agg(i.id), '{}') into v_items from gold.transaction_items i join gold.transactions t on t.id = i.transaction_id
    where t.customer_id = p_customer and t.status <> 'void';
    v_cust := gold.karat_stats_json(v_items) || jsonb_build_object('id', p_customer);
  end if;
  return jsonb_build_object('town', v_town, 'customer', v_cust);
end $$;


--
-- Name: fail(integer, text, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.fail(p_status integer, p_code text, p_message text) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  raise exception '%|%', p_code, p_message using errcode = 'GV' || lpad(p_status::text, 3, '0');
end $$;


--
-- Name: feed_apply(numeric, timestamp with time zone, jsonb, uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.feed_apply(p_base numeric, p_published timestamp with time zone, p_raw jsonb, p_actor uuid) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare v_tenant uuid := gold.current_tenant(); v_snap uuid; v_policy text;
begin
  select margin_policy into v_policy from gold.price_feed_settings where tenant_id = v_tenant;
  v_policy := coalesce(v_policy, 'approve');
  insert into gold.price_snapshots (tenant_id, source, base_price, published_at, raw, created_by)
  values (v_tenant, 'goldbod', p_base, least(p_published, now()), p_raw, p_actor) returning id into v_snap;
  perform gold.carry_branch_prices(v_snap, p_actor, v_policy = 'carry');
  return v_snap;
end $$;


--
-- Name: feed_decide(uuid, boolean); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.feed_decide(p_event uuid, p_accept boolean) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare v_user uuid := gold.require_actor(); e gold.price_feed_events;
begin
  select * into e from gold.price_feed_events where id = p_event and kind = 'held' for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That price was not found.'); end if;
  if e.state <> 'pending' then perform gold.fail(409, 'ALREADY_DECIDED', 'This price was already decided.'); end if;
  if p_accept then
    if not exists (select 1 from gold.price_snapshots where source = 'goldbod' and published_at = e.published_at) then
      perform gold.feed_apply(e.base_price, e.published_at, jsonb_build_object('acceptedHeld', true, 'usdPerOunce', e.usd_per_ounce, 'rate', e.rate), v_user);
    end if;
  end if;
  update gold.price_feed_events set state = case when p_accept then 'accepted' else 'dismissed' end, decided_by = v_user, decided_at = now() where id = p_event;
  return gold.price_feed_json();
end $$;


--
-- Name: feed_missed_check(timestamp with time zone); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.feed_missed_check(p_now timestamp with time zone) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant(); v_actor uuid := gold.require_actor(); s gold.price_feed_settings; w jsonb;
  v_local timestamp; v_start timestamp; v_end timestamp; v_best_start timestamp; v_best_end timestamp; v_msg text;
  v_start_ts timestamptz; v_end_ts timestamptz;
begin
  select * into s from gold.price_feed_settings where tenant_id = v_tenant and enabled;
  if not found then return jsonb_build_object('result', 'off'); end if;
  v_local := p_now at time zone s.timezone;
  if not (extract(isodow from v_local)::smallint = any(s.weekdays)) then return jsonb_build_object('result', 'not a price day'); end if;
  for w in select * from jsonb_array_elements(s.windows) loop
    v_start := date_trunc('day', v_local) + (w->>'start')::time;
    v_end := date_trunc('day', v_local) + (w->>'end')::time;
    if v_end <= v_local and (v_best_end is null or v_end > v_best_end) then v_best_start := v_start; v_best_end := v_end; end if;
  end loop;
  if v_best_end is null then return jsonb_build_object('result', 'no window has ended'); end if;
  v_start_ts := v_best_start at time zone s.timezone;
  v_end_ts := v_best_end at time zone s.timezone;
  -- anything recorded since the window began means someone has already been told, or a price arrived
  if exists (select 1 from gold.price_feed_events where tenant_id = v_tenant and at >= v_start_ts) then return jsonb_build_object('result', 'something happened'); end if;
  if exists (select 1 from gold.price_snapshots where source = 'goldbod' and fetched_at >= v_start_ts) then return jsonb_build_object('result', 'price captured'); end if;
  v_msg := format('No new GoldBod price was found between %s and %s. Branches are still using the last price. Check the website, or set the price by hand.',
                  to_char(v_best_start, 'HH24:MI'), to_char(v_best_end, 'HH24:MI'));
  insert into gold.price_feed_events (tenant_id, at, kind, state, message) values (v_tenant, p_now, 'missed', 'done', v_msg);
  perform set_config('app.user_id', '', true);
  perform gold.notify(v_tenant, 'price_feed_missed', 'No new GoldBod price this time', v_msg, '/prices/feed', null, 'prices:approve');
  perform set_config('app.user_id', v_actor::text, true);
  return jsonb_build_object('result', 'missed');
end $$;


--
-- Name: feed_record(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.feed_record(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant(); v_actor uuid := gold.require_actor(); v_kind text := p->>'kind'; v_base numeric := (p->>'basePrice')::numeric;
  v_pub timestamptz := (p->>'publishedAt')::timestamptz; v_msg text := left(coalesce(p->>'message', ''), 500); v_snap uuid; v_prev text; v_prev_at timestamptz;
begin
  if v_kind not in ('unchanged', 'applied', 'held', 'failed') then perform gold.fail(422, 'VALIDATION_FAILED', 'Unknown result.'); end if;
  update gold.price_feed_settings set last_checked_at = now(), last_result = v_msg where tenant_id = v_tenant;
  -- The signed-in "actor" here is only the director whose name the automatic price is recorded under. Everyone who can approve prices,
  -- that director included, should hear about it, so notifications are sent as if nobody had acted.
  perform set_config('app.user_id', '', true);

  if v_kind = 'applied' then
    if exists (select 1 from gold.price_snapshots where source = 'goldbod' and published_at = v_pub) then
      perform set_config('app.user_id', v_actor::text, true);
      return jsonb_build_object('result', 'unchanged');
    end if;
    v_snap := gold.feed_apply(v_base, v_pub, p - 'excerpt', v_actor);
    insert into gold.price_feed_events (tenant_id, kind, state, message, base_price, published_at, usd_per_ounce, rate, discount_pct, computed)
    values (v_tenant, 'applied', 'done', v_msg, v_base, v_pub, (p->>'usdPerOunce')::numeric, (p->>'rate')::numeric, (p->>'discountPct')::numeric, (p->>'computed')::numeric);
  elsif v_kind = 'held' then
    -- Once a price has been held, it is the director's to decide: whatever the answer was (still waiting, accepted, dismissed), the same
    -- price is not held and announced again at the next look.
    if not exists (select 1 from gold.price_feed_events where kind = 'held' and base_price = v_base and published_at is not distinct from v_pub) then
      insert into gold.price_feed_events (tenant_id, kind, state, message, base_price, published_at, usd_per_ounce, rate, discount_pct, computed, excerpt)
      values (v_tenant, 'held', 'pending', v_msg, v_base, v_pub, (p->>'usdPerOunce')::numeric, (p->>'rate')::numeric, (p->>'discountPct')::numeric, (p->>'computed')::numeric, left(p->>'excerpt', 1500));
      perform gold.notify(v_tenant, 'price_held', 'A GoldBod price needs your confirmation', v_msg, '/prices/feed', null, 'prices:approve');
    end if;
  elsif v_kind = 'failed' then
    select kind, at into v_prev, v_prev_at from gold.price_feed_events where tenant_id = v_tenant order by at desc limit 1;
    -- Told once when it starts failing, and again if it is still failing three hours later.
    if v_prev is distinct from 'failed' or v_prev_at < now() - interval '3 hours' then
      insert into gold.price_feed_events (tenant_id, kind, state, message, excerpt) values (v_tenant, 'failed', 'done', v_msg, left(p->>'excerpt', 1500));
      perform gold.notify(v_tenant, 'price_feed_failed', 'The automatic price could not be read', v_msg || ' Set the price by hand if you need it now.', '/prices/feed', null, 'prices:approve');
    end if;
  end if;
  perform set_config('app.user_id', v_actor::text, true);
  return jsonb_build_object('result', v_kind, 'snapshotId', v_snap);
end $$;


--
-- Name: forbid_mutation(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.forbid_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  raise exception '% on gold.% is not allowed: this table is append-only', tg_op, tg_table_name
    using errcode = 'integrity_constraint_violation';
end $$;


--
-- Name: guide_admin_json(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_admin_json() RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare v_user uuid := gold.require_actor(); v_staff int;
begin
  select count(*) into v_staff from gold.users where is_active;
  return jsonb_build_object(
    'staff', v_staff,
    'categories', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'name', c.name, 'position', c.position) order by c.position, c.name) from gold.guide_categories c), '[]'::jsonb),
    'articles', coalesce((select jsonb_agg(gold.guide_article_row(a, v_user) || jsonb_build_object(
        'readers', (select count(*) from gold.guide_reads r join gold.users u on u.id = r.user_id and u.is_active where r.article_id = a.id and r.version >= a.version)
      ) order by a.position, a.updated_at desc) from gold.guide_articles a), '[]'::jsonb),
    'reminders', gold.guide_reminders_json());
end $$;


--
-- Name: guide_article_json(uuid, boolean); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_article_json(p_id uuid, p_include_draft boolean DEFAULT false) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare v_user uuid := gold.require_actor(); a gold.guide_articles;
begin
  select * into a from gold.guide_articles where id = p_id and (status = 'published' or p_include_draft);
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That article was not found.'); end if;
  return gold.guide_article_row(a, v_user) || jsonb_build_object('blocks', a.blocks);
end $$;


--
-- Name: guide_articles; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.guide_articles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    category_id uuid,
    title text NOT NULL,
    summary text,
    kind text DEFAULT 'rule'::text NOT NULL,
    blocks jsonb DEFAULT '[]'::jsonb NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    rev integer DEFAULT 1 NOT NULL,
    must_read boolean DEFAULT true NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    published_at timestamp with time zone,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT guide_articles_blocks_check CHECK ((jsonb_typeof(blocks) = 'array'::text)),
    CONSTRAINT guide_articles_kind_check CHECK ((kind = ANY (ARRAY['rule'::text, 'dos_donts'::text, 'howto'::text, 'info'::text]))),
    CONSTRAINT guide_articles_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text]))),
    CONSTRAINT guide_articles_summary_check CHECK (((summary IS NULL) OR (char_length(summary) <= 240))),
    CONSTRAINT guide_articles_title_check CHECK (((char_length(TRIM(BOTH FROM title)) >= 3) AND (char_length(TRIM(BOTH FROM title)) <= 120)))
);

ALTER TABLE ONLY gold.guide_articles FORCE ROW LEVEL SECURITY;


--
-- Name: guide_article_row(gold.guide_articles, uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_article_row(a gold.guide_articles, p_user uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'id', a.id, 'categoryId', a.category_id, 'title', a.title, 'summary', a.summary, 'kind', a.kind, 'status', a.status,
    'version', a.version, 'rev', a.rev, 'mustRead', a.must_read, 'position', a.position,
    'publishedAt', gold.iso(a.published_at), 'updatedAt', gold.iso(a.updated_at),
    'read', exists (select 1 from gold.guide_reads r where r.article_id = a.id and r.user_id = p_user and r.version >= a.version),
    'readAt', (select gold.iso(r.read_at) from gold.guide_reads r where r.article_id = a.id and r.user_id = p_user))
$$;


--
-- Name: guide_check_blocks(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_check_blocks(b jsonb) RETURNS void
    LANGUAGE plpgsql IMMUTABLE
    AS $_$
declare x jsonb; i jsonb; v_images int := 0;
begin
  if jsonb_typeof(b) <> 'array' then perform gold.fail(422, 'VALIDATION_FAILED', 'The content must be a list of blocks.'); end if;
  if jsonb_array_length(b) > 80 then perform gold.fail(422, 'VALIDATION_FAILED', 'Too many blocks in one article (80 at most). Split it into two.'); end if;
  if length(b::text) > 6000000 then perform gold.fail(422, 'VALIDATION_FAILED', 'This article is too large. Use fewer or smaller pictures.'); end if;
  for x in select * from jsonb_array_elements(b) loop
    if jsonb_typeof(x) <> 'object' then perform gold.fail(422, 'VALIDATION_FAILED', 'A block is not valid.'); end if;
    case x->>'type'
      when 'heading', 'text' then
        if char_length(coalesce(x->>'text', '')) > 5000 then perform gold.fail(422, 'VALIDATION_FAILED', 'A piece of text is too long (5000 characters at most).'); end if;
      when 'list' then
        if (x->>'style') not in ('bullets', 'numbers', 'dos', 'donts') or jsonb_typeof(x->'items') <> 'array' or jsonb_array_length(x->'items') > 50 then
          perform gold.fail(422, 'VALIDATION_FAILED', 'A list is not valid.'); end if;
      when 'callout' then
        if (x->>'tone') not in ('info', 'warning', 'danger', 'success') or char_length(coalesce(x->>'text', '')) > 3000 then
          perform gold.fail(422, 'VALIDATION_FAILED', 'A callout is not valid.'); end if;
      when 'image' then
        v_images := v_images + 1;
        if coalesce(x->>'src', '') !~ '^data:image/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$' then
          perform gold.fail(422, 'VALIDATION_FAILED', 'Only PNG, JPEG, WebP or GIF pictures can be added.'); end if;
        if length(x->>'src') > 2500000 then perform gold.fail(422, 'VALIDATION_FAILED', 'A picture is too large. Use a smaller one.'); end if;
      when 'flow' then
        if jsonb_typeof(x->'nodes') <> 'array' or jsonb_array_length(x->'nodes') > 40 then perform gold.fail(422, 'VALIDATION_FAILED', 'A flowchart is not valid.'); end if;
        for i in select * from jsonb_array_elements(x->'nodes') loop
          if (i->>'kind') not in ('step', 'decision', 'end') then perform gold.fail(422, 'VALIDATION_FAILED', 'A flowchart step is not valid.'); end if;
        end loop;
      when 'divider' then null;
      else perform gold.fail(422, 'VALIDATION_FAILED', 'Unknown kind of block: ' || coalesce(x->>'type', '(none)'));
    end case;
  end loop;
  if v_images > 12 then perform gold.fail(422, 'VALIDATION_FAILED', 'Too many pictures in one article (12 at most).'); end if;
end $_$;


--
-- Name: guide_delete_article(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_delete_article(p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare a gold.guide_articles;
begin
  delete from gold.guide_articles where id = p_id returning * into a;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That article was not found.'); end if;
  perform gold.audit('guide.article_deleted', 'guide_article', p_id::text, jsonb_build_object('title', a.title), null);
  perform gold.publish(gold.current_tenant(), 'guide', null);
  return jsonb_build_object('id', p_id);
end $$;


--
-- Name: guide_delete_category(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_delete_category(p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare c gold.guide_categories;
begin
  select * into c from gold.guide_categories where id = p_id;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That category was not found.'); end if;
  if exists (select 1 from gold.guide_articles where category_id = p_id) then
    perform gold.fail(409, 'NOT_EMPTY', 'Move or delete the articles in this category first.'); end if;
  delete from gold.guide_categories where id = p_id;
  perform gold.audit('guide.category_deleted', 'guide_category', p_id::text, jsonb_build_object('name', c.name), null);
  return jsonb_build_object('id', p_id);
end $$;


--
-- Name: guide_json(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_json() RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare v_user uuid := gold.require_actor();
begin
  return jsonb_build_object(
    'unread', gold.guide_unread_count(v_user),
    'categories', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'name', c.name, 'position', c.position) order by c.position, c.name) from gold.guide_categories c), '[]'::jsonb),
    'articles', coalesce((select jsonb_agg(gold.guide_article_row(a, v_user) order by a.position, a.published_at desc) from gold.guide_articles a where a.status = 'published'), '[]'::jsonb));
end $$;


--
-- Name: guide_mark_read(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_mark_read(p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare v_user uuid := gold.require_actor(); a gold.guide_articles;
begin
  select * into a from gold.guide_articles where id = p_id and status = 'published';
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That article was not found.'); end if;
  insert into gold.guide_reads (tenant_id, article_id, user_id, version) values (gold.current_tenant(), a.id, v_user, a.version)
  on conflict (article_id, user_id) do update set version = excluded.version, read_at = now();
  return jsonb_build_object('unread', gold.guide_unread_count(v_user));
end $$;


--
-- Name: guide_publish(uuid, jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_publish(p_id uuid, p jsonb DEFAULT '{}'::jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  a gold.guide_articles; v_actor uuid := gold.require_actor(); v_notify boolean := coalesce((p->>'notify')::boolean, true);
  v_material boolean := coalesce((p->>'material')::boolean, false); v_was text; r record; v_n int := 0;
begin
  select * into a from gold.guide_articles where id = p_id for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That article was not found.'); end if;
  if jsonb_array_length(a.blocks) = 0 then perform gold.fail(422, 'VALIDATION_FAILED', 'Add some content before publishing.'); end if;
  v_was := a.status;
  update gold.guide_articles set status = 'published', published_at = coalesce(case when v_was = 'published' then published_at end, now()),
    version = case when v_was = 'published' and v_material then version + 1 else version end, updated_at = now(), updated_by = v_actor
    where id = p_id returning * into a;
  perform gold.audit('guide.article_published', 'guide_article', a.id::text, null, jsonb_build_object('title', a.title, 'version', a.version, 'notified', v_notify));
  if v_notify and (v_was <> 'published' or v_material) then
    for r in select id from gold.users where is_active and id <> v_actor loop
      perform gold.notify_user(gold.current_tenant(), r.id, case when v_was = 'published' then 'guide_updated' else 'guide_new' end,
        case when v_was = 'published' then 'Rules updated: ' || a.title else 'New to read: ' || a.title end,
        case when a.must_read then 'Please read this as soon as you can.' else null end, '/guide/' || a.id);
      v_n := v_n + 1;
    end loop;
  end if;
  perform gold.publish(gold.current_tenant(), 'guide', null);
  return gold.guide_article_row(a, v_actor) || jsonb_build_object('notified', v_n);
end $$;


--
-- Name: guide_readers_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_readers_json(p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare a gold.guide_articles;
begin
  select * into a from gold.guide_articles where id = p_id;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That article was not found.'); end if;
  return coalesce((select jsonb_agg(jsonb_build_object('userId', u.id, 'displayName', u.display_name,
      'read', coalesce(r.version >= a.version, false), 'readAt', gold.iso(r.read_at), 'readVersion', r.version) order by (coalesce(r.version >= a.version, false)), u.display_name)
    from gold.users u left join gold.guide_reads r on r.user_id = u.id and r.article_id = p_id where u.is_active), '[]'::jsonb);
end $$;


--
-- Name: guide_reminder_run(timestamp with time zone); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_reminder_run(p_now timestamp with time zone) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
  s gold.guide_settings; v_tz text; v_local timestamp; v_day date; n int := 0; r record; v_count int; v_published int;
begin
  select * into s from gold.guide_settings where tenant_id = gold.current_tenant();
  if not found or s.frequency = 'off' then return 0; end if;
  select timezone into v_tz from gold.branches order by is_main desc, created_at limit 1;
  v_local := p_now at time zone coalesce(v_tz, 'Africa/Accra'); v_day := v_local::date;
  if to_char(v_local, 'HH24:MI') < s.remind_time then return 0; end if;
  if s.last_sent_on is not null and s.last_sent_on >= v_day then return 0; end if;
  if s.frequency = 'weekly' and extract(isodow from v_day)::int <> s.weekday then return 0; end if;
  if s.frequency = 'monthly' and extract(day from v_day)::int <> 1 then return 0; end if;
  update gold.guide_settings set last_sent_on = v_day where tenant_id = s.tenant_id;
  select count(*) into v_published from gold.guide_articles where status = 'published';
  if v_published = 0 then return 0; end if;
  for r in select id from gold.users where is_active loop
    v_count := gold.guide_unread_count(r.id);
    if s.audience = 'unread' and v_count = 0 then continue; end if;
    perform gold.notify_user(s.tenant_id, r.id, 'guide_reminder', 'Time to read the business rules',
      case when v_count > 0 then format('%s still to read.', v_count) else 'A short refresh of how we work.' end, '/guide');
    n := n + 1;
  end loop;
  return n;
end $$;


--
-- Name: guide_reminders_json(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_reminders_json() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce((select jsonb_build_object('frequency', frequency, 'time', remind_time, 'weekday', weekday, 'audience', audience) from gold.guide_settings where tenant_id = gold.current_tenant()),
    jsonb_build_object('frequency', 'off', 'time', '08:00', 'weekday', 1, 'audience', 'unread'))
$$;


--
-- Name: guide_save_article(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_save_article(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_id uuid := coalesce((p->>'id')::uuid, gen_random_uuid()); a gold.guide_articles; v_actor uuid := gold.require_actor();
  v_title text := trim(coalesce(p->>'title', '')); v_blocks jsonb := coalesce(p->'blocks', '[]'::jsonb); v_cat uuid := nullif(p->>'categoryId', '')::uuid;
  v_kind text := coalesce(p->>'kind', 'rule');
begin
  if char_length(v_title) < 3 or char_length(v_title) > 120 then perform gold.fail(422, 'VALIDATION_FAILED', 'Give the article a title (3 to 120 letters).'); end if;
  if v_kind not in ('rule', 'dos_donts', 'howto', 'info') then perform gold.fail(422, 'VALIDATION_FAILED', 'Unknown kind of article.'); end if;
  if v_cat is not null and not exists (select 1 from gold.guide_categories where id = v_cat) then perform gold.fail(404, 'NOT_FOUND', 'That category was not found.'); end if;
  perform gold.guide_check_blocks(v_blocks);
  select * into a from gold.guide_articles where id = v_id for update;
  if found then
    if p ? 'rev' and (p->>'rev')::int is distinct from a.rev then
      perform gold.fail(409, 'EDIT_CONFLICT', 'Someone else changed this article while you were editing. Reload it to see their change before saving yours.');
    end if;
    update gold.guide_articles set category_id = case when p ? 'categoryId' then v_cat else category_id end, title = v_title, summary = nullif(trim(coalesce(p->>'summary', '')), ''), kind = v_kind,
      must_read = coalesce((p->>'mustRead')::boolean, must_read), blocks = v_blocks, rev = rev + 1, updated_by = v_actor, updated_at = now()
      where id = v_id returning * into a;
  else
    insert into gold.guide_articles (id, tenant_id, category_id, title, summary, kind, must_read, blocks, position, created_by, updated_by)
    values (v_id, gold.current_tenant(), v_cat, v_title, nullif(trim(coalesce(p->>'summary', '')), ''), v_kind, coalesce((p->>'mustRead')::boolean, true), v_blocks,
      (select coalesce(max(position), 0) + 1 from gold.guide_articles), v_actor, v_actor)
    returning * into a;
  end if;
  perform gold.audit('guide.article_saved', 'guide_article', a.id::text, null, jsonb_build_object('title', a.title, 'status', a.status, 'rev', a.rev));
  return gold.guide_article_row(a, v_actor) || jsonb_build_object('blocks', a.blocks);
end $$;


--
-- Name: guide_save_category(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_save_category(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare v_id uuid := coalesce((p->>'id')::uuid, gen_random_uuid()); v_name text := trim(coalesce(p->>'name', '')); c gold.guide_categories;
begin
  if char_length(v_name) < 2 or char_length(v_name) > 60 then perform gold.fail(422, 'VALIDATION_FAILED', 'Give the category a name (2 to 60 letters).'); end if;
  if exists (select 1 from gold.guide_categories where lower(trim(name)) = lower(v_name) and id <> v_id) then
    perform gold.fail(409, 'ALREADY_EXISTS', 'There is already a category with that name.'); end if;
  insert into gold.guide_categories (id, tenant_id, name, position) values (v_id, gold.current_tenant(), v_name, coalesce((p->>'position')::int, (select coalesce(max(position), 0) + 1 from gold.guide_categories)))
  on conflict (id) do update set name = excluded.name, position = case when p ? 'position' then excluded.position else gold.guide_categories.position end
  returning * into c;
  perform gold.audit('guide.category_saved', 'guide_category', c.id::text, null, jsonb_build_object('name', c.name));
  return jsonb_build_object('id', c.id, 'name', c.name, 'position', c.position);
end $$;


--
-- Name: guide_unpublish(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_unpublish(p_id uuid) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare a gold.guide_articles;
begin
  update gold.guide_articles set status = 'draft', updated_at = now() where id = p_id returning * into a;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That article was not found.'); end if;
  perform gold.audit('guide.article_unpublished', 'guide_article', a.id::text, null, jsonb_build_object('title', a.title));
  perform gold.publish(gold.current_tenant(), 'guide', null);
  return gold.guide_article_row(a, gold.require_actor());
end $$;


--
-- Name: guide_unread_count(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.guide_unread_count(p_user uuid) RETURNS integer
    LANGUAGE sql STABLE
    AS $$
  select count(*)::int from gold.guide_articles a
  where a.status = 'published' and a.must_read
    and not exists (select 1 from gold.guide_reads r where r.article_id = a.id and r.user_id = p_user and r.version >= a.version)
$$;


--
-- Name: import_batches_json(uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.import_batches_json(p_scope uuid[]) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(x.j order by x.at desc), '[]'::jsonb) from (
    select b.created_at as at, jsonb_build_object(
      'id', b.id, 'kind', b.kind, 'label', b.label, 'createdAt', gold.iso(b.created_at), 'createdBy', gold.person_json(b.created_by),
      'undone', b.undone_at is not null,
      'purchases', (select count(*) from gold.transactions t where t.imported_batch = b.id and t.status <> 'void'),
      'worth', gold.ts(coalesce((select sum(t.payable) from gold.transactions t where t.imported_batch = b.id and t.status <> 'void'), 0)),
      'from', (select min(t.captured_at)::date from gold.transactions t where t.imported_batch = b.id),
      'to', (select max(t.captured_at)::date from gold.transactions t where t.imported_batch = b.id)) as j
    from gold.import_batches b
    where b.kind = 'history'
      and (not exists (select 1 from gold.transactions t where t.imported_batch = b.id)
           or exists (select 1 from gold.transactions t where t.imported_batch = b.id and t.branch_id = any(coalesce(p_scope, '{}'))))
    union all
    select b.created_at, jsonb_build_object(
      'id', b.id, 'kind', b.kind, 'label', b.label, 'createdAt', gold.iso(b.created_at), 'createdBy', gold.person_json(b.created_by),
      'undone', b.undone_at is not null,
      'purchases', (select count(*) from gold.ledger_entries e where e.source_id = b.id and e.source_type = 'go_live_balance')
                 + (select count(*) from gold.debts d where d.imported_batch = b.id),
      'worth', gold.ts(coalesce((select sum(e.delta_value) from gold.ledger_entries e where e.source_id = b.id and e.source_type = 'go_live_balance'), 0)
                     + coalesce((select sum(d.principal) from gold.debts d where d.imported_batch = b.id), 0)),
      'from', null, 'to', null)
    from gold.import_batches b
    where b.kind = 'opening'
      and (exists (select 1 from gold.ledger_entries e where e.source_id = b.id and e.source_type = 'go_live_balance' and e.branch_id = any(coalesce(p_scope, '{}')))
           or exists (select 1 from gold.debts d where d.imported_batch = b.id and d.branch_id = any(coalesce(p_scope, '{}'))))
  ) x
$$;


--
-- Name: import_customers(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.import_customers(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant(); v_user uuid := gold.require_actor(); r jsonb; v_id uuid; v_before int; v_created int := 0; v_existing int := 0;
  v_name text; v_phone text;
begin
  if jsonb_typeof(p->'rows') <> 'array' or jsonb_array_length(p->'rows') not between 1 and 1000 then
    perform gold.fail(422, 'VALIDATION_FAILED', 'Send 1 to 1000 rows at a time.');
  end if;
  for r in select * from jsonb_array_elements(p->'rows') loop
    v_name := trim(coalesce(r->>'name', ''));
    v_phone := nullif(regexp_replace(coalesce(r->>'phone', ''), '\s', '', 'g'), '');
    if not gold.has_text(v_name, 1) or v_phone is null then
      perform gold.fail(422, 'VALIDATION_FAILED', 'Every customer needs a name and a phone number.');
    end if;
    select count(*) into v_before from gold.customers;
    v_id := gold.ensure_customer(null, v_name, v_phone);
    if (select count(*) from gold.customers) > v_before then
      v_created := v_created + 1;
      update gold.customers set notes = nullif(trim(coalesce(r->>'notes', '')), '') where id = v_id;
    else v_existing := v_existing + 1; end if;
  end loop;
  return jsonb_build_object('created', v_created, 'existing', v_existing);
end $$;


--
-- Name: import_history(jsonb, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.import_history(p jsonb, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant(); v_user uuid := gold.require_actor(); v_batch uuid := (p->>'batchId')::uuid;
  r jsonb; b gold.branches; v_id uuid; v_at timestamptz; v_local date; v_n int; v_ref text; v_customer uuid; v_name text; v_phone text;
  v_flags text[]; v_created int := 0; v_skipped int := 0; v_out jsonb := '[]'::jsonb; v_payable numeric;
begin
  if v_batch is null then perform gold.fail(422, 'VALIDATION_FAILED', 'A batch id is needed.'); end if;
  if jsonb_typeof(p->'rows') <> 'array' or jsonb_array_length(p->'rows') not between 1 and 500 then
    perform gold.fail(422, 'VALIDATION_FAILED', 'Send 1 to 500 rows at a time.');
  end if;
  insert into gold.import_batches (id, tenant_id, kind, label, created_by) values (v_batch, v_tenant, 'history', nullif(trim(coalesce(p->>'label', '')), ''), v_user)
    on conflict (id) do nothing;
  if exists (select 1 from gold.import_batches where id = v_batch and (kind <> 'history' or undone_at is not null)) then
    perform gold.fail(409, 'BATCH_CLOSED', 'This import was undone or is not a purchases import. Start a new one.');
  end if;

  for r in select * from jsonb_array_elements(p->'rows') loop
    perform gold.in_scope((r->>'branchId')::uuid, p_scope);
    select * into b from gold.branches where id = (r->>'branchId')::uuid and is_active;
    if not found then perform gold.fail(404, 'NOT_FOUND', 'Branch was not found.'); end if;
    if exists (select 1 from gold.transactions where imported_batch = v_batch and import_key = r->>'key') then
      v_skipped := v_skipped + 1;
      v_out := v_out || jsonb_build_object('key', r->>'key', 'status', 'exists');
      continue;
    end if;
    v_at := (r->>'capturedAt')::timestamptz;
    if v_at is null or v_at > now() then perform gold.fail(422, 'VALIDATION_FAILED', 'Row ' || (r->>'key') || ': the date must be in the past.'); end if;
    v_name := trim(coalesce(r#>>'{customer,name}', ''));
    if not gold.has_text(v_name, 1) then perform gold.fail(422, 'VALIDATION_FAILED', 'Row ' || (r->>'key') || ': the customer name is missing.'); end if;
    v_phone := nullif(regexp_replace(coalesce(r#>>'{customer,phone}', ''), '\s', '', 'g'), '');
    if not exists (select 1 from gold.formula_versions where key = r->>'formulaVersion') then
      perform gold.fail(409, 'FORMULA_NOT_CONFIGURED', 'The calculation settings are missing for this company. Run the seed command.');
    end if;
    v_payable := (r->>'payable')::numeric;
    if v_payable is null or v_payable < 0 then perform gold.fail(422, 'VALIDATION_FAILED', 'Row ' || (r->>'key') || ': the amount paid is not valid.'); end if;

    v_customer := gold.ensure_customer(null, v_name, v_phone);
    v_local := (v_at at time zone b.timezone)::date;
    v_n := gold.next_document_number(v_tenant, 'history', b.id, v_local);
    v_ref := b.code || '-H' || to_char(v_local, 'YYYYMMDD') || '-' || lpad(v_n::text, 4, '0');
    v_flags := array['HISTORICAL'] || coalesce(array(select jsonb_array_elements_text(coalesce(r->'flags', '[]'::jsonb))), '{}');
    v_id := gen_random_uuid();

    insert into gold.transactions (id, tenant_id, branch_id, business_day_id, reference, customer_id, customer_name, customer_phone, status, formula_version,
                                   price_as_of, client_amount, calculated_amount, payout_policy, payout_strategy, payable, payout_difference, captured_at,
                                   created_by, flags, imported_batch, import_key, import_ref, import_note)
    values (v_id, v_tenant, b.id, null, v_ref, v_customer, v_name, v_phone, 'saved', r->>'formulaVersion', v_at,
            coalesce((r->>'clientAmount')::numeric, (r->>'calculatedAmount')::numeric), (r->>'calculatedAmount')::numeric, 'down', 'fewest-notes', v_payable,
            v_payable - (r->>'calculatedAmount')::numeric, v_at, v_user, v_flags, v_batch, r->>'key',
            nullif(trim(coalesce(r->>'receiptNo', '')), ''), nullif(trim(coalesce(r->>'note', '')), ''));

    insert into gold.transaction_items (id, tenant_id, transaction_id, line_no, label, top, down, price, density, karat, purity, net_weight, pounds, amount,
                                        location_branch_id, location_state)
    select gen_random_uuid(), v_tenant, v_id, ord::smallint, nullif(trim(coalesce(i->>'label', '')), ''), (i->>'top')::numeric, (i->>'down')::numeric,
           (i->>'price')::numeric, (i->>'density')::numeric, (i->>'karat')::numeric, (i->>'purity')::numeric, (i->>'netWeight')::numeric,
           (i->>'pounds')::numeric, (i->>'amount')::numeric, b.id, 'historical'
    from jsonb_array_elements(r->'items') with ordinality as t(i, ord);

    v_created := v_created + 1;
    v_out := v_out || jsonb_build_object('key', r->>'key', 'status', 'created', 'reference', v_ref);
  end loop;
  return jsonb_build_object('created', v_created, 'skipped', v_skipped, 'rows', v_out);
end $$;


--
-- Name: import_opening(jsonb, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.import_opening(p jsonb, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant(); v_user uuid := gold.require_actor(); v_batch uuid := (p->>'batchId')::uuid;
  v_as_of timestamptz := (p->>'asOf')::timestamptz; r jsonb; b gold.branches; v_goods int := 0; v_debts int := 0; v_customer uuid; v_id uuid;
  v_name text; v_type text; v_amount numeric; v_at timestamptz; v_top numeric; v_down numeric; v_value numeric;
begin
  if v_batch is null or v_as_of is null then perform gold.fail(422, 'VALIDATION_FAILED', 'A batch id and the go-live date are needed.'); end if;
  if v_as_of > now() then perform gold.fail(422, 'VALIDATION_FAILED', 'The go-live date must not be in the future.'); end if;
  if jsonb_typeof(p->'rows') <> 'array' or jsonb_array_length(p->'rows') not between 1 and 1000 then
    perform gold.fail(422, 'VALIDATION_FAILED', 'Send 1 to 1000 rows.');
  end if;
  if exists (select 1 from gold.import_batches where id = v_batch) then
    return jsonb_build_object('alreadyApplied', true, 'goods', 0, 'debts', 0);
  end if;
  insert into gold.import_batches (id, tenant_id, kind, label, created_by) values (v_batch, v_tenant, 'opening', nullif(trim(coalesce(p->>'label', '')), ''), v_user);

  for r in select * from jsonb_array_elements(p->'rows') loop
    perform gold.in_scope((r->>'branchId')::uuid, p_scope);
    select * into b from gold.branches where id = (r->>'branchId')::uuid and is_active;
    if not found then perform gold.fail(404, 'NOT_FOUND', 'Branch was not found.'); end if;

    if r->>'kind' = 'goods' then
      v_top := (r->>'top')::numeric; v_down := (r->>'down')::numeric; v_value := (r->>'value')::numeric;
      if v_top is null or v_top <= 0 or v_down is null or v_down < 0 or v_value is null or v_value < 0 then
        perform gold.fail(422, 'VALIDATION_FAILED', b.name || ': the gold needs a top weight above zero, a down weight and a value.');
      end if;
      if exists (select 1 from gold.ledger_entries e where e.branch_id = b.id and e.asset = 'goods' and e.source_type = 'go_live_balance'
                   and not exists (select 1 from gold.ledger_entries x where x.reverses_entry_id = e.id)) then
        perform gold.fail(409, 'ALREADY_SET', b.name || ' already has its opening gold. Undo that import first.');
      end if;
      perform gold.post_goods(b.id, null, v_as_of, v_top, v_down, v_value, 'go_live_balance', v_batch, coalesce(nullif(trim(r->>'note'), ''), 'Opening gold'));
      v_goods := v_goods + 1;

    elsif r->>'kind' = 'debt' then
      v_name := trim(coalesce(r->>'partyName', ''));
      v_type := coalesce(nullif(r->>'partyType', ''), 'customer');
      v_amount := (r->>'amount')::numeric;
      v_at := least(coalesce((r->>'issuedAt')::timestamptz, v_as_of), v_as_of);
      if not gold.has_text(v_name, 1) then perform gold.fail(422, 'VALIDATION_FAILED', 'Every debt needs the name of who owes.'); end if;
      if v_type not in ('customer', 'staff', 'other') then perform gold.fail(422, 'VALIDATION_FAILED', v_name || ': unknown party type.'); end if;
      if v_amount is null or v_amount <= 0 then perform gold.fail(422, 'VALIDATION_FAILED', v_name || ': the amount owed must be above zero.'); end if;
      v_customer := gold.ensure_customer(null, v_name, r->>'phone');
      if v_type = 'customer' and v_customer is null then
        perform gold.fail(422, 'CUSTOMER_REQUIRED', v_name || ': a phone number is needed for a customer.');
      end if;
      v_id := gen_random_uuid();
      insert into gold.debts (id, tenant_id, branch_id, customer_id, party_name, party_type, principal, reason, issued_at, issued_by, due_date, direction, imported_batch)
      values (v_id, v_tenant, b.id, v_customer, v_name, v_type, v_amount, coalesce(nullif(trim(r->>'reason'), ''), 'Opening balance'), v_at, v_user,
              nullif(r->>'dueDate', '')::date, 'receivable', v_batch);
      perform gold.post_value('debt', b.id, null, v_at, v_amount, 'go_live_balance', v_id, 'Opening balance: owed by ' || v_name);
      v_debts := v_debts + 1;
    else
      perform gold.fail(422, 'VALIDATION_FAILED', 'Each row is either gold or a debt.');
    end if;
  end loop;
  return jsonb_build_object('alreadyApplied', false, 'goods', v_goods, 'debts', v_debts);
end $$;


--
-- Name: import_undo(uuid, text, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.import_undo(p_batch uuid, p_reason text, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare v_user uuid := gold.require_actor(); b gold.import_batches; n int; v_ids uuid[];
begin
  select * into b from gold.import_batches where id = p_batch and kind in ('history', 'opening') for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That import was not found.'); end if;
  if b.undone_at is not null then perform gold.fail(409, 'ALREADY_UNDONE', 'This import was already undone.'); end if;
  if not gold.has_text(p_reason, 5) then perform gold.fail(422, 'VALIDATION_FAILED', 'Say why (at least 5 characters).'); end if;

  if b.kind = 'history' then
    if exists (select 1 from gold.transactions t where t.imported_batch = p_batch and not (t.branch_id = any(coalesce(p_scope, '{}')))) then
      perform gold.fail(403, 'FORBIDDEN', 'This import includes branches you do not work at.');
    end if;
    update gold.transactions set status = 'void', voided_at = now(), voided_by = v_user, void_reason = 'Import undone: ' || trim(p_reason)
     where imported_batch = p_batch and status <> 'void';
    get diagnostics n = row_count;
  else
    if exists (select 1 from gold.ledger_entries e where e.source_id = p_batch and e.source_type = 'go_live_balance' and not (e.branch_id = any(coalesce(p_scope, '{}'))))
       or exists (select 1 from gold.debts d where d.imported_batch = p_batch and not (d.branch_id = any(coalesce(p_scope, '{}')))) then
      perform gold.fail(403, 'FORBIDDEN', 'This import includes branches you do not work at.');
    end if;
    if exists (select 1 from gold.debt_repayments r join gold.debts d on d.id = r.debt_id where d.imported_batch = p_batch) then
      perform gold.fail(409, 'ALREADY_IN_USE', 'A debt from this import has already been repaid, so it cannot be undone.');
    end if;
    select coalesce(array_agg(id), '{}') into v_ids from gold.debts where imported_batch = p_batch;
    insert into gold.ledger_entries (tenant_id, branch_id, business_day_id, occurred_at, recorded_by, asset, delta_top, delta_down, delta_value,
                                     source_type, source_id, memo, reverses_entry_id)
    select e.tenant_id, e.branch_id, null, now(), v_user, e.asset, -e.delta_top, -e.delta_down, -e.delta_value, 'reversal', e.source_id,
           'Opening balance import undone: ' || trim(p_reason), e.id
      from gold.ledger_entries e
     where e.source_type = 'go_live_balance' and (e.source_id = p_batch or e.source_id = any(v_ids))
       and not exists (select 1 from gold.ledger_entries x where x.reverses_entry_id = e.id);
    get diagnostics n = row_count;
    update gold.debts set status = 'written_off', closed_at = now(), closed_by = v_user, close_reason = 'Opening balance import undone: ' || trim(p_reason)
     where imported_batch = p_batch and status = 'open';
  end if;
  update gold.import_batches set undone_at = now(), undone_by = v_user where id = p_batch;
  return jsonb_build_object('voided', n);
end $$;


--
-- Name: in_scope(uuid, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.in_scope(p_branch uuid, p_scope uuid[]) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  if p_branch is null or not (p_branch = any(coalesce(p_scope, '{}'))) then
    perform gold.fail(403, 'FORBIDDEN', 'You do not work at that branch.');
  end if;
end $$;


--
-- Name: interbranch_position_json(uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.interbranch_position_json(p_scope uuid[]) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(jsonb_build_object(
    'senderBranchId', v.sender_branch_id, 'senderName', (select name from gold.branches b where b.id = v.sender_branch_id),
    'receiverBranchId', v.receiver_branch_id, 'receiverName', (select name from gold.branches b where b.id = v.receiver_branch_id),
    'cashSent', gold.ts(v.cash_sent), 'mobileMoneyPaidOnBehalf', gold.ts(v.mobile_money_paid_on_behalf),
    'goodsValueSent', gold.ts(v.goods_value_sent), 'mobileMoneyFailedCoveredByCash', gold.ts(v.mobile_money_failed_covered_by_cash))
    order by v.sender_branch_id, v.receiver_branch_id), '[]'::jsonb)
  from gold.v_interbranch_position v
  where v.sender_branch_id = any(coalesce(p_scope, '{}')) or v.receiver_branch_id = any(coalesce(p_scope, '{}'))
$$;


--
-- Name: iso(timestamp with time zone); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.iso(p timestamp with time zone) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  select to_char(p at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')
$$;


--
-- Name: issue_loan(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.issue_loan(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant();
  v_user uuid := gold.require_actor();
  v_id uuid := (p->>'id')::uuid;
  v_branch uuid := (p->>'branchId')::uuid;
  v_principal numeric := (p->>'principal')::numeric;
  v_at timestamptz := least((p->>'capturedAt')::timestamptz, now());
  v_type text := coalesce(p->>'partyType', 'customer');
  v_name text := trim(coalesce(p#>>'{customer,name}', ''));
  v_customer uuid;
  v_day uuid; v_holding uuid;
  v_top numeric := nullif(p#>>'{collateral,topWeight}', '')::numeric;
begin
  if exists (select 1 from gold.debts where id = v_id) then
    return jsonb_build_object('replayed', true, 'data', gold.debt_json(v_id));
  end if;
  perform 1 from gold.branches where id = v_branch and is_active;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Branch was not found.'); end if;
  if v_principal is null or v_principal <= 0 or v_principal <> trunc(v_principal) then
    perform gold.fail(422, 'VALIDATION_FAILED', 'The loan must be a whole number of cedis above zero.');
  end if;
  if v_type not in ('customer', 'staff', 'other') then perform gold.fail(422, 'VALIDATION_FAILED', 'Unknown party type.'); end if;
  if not gold.has_text(v_name, 1) then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the borrower''s name.'); end if;
  if gold.lines_total(p->'lines') <> v_principal then
    perform gold.fail(422, 'PAYOUT_MISMATCH', 'The notes handed over do not add up to the loan.');
  end if;
  v_customer := gold.ensure_customer((p#>>'{customer,id}')::uuid, v_name, p#>>'{customer,phone}');
  if v_type = 'customer' and v_customer is null then
    perform gold.fail(422, 'CUSTOMER_REQUIRED', 'A name and phone number are needed to lend to a customer.');
  end if;
  if v_top is not null and (v_top <= 0 or v_customer is null) then
    perform gold.fail(422, 'VALIDATION_FAILED', 'Security needs a weight above zero and a customer.');
  end if;
  v_day := gold.open_day_id(v_branch);

  insert into gold.debts (id, tenant_id, branch_id, customer_id, party_name, party_type, principal, reason, issued_at, issued_by, due_date, direction)
  values (v_id, v_tenant, v_branch, v_customer, v_name, v_type, v_principal, coalesce(nullif(trim(p->>'reason'), ''), 'Loan'), v_at, v_user,
          nullif(p->>'dueDate', '')::date, 'receivable');
  perform gold.post_value('debt', v_branch, v_day, v_at, v_principal, 'debt_issued', v_id, 'Loan');
  perform gold.post_cash(v_branch, v_day, v_at, p->'lines', -1, 'debt_issued', v_id, 'Loan paid out');

  if v_top is not null then
    insert into gold.collateral_holdings (tenant_id, branch_id, customer_id, debt_id, top_weight, description, received_by, received_at)
    values (v_tenant, v_branch, v_customer, v_id, v_top, nullif(trim(p#>>'{collateral,description}'), ''), v_user, v_at)
    returning id into v_holding;
    perform gold.post_custody(v_branch, v_day, v_at, v_top, 'custody_in', v_holding, 'Unrefined gold kept as security');
  end if;
  return jsonb_build_object('replayed', false, 'data', gold.debt_json(v_id));
end $$;


--
-- Name: item_booked_value(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.item_booked_value(p_item uuid) RETURNS numeric
    LANGUAGE sql STABLE
    AS $$
  select round(i.amount * coalesce(t.payable / nullif((select sum(amount) from gold.transaction_items where transaction_id = t.id), 0), 1), 2)
  from gold.transaction_items i join gold.transactions t on t.id = i.transaction_id where i.id = p_item
$$;


--
-- Name: karat_label(numeric); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.karat_label(k numeric) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  select case when k is null then null
              when k >= 24 then '24'
              else floor(k)::int::text || ' ' || case when k - floor(k) < 1.0/3 then 'low' when k - floor(k) < 2.0/3 then 'mid' else 'high' end end
$$;


--
-- Name: karat_stats_json(uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.karat_stats_json(p_items uuid[]) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select case when count(*) = 0 then jsonb_build_object('n', 0, 'enough', false) else jsonb_build_object(
    'n', count(*), 'enough', count(*) >= 5,
    'median', round(percentile_cont(0.5) within group (order by i.karat)::numeric, 2),
    'low', round(percentile_cont(0.1) within group (order by i.karat)::numeric, 2),
    'high', round(percentile_cont(0.9) within group (order by i.karat)::numeric, 2),
    'usual', gold.karat_label(percentile_cont(0.5) within group (order by i.karat)::numeric),
    'from', gold.karat_label(percentile_cont(0.1) within group (order by i.karat)::numeric),
    'to', gold.karat_label(percentile_cont(0.9) within group (order by i.karat)::numeric)) end
  from gold.transaction_items i where i.id = any(p_items)
$$;


--
-- Name: lines_json(text, uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.lines_json(p_source text, p_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_object_agg(denomination::text, n), '{}'::jsonb)
  from (select denomination, abs(sum(delta_count)) as n from gold.ledger_entries
        where asset = 'cash' and source_type = p_source and source_id = p_id
        group by denomination having sum(delta_count) <> 0) x
$$;


--
-- Name: lines_total(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.lines_total(p_lines jsonb) RETURNS numeric
    LANGUAGE plpgsql
    AS $_$
declare r record; t numeric := 0;
begin
  if p_lines is null then return 0; end if;
  if jsonb_typeof(p_lines) <> 'object' then perform gold.fail(422, 'VALIDATION_FAILED', 'Notes must be given as {"100": 3}.'); end if;
  for r in select key, value from jsonb_each_text(p_lines) loop
    if r.key !~ '^(5|10|20|50|100|200)$' then perform gold.fail(422, 'BAD_DENOMINATION', 'Notes must be 5, 10, 20, 50, 100 or 200 cedis.'); end if;
    if r.value !~ '^[1-9][0-9]{0,8}$' then perform gold.fail(422, 'BAD_COUNT', 'Note counts must be positive whole numbers.'); end if;
    t := t + r.key::int * r.value::int;
  end loop;
  return t;
end $_$;


--
-- Name: merge_customers(uuid, uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.merge_customers(p_keep uuid, p_remove uuid) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare k gold.customers; r gold.customers; v_before jsonb;
begin
  perform gold.require_actor();
  if p_keep = p_remove then perform gold.fail(422, 'VALIDATION_FAILED', 'Choose two different customers.'); end if;
  select * into k from gold.customers where id = p_keep for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Customer was not found.'); end if;
  select * into r from gold.customers where id = p_remove for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Customer was not found.'); end if;
  v_before := jsonb_build_object('kept', gold.customer_row_json(k), 'removed', gold.customer_row_json(r));
  update gold.transactions set customer_id = p_keep where customer_id = p_remove;
  update gold.debts set customer_id = p_keep, party_name = k.name where customer_id = p_remove;
  update gold.collateral_holdings set customer_id = p_keep where customer_id = p_remove;
  update gold.customers set notes = nullif(concat_ws(E'\n', k.notes, r.notes), '') where id = p_keep;
  delete from gold.customers where id = p_remove;
  perform gold.audit('customer.merged', 'customer', p_keep::text, v_before, gold.customer_row_json((select x from gold.customers x where x.id = p_keep)));
  return gold.customer_detail_json(p_keep);
end $$;


--
-- Name: movement_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.movement_json(p_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object('id', m.id, 'dayId', m.business_day_id, 'kind', m.kind, 'lines', gold.lines_json('drawer_movement', m.id),
                            'note', m.note, 'capturedAt', gold.iso(m.occurred_at), 'createdBy', gold.person_json(m.created_by),
                            'transactionId', m.transaction_id)
         || case when m.kind = 'exchange' then jsonb_build_object('exchange', jsonb_build_object(
              'gave', coalesce((select jsonb_object_agg(x.denomination::text, x.n) from (select denomination, sum(delta_count) as n from gold.ledger_entries
                        where asset = 'cash' and source_type = 'drawer_movement' and source_id = m.id group by denomination having sum(delta_count) > 0) x), '{}'::jsonb),
              'took', coalesce((select jsonb_object_agg(x.denomination::text, -x.n) from (select denomination, sum(delta_count) as n from gold.ledger_entries
                        where asset = 'cash' and source_type = 'drawer_movement' and source_id = m.id group by denomination having sum(delta_count) < 0) x), '{}'::jsonb)))
            else '{}'::jsonb end
  from gold.drawer_movements m where m.id = p_id
$$;


--
-- Name: my_password_hash(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.my_password_hash() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select password_hash from gold.users where id = gold.current_actor()
$$;


--
-- Name: my_security_json(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.my_security_json() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object('mustChangePassword', must_change_password) from gold.users where id = gold.current_actor()
$$;


--
-- Name: next_document_number(uuid, text, uuid, date); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.next_document_number(p_tenant uuid, p_kind text, p_branch uuid, p_date date) RETURNS integer
    LANGUAGE sql
    AS $$
  insert into gold.document_counters (tenant_id, kind, branch_id, business_date, last_value)
  values (p_tenant, p_kind, p_branch, p_date, 1)
  on conflict (tenant_id, kind, branch_id, business_date)
  do update set last_value = gold.document_counters.last_value + 1
  returning last_value
$$;


--
-- Name: notifications_json(integer, boolean); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.notifications_json(p_limit integer DEFAULT 30, p_unread_only boolean DEFAULT false) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare v_user uuid := gold.require_actor();
begin
  return jsonb_build_object(
    'unread', (select count(*) from gold.notifications where user_id = v_user and read_at is null),
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', n.id, 'kind', n.kind, 'title', n.title, 'body', n.body, 'link', n.link,
                'createdAt', gold.iso(n.created_at), 'read', n.read_at is not null) order by n.created_at desc)
              from (select * from gold.notifications where user_id = v_user and (not p_unread_only or read_at is null)
                    order by created_at desc limit least(greatest(coalesce(p_limit, 30), 1), 100)) n), '[]'::jsonb));
end $$;


--
-- Name: notifications_mark_read(uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.notifications_mark_read(p_ids uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare v_user uuid := gold.require_actor();
begin
  update gold.notifications set read_at = now() where user_id = v_user and read_at is null and (p_ids is null or id = any(p_ids));
  return gold.notifications_json(30, false);
end $$;


--
-- Name: notify(uuid, text, text, text, text, uuid[], text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.notify(p_tenant uuid, p_kind text, p_title text, p_body text, p_link text, p_branches uuid[], p_permission text) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare v_tenant uuid := p_tenant; v_actor uuid := gold.current_actor(); r record; v_id uuid; n int := 0;
begin
  for r in
    select u.id from gold.users u
    where u.tenant_id = v_tenant and u.is_active and u.id is distinct from v_actor
      and exists (select 1 from gold.effective_permissions(u.id) p where p = p_permission)
      and (p_branches is null or exists (select 1 from gold.user_branch_ids(u.id) b where b = any(p_branches)))
  loop
    insert into gold.notifications (tenant_id, user_id, kind, title, body, link) values (v_tenant, r.id, p_kind, p_title, p_body, p_link) returning id into v_id;
    perform pg_notify('gold_events', jsonb_build_object('type', 'notification', 't', v_tenant, 'u', r.id, 'n', v_id, 'kind', p_kind, 'title', p_title, 'link', p_link)::text);
    n := n + 1;
  end loop;
  return n;
end $$;


--
-- Name: notify_user(uuid, uuid, text, text, text, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.notify_user(p_tenant uuid, p_user uuid, p_kind text, p_title text, p_body text, p_link text) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare v_tenant uuid := p_tenant; v_id uuid;
begin
  if p_user is null or p_user is not distinct from gold.current_actor() then return; end if;
  insert into gold.notifications (tenant_id, user_id, kind, title, body, link) values (v_tenant, p_user, p_kind, p_title, p_body, p_link) returning id into v_id;
  perform pg_notify('gold_events', jsonb_build_object('type', 'notification', 't', v_tenant, 'u', p_user, 'n', v_id, 'kind', p_kind, 'title', p_title, 'link', p_link)::text);
end $$;


--
-- Name: open_day(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.open_day(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant();
  v_user uuid := gold.require_actor();
  v_id uuid := (p->>'id')::uuid;
  v_branch uuid := (p->>'branchId')::uuid;
  v_date date := (p->>'businessDate')::date;
  v_at timestamptz := least((p->>'capturedAt')::timestamptz, now());
  v_source text := coalesce(p->>'source', 'counted');
  v_lines jsonb := coalesce(p->'lines', '{}'::jsonb);
  v_expl text := nullif(trim(coalesce(p->>'explanation', '')), '');
  bal record; r record;
  v_seq bigint; v_history boolean; v_prev uuid; v_cont boolean := false;
  v_detail jsonb := '{}'::jsonb; v_pos jsonb := '{}'::jsonb; v_neg jsonb := '{}'::jsonb; v_declared numeric;
begin
  if exists (select 1 from gold.business_days where id = v_id) then
    return jsonb_build_object('replayed', true, 'data', gold.day_json(v_id));
  end if;
  perform 1 from gold.branches where id = v_branch and is_active for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Branch was not found.'); end if;
  if v_source not in ('counted', 'carried') then perform gold.fail(422, 'VALIDATION_FAILED', 'source must be counted or carried.'); end if;
  if exists (select 1 from gold.business_days where branch_id = v_branch and status = 'open') then
    perform gold.fail(409, 'DAY_ALREADY_OPEN', 'A day is already open for this branch.');
  end if;
  if exists (select 1 from gold.business_days where branch_id = v_branch and business_date = v_date) then
    -- A customer arrives after the day was closed: a second session on the same date is allowed, never a changed past.
    -- The first session's count stays exactly as it was signed; this one starts from the closing books, and says why.
    if exists (select 1 from gold.business_days where branch_id = v_branch and business_date = v_date and status <> 'closed') then
      perform gold.fail(409, 'DAY_ALREADY_OPEN', 'This branch already has a day for that date.');
    end if;
    if coalesce(p->>'afterClose', 'false') <> 'true' then
      perform gold.fail(409, 'DAY_ALREADY_CLOSED', 'Today was already closed. If a customer came in after closing, open it again and say why.');
    end if;
    if not gold.has_text(v_expl, 5) then
      perform gold.fail(422, 'VALIDATION_FAILED', 'Say why the day is opened again (at least 5 characters).');
    end if;
    v_source := 'carried';
    v_cont := true;
  end if;

  select * into bal from gold.branch_balance(v_branch);
  select max(seq) into v_seq from gold.ledger_entries where branch_id = v_branch;
  -- A branch that only has opening gold and debts is still at its first count: what matters is whether its drawer has a past.
  v_history := exists (select 1 from gold.business_days where branch_id = v_branch) or exists (select 1 from gold.ledger_entries where branch_id = v_branch and asset = 'cash');
  if v_source = 'carried' then
    select coalesce(jsonb_object_agg(key, value), '{}'::jsonb) into v_lines from jsonb_each(bal.cash_lines) where (value #>> '{}')::int > 0;
  end if;
  v_declared := gold.lines_total(v_lines);
  select id into v_prev from gold.business_days where branch_id = v_branch order by business_date desc, opened_at desc limit 1;

  insert into gold.business_days (id, tenant_id, branch_id, business_date, session_no, previous_day_id, opened_at, opened_by, opened_offline, opening_source)
  values (v_id, v_tenant, v_branch, v_date, (select coalesce(max(session_no), 0) + 1 from gold.business_days where branch_id = v_branch and business_date = v_date),
          v_prev, v_at, v_user, (now() - v_at) > interval '2 minutes', v_source);
  if v_cont then
    update gold.business_days set continuation_reason = trim(v_expl) where id = v_id;
    perform gold.notify(v_tenant, 'after_close_session', 'The day was opened again after closing', trim(v_expl), '/drawer/history', array[v_branch], 'discrepancies:review');
  end if;

  insert into gold.day_balances (tenant_id, business_day_id, kind, cash_lines, cash_value, goods_top, goods_down, goods_value, debt_value,
                                 payable_value, custody_top, ledger_seq, captured_by)
  values (v_tenant, v_id, 'opening_expected', bal.cash_lines, bal.cash_value, bal.goods_top, bal.goods_down, bal.goods_value, bal.debt_value,
          bal.payable_value, bal.custody_top, v_seq, v_user);

  if not v_history then
    perform gold.post_cash(v_branch, v_id, v_at, v_lines, 1, 'go_live_balance', v_id, 'First count of the drawer');
  else
    for r in
      select coalesce(e.k, d.k) as denom, coalesce(d.n, 0) - coalesce(e.n, 0) as delta
      from (select key::int as k, value::int as n from jsonb_each_text(bal.cash_lines)) e
      full join (select key::int as k, value::int as n from jsonb_each_text(v_lines)) d on d.k = e.k
      where coalesce(d.n, 0) <> coalesce(e.n, 0)
    loop
      v_detail := v_detail || jsonb_build_object(r.denom::text, r.delta);
      if r.delta > 0 then v_pos := v_pos || jsonb_build_object(r.denom::text, r.delta);
      else v_neg := v_neg || jsonb_build_object(r.denom::text, -r.delta); end if;
    end loop;

    if v_detail <> '{}'::jsonb then
      if v_expl is null or not gold.has_text(v_expl, 5) then
        perform gold.fail(422, 'EXPLANATION_REQUIRED',
          'The count differs from what the books say the drawer holds. Write why (at least 5 characters).');
      end if;
      perform gold.post_cash(v_branch, v_id, v_at, v_pos, 1, 'opening_adjustment', v_id, v_expl);
      perform gold.post_cash(v_branch, v_id, v_at, v_neg, -1, 'opening_adjustment', v_id, v_expl);
      insert into gold.day_reconciliations (tenant_id, business_day_id, phase, asset, expected, actual, detail, explanation, explained_by)
      values (v_tenant, v_id, 'opening', 'cash', bal.cash_value, v_declared, v_detail, v_expl, v_user);
    end if;
  end if;

  insert into gold.day_balances (tenant_id, business_day_id, kind, cash_lines, cash_value, goods_top, goods_down, goods_value, debt_value,
                                 payable_value, custody_top, captured_by)
  values (v_tenant, v_id, 'opening_declared', v_lines, v_declared, bal.goods_top, bal.goods_down, bal.goods_value, bal.debt_value,
          bal.payable_value, bal.custody_top, v_user);

  return jsonb_build_object('replayed', false, 'data', gold.day_json(v_id));
end $$;


--
-- Name: open_day_id(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.open_day_id(p_branch uuid) RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select id from gold.business_days where branch_id = p_branch and status = 'open'
$$;


--
-- Name: other_holders(text, uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.other_holders(p_permission text, p_except uuid) RETURNS integer
    LANGUAGE sql STABLE
    AS $$
  select count(*)::int from gold.users u
  where u.is_active and u.id <> p_except
    and exists (select 1 from gold.effective_permissions(u.id) e where e = p_permission)
$$;


--
-- Name: pay_transaction(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.pay_transaction(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_user uuid := gold.require_actor();
  v_id uuid := (p->>'id')::uuid;
  v_lines jsonb := p->'lines';
  v_at timestamptz := least(coalesce((p->>'capturedAt')::timestamptz, now()), now());
  t gold.transactions; v_day uuid; v_who text; v_check numeric; v_matched boolean;
begin
  select * into t from gold.transactions where id = v_id for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Purchase was not found.'); end if;
  if t.status = 'void' then perform gold.fail(409, 'TRANSACTION_VOID', 'This purchase was cancelled.'); end if;
  if t.stage = 'paid' then
    if t.paid_by is null then perform gold.fail(409, 'ALREADY_PAID', 'This purchase was already paid when it was saved.'); end if;
    if t.paid_by = v_user and gold.lines_json('transaction_payout', t.id) = coalesce(v_lines, '{}'::jsonb) then
      return jsonb_build_object('replayed', true, 'data', gold.transaction_json(v_id));
    end if;
    select display_name into v_who from gold.users where id = t.paid_by;
    perform gold.fail(409, 'ALREADY_PAID', format('Already paid by %s at %s.', coalesce(v_who, 'someone else'), to_char(t.paid_at at time zone (select timezone from gold.branches where id = t.branch_id), 'HH24:MI')));
  end if;
  if t.created_by = v_user and not coalesce((gold.setting('payout.sameUserMayPay'))::boolean, true) then
    perform gold.fail(403, 'SAME_PERSON', 'Another person has to pay this one out.');
  end if;
  if gold.lines_total(v_lines) <> t.cash_due then
    perform gold.fail(422, 'PAYOUT_MISMATCH', format('The notes must add up to exactly GHS %s. Only the notes can change, not the amount.', gold.ts(t.cash_due)));
  end if;
  v_day := gold.open_day_id(t.branch_id);
  if v_day is null then perform gold.fail(409, 'NO_OPEN_DAY', 'Open the day before paying cash out.'); end if;

  if coalesce((gold.setting('payout.blindCheck'))::boolean, false) and nullif(p->>'checkAmount', '') is null then
    perform gold.fail(422, 'CHECK_REQUIRED', 'Enter the amount worked out from the weights before paying.');
  end if;
  if nullif(p->>'checkAmount', '') is not null then
    v_check := (p->>'checkAmount')::numeric;
    v_matched := v_check = t.calculated_amount;
    if not v_matched then
      -- Refuse, and make a note that someone noticed: the books are unchanged.
      perform gold.notify(t.tenant_id, 'check_mismatch', format('%s: the check does not match', t.reference),
        format('The amount worked out at the paying desk (GHS %s) differs from the recorded one (GHS %s).', gold.ts(v_check), gold.ts(t.calculated_amount)),
        '/transactions/' || t.id::text, array[t.branch_id], 'discrepancies:review');
      perform gold.fail(409, 'CHECK_MISMATCH', format('Your figure (GHS %s) does not match the recorded amount. Check the weights and the price with the person who recorded it.', gold.ts(v_check)));
    end if;
  end if;

  perform gold.post_cash(t.branch_id, v_day, v_at, v_lines, -1, 'transaction_payout', t.id, 'Paid for ' || t.reference);
  perform gold.post_value('payable', t.branch_id, v_day, v_at, -t.cash_due, 'payable_settlement', t.id, 'Cash paid for ' || t.reference);
  insert into gold.transaction_payments (tenant_id, transaction_id, method, amount, recorded_by, confirmed_by, confirmed_at)
  values (t.tenant_id, t.id, 'cash', t.cash_due, v_user, v_user, v_at);
  update gold.transactions set stage = 'paid', paid_by = v_user, paid_at = v_at, check_amount = v_check, check_matched = v_matched where id = t.id;
  return jsonb_build_object('replayed', false, 'data', gold.transaction_json(t.id));
end $$;


--
-- Name: payment_guard(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.payment_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  if tg_op = 'DELETE' then
    raise exception 'payments cannot be deleted' using errcode = 'integrity_constraint_violation';
  end if;
  if (new.tenant_id, new.transaction_id, new.method, new.amount, new.paid_by_branch_id, new.debt_id, new.recorded_by, new.created_at)
     is distinct from
     (old.tenant_id, old.transaction_id, old.method, old.amount, old.paid_by_branch_id, old.debt_id, old.recorded_by, old.created_at) then
    raise exception 'a recorded payment cannot be changed' using errcode = 'integrity_constraint_violation';
  end if;
  if old.status <> 'pending' and new.status is distinct from old.status then
    raise exception 'a confirmed or failed payment cannot change status again' using errcode = 'integrity_constraint_violation';
  end if;
  return new;
end $$;


--
-- Name: payment_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.payment_json(p_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object('id', id, 'method', method, 'amount', gold.ts(amount), 'status', status, 'paidByBranchId', paid_by_branch_id,
                            'externalRef', external_ref, 'debtId', debt_id, 'confirmedAt', case when confirmed_at is null then null else gold.iso(confirmed_at) end)
  from gold.transaction_payments where id = p_id
$$;


--
-- Name: pending_payments_json(uuid, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.pending_payments_json(p_branch uuid, p_role text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(jsonb_build_object(
      'paymentId', p.id, 'transactionId', t.id, 'reference', t.reference,
      'purchaseBranchId', t.branch_id, 'purchaseBranchName', b.name,
      'sendingBranchId', p.paid_by_branch_id, 'sendingBranchName', sb.name,
      'customerName', t.customer_name, 'amount', gold.ts(p.amount), 'externalRef', p.external_ref,
      'createdAt', gold.iso(p.created_at)) order by p.created_at), '[]'::jsonb)
  from gold.transaction_payments p
  join gold.transactions t on t.id = p.transaction_id
  join gold.branches b on b.id = t.branch_id
  join gold.branches sb on sb.id = p.paid_by_branch_id
  where p.method = 'mobile_money' and p.status = 'pending'
    and case when p_role = 'receiving' then t.branch_id = p_branch else p.paid_by_branch_id = p_branch end
$$;


--
-- Name: person_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.person_json(p_user uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object('id', id, 'displayName', display_name) from gold.users where id = p_user
$$;


--
-- Name: post_cash(uuid, uuid, timestamp with time zone, jsonb, integer, text, uuid, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.post_cash(p_branch uuid, p_day uuid, p_at timestamp with time zone, p_lines jsonb, p_sign integer, p_source text, p_source_id uuid, p_memo text DEFAULT NULL::text) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
declare r record; total numeric := gold.lines_total(p_lines);
begin
  if p_lines is null then return 0; end if;
  for r in select key::int as denom, value::int as n from jsonb_each_text(p_lines) loop
    insert into gold.ledger_entries (tenant_id, branch_id, business_day_id, occurred_at, recorded_by, asset, denomination, delta_count,
                                     delta_value, source_type, source_id, memo)
    values (gold.current_tenant(), p_branch, p_day, p_at, gold.current_actor(), 'cash', r.denom, p_sign * r.n,
            r.denom * p_sign * r.n, p_source, p_source_id, p_memo);
  end loop;
  return total;
end $$;


--
-- Name: post_custody(uuid, uuid, timestamp with time zone, numeric, text, uuid, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.post_custody(p_branch uuid, p_day uuid, p_at timestamp with time zone, p_top numeric, p_source text, p_source_id uuid, p_memo text DEFAULT NULL::text) RETURNS void
    LANGUAGE sql
    AS $$
  insert into gold.ledger_entries (tenant_id, branch_id, business_day_id, occurred_at, recorded_by, asset, delta_top, delta_value, source_type, source_id, memo)
  values (gold.current_tenant(), p_branch, p_day, p_at, gold.current_actor(), 'custody', p_top, 0, p_source, p_source_id, p_memo)
$$;


--
-- Name: post_goods(uuid, uuid, timestamp with time zone, numeric, numeric, numeric, text, uuid, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.post_goods(p_branch uuid, p_day uuid, p_at timestamp with time zone, p_top numeric, p_down numeric, p_value numeric, p_source text, p_source_id uuid, p_memo text DEFAULT NULL::text) RETURNS void
    LANGUAGE sql
    AS $$
  insert into gold.ledger_entries (tenant_id, branch_id, business_day_id, occurred_at, recorded_by, asset, delta_top, delta_down, delta_value,
                                   source_type, source_id, memo)
  values (gold.current_tenant(), p_branch, p_day, p_at, gold.current_actor(), 'goods', p_top, p_down, p_value, p_source, p_source_id, p_memo)
$$;


--
-- Name: post_transaction(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.post_transaction(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant();
  v_user uuid := gold.require_actor();
  v_id uuid := (p->>'id')::uuid;
  v_branch uuid := (p->>'branchId')::uuid;
  v_at timestamptz := (p->>'capturedAt')::timestamptz;
  v_payable numeric := (p->>'payable')::numeric;
  v_name text := trim(coalesce(p#>>'{customer,name}', ''));
  v_phone text := nullif(regexp_replace(coalesce(p#>>'{customer,phone}', ''), '\s', '', 'g'), '');
  v_rep_name text := nullif(trim(coalesce(p#>>'{representative,name}', '')), '');
  v_rep_phone text := nullif(regexp_replace(coalesce(p#>>'{representative,phone}', ''), '\s', '', 'g'), '');
  b gold.branches; v_town uuid; v_customer uuid; v_day uuid; v_flags text[]; v_late uuid; v_ref text; v_n int; v_local date;
  pay jsonb; v_sum numeric := 0; v_top numeric; v_down numeric; h gold.collateral_holdings;
  v_two boolean := coalesce((gold.setting('payout.twoStep'))::boolean, false); v_due numeric := 0; v_suggest jsonb;
begin
  if exists (select 1 from gold.transactions where id = v_id) then
    return jsonb_build_object('replayed', true, 'data', gold.transaction_json(v_id));
  end if;
  select * into b from gold.branches where id = v_branch and is_active;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Branch was not found.'); end if;
  if not gold.has_text(v_name, 1) then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the customer name.'); end if;
  if not exists (select 1 from gold.formula_versions where key = p->>'formulaVersion') then
    perform gold.fail(409, 'FORMULA_NOT_CONFIGURED', 'The calculation settings are missing for this company. Run the seed command.');
  end if;
  if v_payable is null or v_payable < 0 or v_payable <> trunc(v_payable) or mod(v_payable, 5) <> 0 then
    perform gold.fail(422, 'PAYOUT_MISMATCH', 'The amount to pay must be a whole number of cedis, a multiple of 5.');
  end if;
  for pay in select * from jsonb_array_elements(coalesce(p->'payments', '[]'::jsonb)) loop
    v_sum := v_sum + (pay->>'amount')::numeric;
  end loop;
  if v_sum <> v_payable then
    perform gold.fail(422, 'PAYOUT_MISMATCH', 'The parts of the payment (' || gold.ts(v_sum) || ') must add up to the amount to pay (' || gold.ts(v_payable) || ').');
  end if;

  v_customer := gold.ensure_customer((p#>>'{customer,id}')::uuid, v_name, v_phone, coalesce((gold.setting('customers.autoCreate'))::boolean, true));
  -- Someone brought the gold for the customer: the customer owns the purchase and any debts; the representative is only written on it.
  if v_rep_name is not null and v_customer is null then
    perform gold.fail(422, 'REPRESENTATIVE_NEEDS_CUSTOMER', 'Pick the customer this person is acting for, or give the customer''s phone number.');
  end if;
  if v_rep_phone is not null and v_rep_name is null then
    perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the name of the person bringing the gold.');
  end if;
  v_day := gold.open_day_id(v_branch);
  v_flags := coalesce(array(select jsonb_array_elements_text(coalesce(p->'flags', '[]'::jsonb))), '{}');
  if v_day is null then v_flags := array_append(v_flags, 'NO_OPEN_DAY'); end if;
  -- A device clock that runs ahead must not date the books in the future: use the server's time and say so.
  if v_at > now() + interval '5 minutes' then
    v_at := now();
    v_flags := array_append(v_flags, 'CLOCK_AHEAD');
  end if;
  -- Made while a day was open but reaching us after it closed: the cash really left that day, so its count will not match the books.
  select d.id into v_late from gold.business_days d
   where d.branch_id = v_branch and d.status = 'closed' and d.opened_at <= v_at and v_at <= d.closed_at
   order by d.opened_at desc limit 1;
  if v_late is not null then v_flags := array_append(v_flags, 'AFTER_CLOSE'); end if;

  v_local := (v_at at time zone b.timezone)::date;
  v_n := gold.next_document_number(v_tenant, 'transaction', v_branch, v_local);
  v_ref := b.code || '-' || to_char(v_local, 'YYYYMMDD') || '-' || lpad(v_n::text, 4, '0');

  v_town := gold.resolve_town(p->'originTown');

  insert into gold.transactions (id, tenant_id, branch_id, business_day_id, reference, customer_id, customer_name, customer_phone, status,
                                 formula_version, price_as_of, client_amount, calculated_amount, payout_policy, payout_strategy, payable,
                                 payout_difference, captured_at, created_by, flags, represented_by_name, represented_by_phone, origin_town_id)
  values (v_id, v_tenant, v_branch, v_day, v_ref, v_customer, v_name, v_phone, 'saved', p->>'formulaVersion', (p->>'priceAsOf')::timestamptz,
          (p->>'clientAmount')::numeric, (p->>'calculatedAmount')::numeric, p->>'policy', p->>'strategy', v_payable,
          (p->>'difference')::numeric, v_at, v_user, v_flags, v_rep_name, v_rep_phone, v_town);

  insert into gold.transaction_items (id, tenant_id, transaction_id, line_no, label, top, down, price, density, karat, purity, net_weight, pounds,
                                      amount, location_branch_id)
  select (i->>'id')::uuid, v_tenant, v_id, ord::smallint, nullif(trim(coalesce(i->>'label', '')), ''), (i->>'top')::numeric, (i->>'down')::numeric,
         (i->>'price')::numeric, (i->>'density')::numeric, (i->>'karat')::numeric, (i->>'purity')::numeric, (i->>'netWeight')::numeric,
         (i->>'pounds')::numeric, (i->>'amount')::numeric, v_branch
  from jsonb_array_elements(p->'items') with ordinality as t(i, ord);

  for pay in select * from jsonb_array_elements(coalesce(p->'payments', '[]'::jsonb)) loop
    if v_two and pay->>'method' = 'cash' then
      -- Two-step: the cash is paid out later by whoever hands it over. Until then it is an amount owed to the customer.
      v_due := (pay->>'amount')::numeric;
      if v_due <= 0 or v_due <> trunc(v_due) then perform gold.fail(422, 'VALIDATION_FAILED', 'Each part of the payment must be a whole number of cedis above zero.'); end if;
      if gold.lines_total(pay->'lines') <> v_due then perform gold.fail(422, 'PAYOUT_MISMATCH', 'The notes do not add up to the cash amount.'); end if;
      v_suggest := pay->'lines';
    else
      perform gold.apply_payment(v_id, v_branch, v_day, v_at, v_customer, v_ref, pay);
    end if;
  end loop;

  select sum(top), sum(down) into v_top, v_down from gold.transaction_items where transaction_id = v_id;
  perform gold.post_goods(v_branch, v_day, v_at, v_top, v_down, v_payable, 'transaction_purchase', v_id, 'Gold bought ' || v_ref);
  if v_due > 0 then
    update gold.transactions set stage = 'to_pay', cash_due = v_due, suggested_lines = v_suggest where id = v_id;
    perform gold.post_value('payable', v_branch, v_day, v_at, v_due, 'payable_issued', v_id, 'Cash still to pay for ' || v_ref);
    perform gold.notify(v_tenant, 'purchase_to_pay', format('%s is ready to be paid', v_ref),
      format('%s: GHS %s to pay out.', v_name, gold.ts(v_due)), '/transactions/' || v_id::text, array[v_branch], 'days:manage');
  end if;

  if nullif(p->>'collateralId', '') is not null then
    select * into h from gold.collateral_holdings where id = (p->>'collateralId')::uuid for update;
    if not found then perform gold.fail(404, 'NOT_FOUND', 'That security was not found.'); end if;
    if h.status <> 'held' then perform gold.fail(409, 'COLLATERAL_NOT_HELD', 'This gold is no longer held.'); end if;
    if h.branch_id <> v_branch or h.customer_id is distinct from v_customer then
      perform gold.fail(422, 'COLLATERAL_MISMATCH', 'This security belongs to another customer or branch.');
    end if;
    update gold.collateral_holdings set status = 'converted', converted_transaction_id = v_id, closed_by = v_user, closed_at = v_at where id = h.id;
    perform gold.post_custody(v_branch, v_day, v_at, -h.top_weight, 'custody_out', h.id, 'Refined and bought ' || v_ref);
  end if;

  if v_late is not null then
    perform gold.notify(v_tenant, 'late_purchase', format('%s was recorded after its day had closed', v_ref),
      'It was made while the day was open but reached the server later, so that day''s count may show a difference that this purchase explains.', '/drawer/history', array[v_branch], 'discrepancies:review');
  end if;
  return jsonb_build_object('replayed', false, 'data', gold.transaction_json(v_id));
end $$;


--
-- Name: post_value(text, uuid, uuid, timestamp with time zone, numeric, text, uuid, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.post_value(p_asset text, p_branch uuid, p_day uuid, p_at timestamp with time zone, p_delta numeric, p_source text, p_source_id uuid, p_memo text DEFAULT NULL::text) RETURNS void
    LANGUAGE sql
    AS $$
  insert into gold.ledger_entries (tenant_id, branch_id, business_day_id, occurred_at, recorded_by, asset, delta_value, source_type, source_id, memo)
  values (gold.current_tenant(), p_branch, p_day, p_at, gold.current_actor(), p_asset, p_delta, p_source, p_source_id, p_memo)
$$;


--
-- Name: price_feed_json(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.price_feed_json() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'enabled', coalesce(s.enabled, false),
    'windows', coalesce(s.windows, '[{"start":"10:30","end":"11:30","everyMinutes":5},{"start":"15:00","end":"16:00","everyMinutes":5}]'::jsonb),
    'weekdays', coalesce(to_jsonb(s.weekdays), '[1,2,3,4,5]'::jsonb),
    'timezone', coalesce(s.timezone, 'Africa/Accra'),
    'marginPolicy', coalesce(s.margin_policy, 'approve'),
    'maxJumpPct', gold.ts(coalesce(s.max_jump_pct, 10)),
    'updatedBy', case when s.updated_by is null then null else gold.person_json(s.updated_by) end,
    'lastCheckedAt', gold.iso(s.last_checked_at), 'lastResult', s.last_result,
    'latest', (select jsonb_build_object('basePrice', gold.ts(p.base_price), 'publishedAt', gold.iso(p.published_at), 'source', p.source)
               from gold.price_snapshots p order by p.published_at desc, p.fetched_at desc limit 1),
    'events', coalesce((select jsonb_agg(jsonb_build_object(
        'id', e.id, 'at', gold.iso(e.at), 'kind', e.kind, 'state', e.state, 'message', e.message, 'basePrice', gold.ts(e.base_price),
        'publishedAt', gold.iso(e.published_at), 'usdPerOunce', gold.ts(e.usd_per_ounce), 'rate', gold.ts(e.rate), 'computed', gold.ts(e.computed),
        'excerpt', e.excerpt, 'decidedBy', case when e.decided_by is null then null else gold.person_json(e.decided_by) end) order by e.at desc)
        from (select * from gold.price_feed_events where tenant_id = gold.current_tenant() order by at desc limit 20) e), '[]'::jsonb))
  from (select 1) one left join gold.price_feed_settings s on s.tenant_id = gold.current_tenant()
$$;


--
-- Name: price_feed_state(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.price_feed_state() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'enabled', s.enabled, 'windows', s.windows, 'weekdays', to_jsonb(s.weekdays), 'timezone', s.timezone, 'maxJumpPct', gold.ts(s.max_jump_pct),
    'actor', s.updated_by, 'lastCheckedAt', gold.iso(s.last_checked_at),
    'lastCapturedAt', (select gold.iso(max(fetched_at)) from gold.price_snapshots where source = 'goldbod'),
    'latestFeedPublishedAt', (select gold.iso(max(published_at)) from gold.price_snapshots where source = 'goldbod'),
    'latestBase', (select gold.ts(base_price) from gold.price_snapshots order by published_at desc, fetched_at desc limit 1),
    'poundGrams', (select params->>'poundGrams' from gold.formula_versions where key = 'ExcelV1'),
    'referenceKarat', (select params->>'priceReferenceKarat' from gold.formula_versions where key = 'ExcelV1'))
  from gold.price_feed_settings s where s.tenant_id = gold.current_tenant()
$$;


--
-- Name: publish(uuid, text, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.publish(p_tenant uuid, p_topic text, p_branches uuid[]) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
  perform pg_notify('gold_events', jsonb_build_object('type', 'changed', 't', p_tenant, 'topic', p_topic, 'b', to_jsonb(case when p_branches is null then null else array_remove(p_branches, null) end))::text);
end $$;


--
-- Name: recall_transfer(uuid, text, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.recall_transfer(p_id uuid, p_reason text, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  t gold.transfers; v_user uuid := gold.require_actor(); v_day uuid; v_at timestamptz := now(); v_lines jsonb;
begin
  t := gold.transfer_for(p_id, 'origin', p_scope);
  if t.status = 'draft' then perform gold.fail(409, 'TRANSFER_NOT_RELEASED', 'This transfer has not been released yet. Cancel it instead.'); end if;
  if t.status <> 'released' then
    perform gold.fail(409, 'TRANSFER_NOT_IN_TRANSIT', case t.status
      when 'cancelled' then 'This transfer was already cancelled or recalled.'
      else 'This transfer has already been received, so it cannot be recalled.' end);
  end if;
  if not gold.has_text(p_reason, 5) then perform gold.fail(422, 'VALIDATION_FAILED', 'Write the reason (at least a few words).'); end if;
  v_day := gold.open_day_id(t.origin_branch_id);
  if v_day is null then perform gold.fail(409, 'DAY_NOT_OPEN', 'Open the day at the sending branch first.'); end if;

  if t.kind = 'goods' then
    perform gold.post_goods(t.origin_branch_id, v_day, v_at, t.declared_top, t.declared_down, t.declared_value, 'transfer_recall', p_id, 'Recalled ' || t.reference);
    update gold.transaction_items set location_state = 'on_hand'
      where id in (select transaction_item_id from gold.transfer_goods_lines where transfer_id = p_id and transaction_item_id is not null)
        and location_state = 'in_transit';
  else
    v_lines := gold.lines_json('transfer_release', p_id);
    perform gold.post_cash(t.origin_branch_id, v_day, v_at, v_lines, 1, 'transfer_recall', p_id, 'Cash back from ' || t.reference);
  end if;

  update gold.transfers set status = 'cancelled', cancelled_at = v_at, cancelled_by = v_user, cancel_reason = 'Recalled: ' || trim(p_reason) where id = p_id;
  perform gold.transfer_event(p_id, 'recalled', jsonb_build_object('reason', trim(p_reason), 'kind', t.kind));
  perform gold.notify(t.tenant_id, 'transfer_recalled', format('%s was recalled by the sending branch', t.reference),
    'Do not receive it. Reason: ' || trim(p_reason), '/transfers/' || p_id, array[t.destination_branch_id], 'transfers:receive');
  return gold.transfer_json(p_id);
end $$;


--
-- Name: receive_transfer(uuid, jsonb, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.receive_transfer(p_id uuid, p jsonb, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  t gold.transfers; v_user uuid := gold.require_actor(); v_day uuid; v_at timestamptz := now(); r record; l gold.transfer_goods_lines;
  v_out text; v_top numeric; v_down numeric; v_val numeric; v_rt numeric := 0; v_rd numeric := 0; v_rv numeric := 0; v_bad boolean := false;
  v_note text; v_asset text; v_exp numeric; v_act numeric; v_cash numeric; v_seen uuid[] := '{}'; v_case uuid;
begin
  t := gold.transfer_for(p_id, 'destination', p_scope);
  if t.status <> 'released' then perform gold.fail(409, 'NOT_IN_TRANSIT', 'This transfer is not waiting to be received.'); end if;
  v_day := gold.open_day_id(t.destination_branch_id);
  if v_day is null then perform gold.fail(409, 'DAY_NOT_OPEN', 'Open the day at the receiving branch first.'); end if;

  if t.kind = 'goods' then
    for r in select value as c from jsonb_array_elements(coalesce(p->'lines', '[]'::jsonb)) loop
      select * into l from gold.transfer_goods_lines where id = (r.c->>'lineId')::uuid and transfer_id = p_id for update;
      if not found then perform gold.fail(422, 'VALIDATION_FAILED', 'A line in the receipt does not belong to this transfer.'); end if;
      if l.id = any(v_seen) then perform gold.fail(422, 'VALIDATION_FAILED', 'A line was confirmed twice.'); end if;
      v_seen := v_seen || l.id;
      v_out := r.c->>'outcome'; v_note := nullif(trim(coalesce(r.c->>'note', '')), '');
      if v_out = 'matched' then
        v_top := l.released_top; v_down := l.released_down; v_val := l.released_value;
      elsif v_out = 'differs' then
        v_top := (r.c->>'top')::numeric; v_down := (r.c->>'down')::numeric;
        if v_top is null or v_down is null or v_top < 0 or v_down < 0 then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the weights you found for the line that differs.'); end if;
        if v_top = l.released_top and v_down = l.released_down then v_out := 'matched'; v_val := l.released_value;
        else
          v_val := case when l.released_top > 0 then round(l.released_value * v_top / l.released_top, 2) else 0 end;
          if not gold.has_text(v_note, 3) then perform gold.fail(422, 'EXPLANATION_REQUIRED', 'Say what you found for a line that differs.'); end if;
        end if;
      elsif v_out = 'missing' then
        v_top := null; v_down := null; v_val := null;
        if not gold.has_text(v_note, 3) then perform gold.fail(422, 'EXPLANATION_REQUIRED', 'Say what happened to a line that did not arrive.'); end if;
      else
        perform gold.fail(422, 'VALIDATION_FAILED', 'Each line must be matched, differs or missing.');
      end if;
      update gold.transfer_goods_lines set outcome = v_out, received_top = v_top, received_down = v_down, received_value = v_val where id = l.id;
      if v_out <> 'missing' then
        v_rt := v_rt + v_top; v_rd := v_rd + v_down; v_rv := v_rv + v_val;
        if l.transaction_item_id is not null then
          update gold.transaction_items set location_branch_id = t.destination_branch_id, location_state = 'on_hand' where id = l.transaction_item_id;
        end if;
      end if;
      if v_out <> 'matched' then
        v_bad := true;
        v_asset := case when v_out = 'missing' then 'goods_value' when v_top is distinct from l.released_top then 'goods_top' else 'goods_down' end;
        v_exp := case v_asset when 'goods_value' then l.released_value when 'goods_top' then l.released_top else l.released_down end;
        v_act := case v_asset when 'goods_value' then 0 when 'goods_top' then v_top else v_down end;
        insert into gold.discrepancies (tenant_id, branch_id, business_day_id, kind, asset, transfer_id, transfer_line_id, expected, actual, difference,
                                        reported_explanation, opened_by)
        values (t.tenant_id, t.destination_branch_id, v_day, 'transfer_receipt', v_asset, p_id, l.id, v_exp, v_act, v_act - v_exp, v_note, v_user);
        perform gold.transfer_event(p_id, 'discrepancy_flagged', jsonb_build_object('lineId', l.id, 'outcome', v_out, 'note', v_note));
      end if;
    end loop;
    if (select count(*) from gold.transfer_goods_lines where transfer_id = p_id and outcome = 'pending') > 0 then
      perform gold.fail(422, 'LINES_MISSING', 'Confirm every line: matched, differs or missing.');
    end if;
    if v_rt <> 0 or v_rd <> 0 or v_rv <> 0 then
      perform gold.post_goods(t.destination_branch_id, v_day, v_at, v_rt, v_rd, v_rv, 'transfer_receipt', p_id, 'Received on ' || t.reference);
    end if;
    update gold.transfers set status = case when v_bad then 'received_with_discrepancy' else 'received' end, received_by = v_user, received_at = v_at,
      received_top = v_rt, received_down = v_rd, received_value = v_rv, receipt_note = nullif(trim(coalesce(p->>'note', '')), '')
    where id = p_id;
  else
    v_cash := gold.lines_total(p->'lines');
    if p->'lines' is null then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the notes you counted (an empty envelope is {}).'); end if;
    if v_cash > 0 then perform gold.post_cash(t.destination_branch_id, v_day, v_at, p->'lines', 1, 'transfer_receipt', p_id, 'Cash received on ' || t.reference); end if;
    v_bad := v_cash <> t.declared_cash;
    if v_bad then
      if not gold.has_text(p->>'note', 3) then perform gold.fail(422, 'EXPLANATION_REQUIRED', 'The count differs from what was sent. Say what you found.'); end if;
      insert into gold.discrepancies (tenant_id, branch_id, business_day_id, kind, asset, transfer_id, expected, actual, difference, reported_explanation, opened_by)
      values (t.tenant_id, t.destination_branch_id, v_day, 'transfer_receipt', 'cash', p_id, t.declared_cash, v_cash, v_cash - t.declared_cash,
              trim(p->>'note'), v_user);
      perform gold.transfer_event(p_id, 'discrepancy_flagged', jsonb_build_object('expected', gold.ts(t.declared_cash), 'actual', gold.ts(v_cash), 'note', p->>'note'));
    end if;
    update gold.transfers set status = case when v_bad then 'received_with_discrepancy' else 'received' end, received_by = v_user, received_at = v_at,
      received_cash = v_cash, receipt_note = nullif(trim(coalesce(p->>'note', '')), '')
    where id = p_id;
  end if;
  perform gold.transfer_event(p_id, 'received', jsonb_build_object('discrepancy', v_bad));
  return gold.transfer_json(p_id);
end $$;


--
-- Name: record_exchange(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.record_exchange(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant();
  v_user uuid := gold.require_actor();
  v_id uuid := (p->>'id')::uuid;
  v_day uuid := (p->>'dayId')::uuid;
  v_branch uuid := (p->>'branchId')::uuid;
  v_tx uuid := nullif(p->>'transactionId', '')::uuid;
  v_note text := nullif(trim(coalesce(p->>'note', '')), '');
  v_at timestamptz := least((p->>'capturedAt')::timestamptz, now());
  v_gave jsonb := coalesce(p->'gave', '{}'::jsonb);
  v_took jsonb := coalesce(p->'took', '{}'::jsonb);
  d gold.business_days; t gold.transactions;
begin
  if exists (select 1 from gold.drawer_movements where id = v_id) then
    return jsonb_build_object('replayed', true, 'data', gold.movement_json(v_id));
  end if;
  select * into d from gold.business_days where id = v_day and branch_id = v_branch;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That day was not found.'); end if;
  if d.status <> 'open' then
    v_day := gold.open_day_id(v_branch);
    if v_day is null then perform gold.fail(409, 'DAY_CLOSED', 'This day is closed and no day is open. Open the day, then send it again.'); end if;
    v_note := 'Made before the day closed: ' || coalesce(v_note, 'notes changed');
  end if;
  if gold.lines_total(v_gave) = 0 or gold.lines_total(v_took) = 0 then
    perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the notes the customer gives back and the notes you hand out.');
  end if;
  if gold.lines_total(v_gave) <> gold.lines_total(v_took) then
    perform gold.fail(422, 'EXCHANGE_MISMATCH', 'The notes given back (' || gold.ts(gold.lines_total(v_gave)) || ') and the notes handed out (' || gold.ts(gold.lines_total(v_took)) || ') must be worth the same.');
  end if;
  if exists (select 1 from jsonb_object_keys(v_gave) k where v_took ? k) then
    perform gold.fail(422, 'EXCHANGE_SAME_NOTE', 'Hand out different notes from the ones given back.');
  end if;
  if v_tx is not null then
    select * into t from gold.transactions where id = v_tx;
    if not found or t.branch_id <> v_branch then perform gold.fail(404, 'NOT_FOUND', 'That purchase was not found at this branch.'); end if;
    if t.status = 'void' then perform gold.fail(409, 'TRANSACTION_VOID', 'That purchase was cancelled.'); end if;
    v_note := coalesce(v_note, 'Notes changed for ' || t.reference);
  end if;
  v_note := coalesce(v_note, 'Notes changed');

  insert into gold.drawer_movements (id, tenant_id, branch_id, business_day_id, kind, note, occurred_at, created_by, transaction_id)
  values (v_id, v_tenant, v_branch, v_day, 'exchange', v_note, v_at, v_user, v_tx);
  perform gold.post_cash(v_branch, v_day, v_at, v_gave, 1, 'drawer_movement', v_id, v_note);
  perform gold.post_cash(v_branch, v_day, v_at, v_took, -1, 'drawer_movement', v_id, v_note);
  perform gold.audit('drawer.notes_exchanged', 'drawer_movement', v_id::text, null,
    jsonb_build_object('branchId', v_branch, 'dayId', v_day, 'transactionId', v_tx, 'received', v_gave, 'handedOut', v_took, 'value', gold.ts(gold.lines_total(v_gave)), 'note', v_note));
  return jsonb_build_object('replayed', false, 'data', gold.movement_json(v_id));
end $$;


--
-- Name: record_movement(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.record_movement(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant();
  v_user uuid := gold.require_actor();
  v_id uuid := (p->>'id')::uuid;
  v_day uuid := (p->>'dayId')::uuid;
  v_branch uuid := (p->>'branchId')::uuid;
  v_kind text := p->>'kind';
  v_note text := trim(coalesce(p->>'note', ''));
  v_at timestamptz := least((p->>'capturedAt')::timestamptz, now());
  v_people int := nullif(p->>'people', '')::int;
  d gold.business_days;
begin
  if exists (select 1 from gold.drawer_movements where id = v_id) then
    return jsonb_build_object('replayed', true, 'data', gold.movement_json(v_id));
  end if;
  select * into d from gold.business_days where id = v_day and branch_id = v_branch;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That day was not found.'); end if;
  if d.status <> 'open' then
    -- Saved on a device while the day was open, reaching us after it closed. The cash really moved, so it is recorded in the day
    -- that is open now (never in the sealed one), and says so. With no day open it still has nowhere to go.
    v_day := gold.open_day_id(v_branch);
    if v_day is null then perform gold.fail(409, 'DAY_CLOSED', 'This day is closed and no day is open. Open the day, then send it again.'); end if;
    v_note := 'Made before the day closed: ' || v_note;
  end if;
  if v_kind not in ('topup', 'withdrawal', 'allowance') then perform gold.fail(422, 'VALIDATION_FAILED', 'kind must be topup, withdrawal or allowance.'); end if;
  if v_kind = 'allowance' then
    if v_people is null or v_people < 1 or v_people > 200 then perform gold.fail(422, 'VALIDATION_FAILED', 'Say how many people the office allowance is for.'); end if;
    if not gold.has_text(v_note, 1) then v_note := 'Office allowance for ' || v_people || ' ' || case when v_people = 1 then 'person' else 'people' end; end if;
  elsif v_people is not null then v_people := null; end if;
  if not gold.has_text(v_note, 1) then perform gold.fail(422, 'VALIDATION_FAILED', 'Write a note saying what the money is for.'); end if;
  if gold.lines_total(p->'lines') = 0 then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter at least one note.'); end if;

  insert into gold.drawer_movements (id, tenant_id, branch_id, business_day_id, kind, note, occurred_at, created_by, people)
  values (v_id, v_tenant, v_branch, v_day, v_kind, v_note, v_at, v_user, v_people);
  perform gold.post_cash(v_branch, v_day, v_at, p->'lines', case when v_kind = 'topup' then 1 else -1 end, 'drawer_movement', v_id, v_note);
  return jsonb_build_object('replayed', false, 'data', gold.movement_json(v_id));
end $$;


--
-- Name: record_transfer_payment(uuid, jsonb, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.record_transfer_payment(p_id uuid, p jsonb, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  t gold.transfers; v_user uuid := gold.require_actor(); v_branch uuid := (p->>'branchId')::uuid; v_dir text := p->>'direction';
  v_method text := coalesce(p->>'method', 'cash'); v_amount numeric := (p->>'amount')::numeric; v_pay uuid := coalesce((p->>'id')::uuid, gen_random_uuid());
  v_day uuid;
begin
  t := gold.transfer_for(p_id, 'either', p_scope);
  if exists (select 1 from gold.transfer_payments where id = v_pay) then return gold.transfer_json(p_id); end if;
  if t.status not in ('released', 'received', 'received_with_discrepancy') then
    perform gold.fail(409, 'TRANSFER_NOT_RELEASED', 'Payments are recorded after the transfer is released.');
  end if;
  if v_branch is distinct from t.origin_branch_id and v_branch is distinct from t.destination_branch_id then
    perform gold.fail(422, 'VALIDATION_FAILED', 'Say which end of the transfer made the payment.');
  end if;
  perform gold.in_scope(v_branch, p_scope);
  if v_dir not in ('paid_to_collector', 'received_from_collector') then perform gold.fail(422, 'VALIDATION_FAILED', 'direction must be paid_to_collector or received_from_collector.'); end if;
  if v_method not in ('cash', 'mobile_money', 'bank', 'other') then perform gold.fail(422, 'VALIDATION_FAILED', 'Unknown payment method.'); end if;
  if v_amount is null or v_amount <= 0 then perform gold.fail(422, 'VALIDATION_FAILED', 'The amount must be above zero.'); end if;
  if not gold.has_text(p->>'purpose', 1) then perform gold.fail(422, 'VALIDATION_FAILED', 'Write what the money is for.'); end if;

  insert into gold.transfer_payments (id, tenant_id, transfer_id, direction, amount, method, purpose, external_ref, paid_at, recorded_by, note)
  values (v_pay, gold.current_tenant(), p_id, v_dir, v_amount, v_method, trim(p->>'purpose'), nullif(trim(coalesce(p->>'externalRef', '')), ''), now(), v_user,
          nullif(trim(coalesce(p->>'note', '')), ''));
  if v_method = 'cash' then
    if gold.lines_total(p->'lines') <> v_amount then perform gold.fail(422, 'PAYOUT_MISMATCH', 'The notes do not add up to the amount.'); end if;
    v_day := gold.open_day_id(v_branch);
    if v_day is null then perform gold.fail(409, 'DAY_NOT_OPEN', 'Open the day at that branch first.'); end if;
    perform gold.post_cash(v_branch, v_day, now(), p->'lines', case when v_dir = 'paid_to_collector' then -1 else 1 end, 'transfer_payment', v_pay,
                           trim(p->>'purpose') || ' (' || t.reference || ')');
  end if;
  perform gold.transfer_event(p_id, 'payment_recorded', jsonb_build_object('direction', v_dir, 'amount', gold.ts(v_amount), 'method', v_method, 'branchId', v_branch));
  return gold.transfer_json(p_id);
end $$;


--
-- Name: register_device_key(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.register_device_key(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare v_user uuid := gold.require_actor(); v_dev text := trim(coalesce(p->>'deviceId', '')); v_key text := trim(coalesce(p->>'publicKey', ''));
begin
  if char_length(v_dev) < 8 or char_length(v_dev) > 80 then perform gold.fail(422, 'VALIDATION_FAILED', 'deviceId must be 8 to 80 characters.'); end if;
  if char_length(v_key) < 80 or char_length(v_key) > 400 then perform gold.fail(422, 'VALIDATION_FAILED', 'publicKey is not valid.'); end if;
  insert into gold.device_keys (tenant_id, user_id, device_id, public_key) values (gold.current_tenant(), v_user, v_dev, v_key)
  on conflict (tenant_id, user_id, device_id) do update set public_key = excluded.public_key, revoked_at = null, created_at = now();
  return jsonb_build_object('ok', true);
end $$;


--
-- Name: release_transfer(uuid, jsonb, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.release_transfer(p_id uuid, p jsonb, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  t gold.transfers; v_user uuid := gold.require_actor(); v_day uuid; v_at timestamptz := now(); v_top numeric; v_down numeric; v_value numeric; v_cash numeric;
begin
  t := gold.transfer_for(p_id, 'origin', p_scope);
  if t.status <> 'draft' then perform gold.fail(409, 'ALREADY_RELEASED', 'This transfer is not a draft any more.'); end if;
  if t.collector_type is null then perform gold.fail(422, 'COLLECTOR_REQUIRED', 'Say who is carrying it before it is released.'); end if;
  v_day := gold.open_day_id(t.origin_branch_id);
  if v_day is null then perform gold.fail(409, 'DAY_NOT_OPEN', 'Open the day at the sending branch first.'); end if;

  if t.kind = 'goods' then
    select sum(released_top), sum(released_down), sum(released_value) into v_top, v_down, v_value from gold.transfer_goods_lines where transfer_id = p_id;
    if v_top is null then perform gold.fail(422, 'NO_GOODS', 'Add at least one piece of gold.'); end if;
    update gold.transaction_items set location_state = 'in_transit'
      where id in (select transaction_item_id from gold.transfer_goods_lines where transfer_id = p_id and transaction_item_id is not null);
    perform gold.post_goods(t.origin_branch_id, v_day, v_at, -v_top, -v_down, -v_value, 'transfer_release', p_id, 'Sent on ' || t.reference);
    update gold.transfers set status = 'released', released_by = v_user, released_at = v_at, release_note = nullif(trim(coalesce(p->>'note', '')), ''),
      collected_at = coalesce(nullif(p->>'collectedAt', '')::timestamptz, v_at), declared_top = v_top, declared_down = v_down, declared_value = v_value
    where id = p_id;
  else
    v_cash := gold.lines_total(p->'lines');
    if v_cash <= 0 then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the notes being sent.'); end if;
    perform gold.post_cash(t.origin_branch_id, v_day, v_at, p->'lines', -1, 'transfer_release', p_id, 'Cash sent on ' || t.reference);
    update gold.transfers set status = 'released', released_by = v_user, released_at = v_at, release_note = nullif(trim(coalesce(p->>'note', '')), ''),
      collected_at = coalesce(nullif(p->>'collectedAt', '')::timestamptz, v_at), declared_cash = v_cash
    where id = p_id;
  end if;
  perform gold.transfer_event(p_id, 'released', jsonb_build_object('kind', t.kind, 'note', p->>'note'));
  return gold.transfer_json(p_id);
end $$;


--
-- Name: repay_debt(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.repay_debt(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant();
  v_user uuid := gold.require_actor();
  v_id uuid := (p->>'id')::uuid;
  v_debt uuid := (p->>'debtId')::uuid;
  v_amount numeric := (p->>'amount')::numeric;
  v_method text := coalesce(p->>'method', 'cash');
  v_at timestamptz := least((p->>'capturedAt')::timestamptz, now());
  d record; v_day uuid; v_payer uuid := nullif(p->>'paidByBranchId', '')::uuid;
begin
  if exists (select 1 from gold.debt_repayments where id = v_id) then
    return jsonb_build_object('replayed', true, 'data', gold.debt_json(v_debt));
  end if;
  perform 1 from gold.debts where id = v_debt for update;
  select * into d from gold.v_debts_outstanding where id = v_debt;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Debt was not found.'); end if;
  if d.status <> 'open' then perform gold.fail(409, 'DEBT_CLOSED', 'This debt is already closed.'); end if;
  if v_method not in ('cash', 'mobile_money', 'bank', 'other') then
    perform gold.fail(422, 'VALIDATION_FAILED', 'Gold repayments are made by buying the gold, not here.');
  end if;
  if v_amount is null or v_amount <= 0 then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the amount.'); end if;
  if v_amount > d.outstanding then perform gold.fail(422, 'OVERPAYMENT', 'That is more than is outstanding (' || gold.ts(d.outstanding) || ').'); end if;
  if v_method = 'cash' and gold.lines_total(p->'lines') <> v_amount then
    perform gold.fail(422, 'PAYOUT_MISMATCH', 'The notes do not add up to the amount.');
  end if;
  if v_method = 'mobile_money' then
    v_payer := coalesce(v_payer, case when d.direction = 'receivable' then d.branch_id end);
    if v_payer is null then perform gold.fail(422, 'VALIDATION_FAILED', 'Say which branch sent the mobile money.'); end if;
  end if;
  v_day := gold.open_day_id(d.branch_id);

  insert into gold.debt_repayments (id, tenant_id, debt_id, amount, received_at, received_by, note, method, paid_by_branch_id, external_ref)
  values (v_id, v_tenant, v_debt, v_amount, v_at, v_user, nullif(trim(p->>'note'), ''), v_method, v_payer, nullif(trim(p->>'externalRef'), ''));

  if d.direction = 'receivable' then
    perform gold.post_value('debt', d.branch_id, v_day, v_at, -v_amount, 'debt_repayment', v_id, 'Debt repayment');
    if v_method = 'cash' then perform gold.post_cash(d.branch_id, v_day, v_at, p->'lines', 1, 'debt_repayment', v_id, 'Debt repayment'); end if;
  else
    perform gold.post_value('payable', d.branch_id, v_day, v_at, -v_amount, 'payable_settlement', v_id, 'Owed amount paid');
    if v_method = 'cash' then perform gold.post_cash(d.branch_id, v_day, v_at, p->'lines', -1, 'payable_settlement', v_id, 'Owed amount paid'); end if;
  end if;

  if v_amount = d.outstanding then
    update gold.debts set status = 'settled', closed_at = v_at, closed_by = v_user where id = v_debt;
  end if;
  return jsonb_build_object('replayed', false, 'data', gold.debt_json(v_debt));
end $$;


--
-- Name: require_actor(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.require_actor() RETURNS uuid
    LANGUAGE plpgsql STABLE
    AS $$
declare u uuid := gold.current_actor();
begin
  if u is null then perform gold.fail(401, 'UNAUTHENTICATED', 'Please sign in.'); end if;
  return u;
end $$;


--
-- Name: reset_user_password(uuid, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.reset_user_password(p_id uuid, p_hash text) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
begin
  if p_id = gold.require_actor() then perform gold.fail(409, 'USE_CHANGE_PASSWORD', 'Use "change my password" for your own account.'); end if;
  if coalesce(p_hash, '') = '' then perform gold.fail(422, 'VALIDATION_FAILED', 'A temporary password is needed.'); end if;
  update gold.users set password_hash = p_hash, must_change_password = true, failed_login_count = 0, locked_until = null where id = p_id;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'User was not found.'); end if;
  update gold.refresh_tokens set revoked_at = now() where user_id = p_id and revoked_at is null;
  perform gold.audit('user.password_reset', 'user', p_id::text, null, null);
  return gold.user_admin_json(p_id);
end $$;


--
-- Name: resolve_payment(uuid, text, uuid[], jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.resolve_payment(p_payment uuid, p_outcome text, p_scope uuid[], p_replacements jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_user uuid := gold.require_actor(); pm gold.transaction_payments; t gold.transactions; pay jsonb; v_sum numeric := 0;
begin
  select * into pm from gold.transaction_payments where id = p_payment for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Payment was not found.'); end if;
  if pm.method <> 'mobile_money' then perform gold.fail(409, 'NOT_MOBILE_MONEY', 'Only mobile money payments are confirmed.'); end if;
  if pm.status <> 'pending' then perform gold.fail(409, 'ALREADY_RESOLVED', 'This payment was already confirmed or marked failed.'); end if;
  if not (pm.paid_by_branch_id = any(p_scope)) then
    perform gold.fail(403, 'FORBIDDEN', 'Only someone at the branch that sent the money can confirm it.');
  end if;
  select * into t from gold.transactions where id = pm.transaction_id;

  if p_outcome = 'confirmed' then
    update gold.transaction_payments set status = 'confirmed', confirmed_by = v_user, confirmed_at = now() where id = p_payment;
  elsif p_outcome = 'failed' then
    for pay in select * from jsonb_array_elements(coalesce(p_replacements, '[]'::jsonb)) loop v_sum := v_sum + (pay->>'amount')::numeric; end loop;
    if v_sum <> pm.amount then
      perform gold.fail(422, 'PAYOUT_MISMATCH', 'The replacement payments (' || gold.ts(v_sum) || ') must cover the failed ' || gold.ts(pm.amount) || '.');
    end if;
    update gold.transaction_payments set status = 'failed', confirmed_by = v_user, confirmed_at = now() where id = p_payment;
    for pay in select * from jsonb_array_elements(p_replacements) loop
      perform gold.apply_payment(t.id, t.branch_id, gold.open_day_id(t.branch_id), now(), t.customer_id, t.reference, pay);
    end loop;
  else
    perform gold.fail(422, 'VALIDATION_FAILED', 'Outcome must be confirmed or failed.');
  end if;
  return gold.transaction_json(t.id);
end $$;


--
-- Name: resolve_town(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.resolve_town(p jsonb) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare
  v_name text; v_key text; v_id uuid; v_new uuid;
begin
  if p is null or jsonb_typeof(p) <> 'object' then return null; end if;
  v_name := trim(regexp_replace(coalesce(p->>'name', ''), '\s+', ' ', 'g'));
  if v_name = '' then
    -- an id on its own: it must be one of ours
    if nullif(p->>'id', '') is null then return null; end if;
    select id into v_id from gold.origin_towns where id = (p->>'id')::uuid;
    if v_id is null then perform gold.fail(422, 'VALIDATION_FAILED', 'That town is not in your list. Type its name to add it.'); end if;
    return v_id;
  end if;
  if char_length(v_name) < 2 or char_length(v_name) > 80 then perform gold.fail(422, 'VALIDATION_FAILED', 'A town name is 2 to 80 letters.'); end if;
  v_key := gold.town_key(v_name);
  if v_key = '' then perform gold.fail(422, 'VALIDATION_FAILED', 'A town name needs letters or numbers.'); end if;
  select id into v_id from gold.origin_towns where name_key = v_key;
  if v_id is not null then return v_id; end if;
  v_new := coalesce(nullif(p->>'id', '')::uuid, gen_random_uuid());
  insert into gold.origin_towns (id, tenant_id, name, name_key, created_by) values (v_new, gold.current_tenant(), v_name, v_key, gold.current_actor())
  on conflict (tenant_id, name_key) do nothing;
  select id into v_id from gold.origin_towns where name_key = v_key;
  return v_id;
end $$;


--
-- Name: return_collateral(uuid, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.return_collateral(p_id uuid, p_note text) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare v_user uuid := gold.require_actor(); h gold.collateral_holdings; v_out numeric;
begin
  select * into h from gold.collateral_holdings where id = p_id for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That security was not found.'); end if;
  if h.status <> 'held' then perform gold.fail(409, 'COLLATERAL_NOT_HELD', 'This gold is no longer held.'); end if;
  select outstanding into v_out from gold.v_debts_outstanding where id = h.debt_id;
  if v_out > 0 then perform gold.fail(409, 'DEBT_NOT_SETTLED', 'The loan still has ' || gold.ts(v_out) || ' outstanding.'); end if;
  update gold.collateral_holdings set status = 'returned', closed_by = v_user, closed_at = now(), close_note = nullif(trim(p_note), '') where id = p_id;
  perform gold.post_custody(h.branch_id, gold.open_day_id(h.branch_id), now(), -h.top_weight, 'custody_out', p_id, 'Gold handed back unrefined');
  return gold.collateral_json(p_id);
end $$;


--
-- Name: revoke_refresh_family(bytea); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.revoke_refresh_family(p_hash bytea) RETURNS void
    LANGUAGE sql
    AS $$
  update gold.refresh_tokens set revoked_at = now()
  where revoked_at is null and family_id = (select family_id from gold.refresh_tokens where token_hash = p_hash)
$$;


--
-- Name: role_json(text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.role_json(p_key text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select r from jsonb_array_elements(gold.roles_json()) r where r->>'key' = p_key
$$;


--
-- Name: roles_json(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.roles_json() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(jsonb_build_object(
    'key', r.key, 'name', r.name, 'isSystem', r.is_system, 'description', r.description,
    'permissions', coalesce((select jsonb_agg(rp.permission order by rp.permission) from gold.role_permissions rp where rp.role_id = r.id), '[]'::jsonb),
    'activeMembers', (select count(*) from gold.users u where u.role_id = r.id and u.is_active),
    'members', coalesce((select jsonb_agg(jsonb_build_object('id', u.id, 'name', u.display_name, 'username', u.username::text, 'isActive', u.is_active)
                                          order by u.is_active desc, u.display_name) from gold.users u where u.role_id = r.id), '[]'::jsonb))
    order by r.is_system desc, r.name), '[]'::jsonb)
  from gold.roles r
$$;


--
-- Name: rotate_refresh_token(bytea, bytea, timestamp with time zone, text, inet, interval); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.rotate_refresh_token(p_old bytea, p_new bytea, p_expires timestamp with time zone, p_user_agent text, p_ip inet, p_grace interval DEFAULT '00:00:10'::interval) RETURNS TABLE(o_outcome text, o_user_id uuid, o_family_id uuid)
    LANGUAGE plpgsql
    AS $$
declare
  t gold.refresh_tokens;
  active boolean;
  new_id uuid := gen_random_uuid();
begin
  select * into t from gold.refresh_tokens where token_hash = p_old for update;
  if not found then
    return query select 'unknown'::text, null::uuid, null::uuid;
    return;
  end if;

  if t.revoked_at is not null then
    if t.replaced_by is null then
      return query select 'revoked'::text, t.user_id, t.family_id;
    elsif now() - t.revoked_at <= p_grace then
      return query select 'race'::text, t.user_id, t.family_id;
    else
      update gold.refresh_tokens set revoked_at = now() where family_id = t.family_id and revoked_at is null;
      return query select 'reused'::text, t.user_id, t.family_id;
    end if;
    return;
  end if;

  select u.is_active into active from gold.users u where u.id = t.user_id;
  if not coalesce(active, false) then
    update gold.refresh_tokens set revoked_at = now() where family_id = t.family_id and revoked_at is null;
    return query select 'revoked'::text, t.user_id, t.family_id;
    return;
  end if;

  if t.expires_at <= now() then
    return query select 'expired'::text, t.user_id, t.family_id;
    return;
  end if;

  insert into gold.refresh_tokens (id, tenant_id, user_id, family_id, token_hash, expires_at, user_agent, ip)
  values (new_id, t.tenant_id, t.user_id, t.family_id, p_new, p_expires, p_user_agent, p_ip);
  update gold.refresh_tokens set revoked_at = now(), replaced_by = new_id where id = t.id;
  return query select 'ok'::text, t.user_id, t.family_id;
end $$;


--
-- Name: set_base_price(numeric, timestamp with time zone); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.set_base_price(p_base numeric, p_published timestamp with time zone) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare v_user uuid := gold.require_actor(); v_snap uuid;
begin
  if p_base is null or p_base <= 0 then perform gold.fail(422, 'VALIDATION_FAILED', 'The price must be above zero.'); end if;
  insert into gold.price_snapshots (tenant_id, source, base_price, published_at, created_by)
  values (gold.current_tenant(), 'manual', p_base, least(coalesce(p_published, now()), now()), v_user) returning id into v_snap;
  perform gold.carry_branch_prices(v_snap, v_user, true);
  return jsonb_build_object('snapshotId', v_snap);
end $$;


--
-- Name: set_guide_reminders(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.set_guide_reminders(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $_$
declare v_tenant uuid := gold.current_tenant(); v_actor uuid := gold.require_actor(); f text := coalesce(p->>'frequency', 'off'); t text := coalesce(p->>'time', '08:00');
  d int := coalesce((p->>'weekday')::int, 1); w text := coalesce(p->>'audience', 'unread');
begin
  if f not in ('off', 'daily', 'weekly', 'monthly') then perform gold.fail(422, 'VALIDATION_FAILED', 'Choose off, daily, weekly or monthly.'); end if;
  if t !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' then perform gold.fail(422, 'VALIDATION_FAILED', 'Give the time as hours and minutes, for example 08:00.'); end if;
  if d not between 1 and 7 then perform gold.fail(422, 'VALIDATION_FAILED', 'Choose a day of the week.'); end if;
  if w not in ('unread', 'everyone') then perform gold.fail(422, 'VALIDATION_FAILED', 'Choose who is reminded.'); end if;
  insert into gold.guide_settings (tenant_id, frequency, remind_time, weekday, audience, updated_by) values (v_tenant, f, t, d, w, v_actor)
  on conflict (tenant_id) do update set frequency = f, remind_time = t, weekday = d, audience = w, updated_by = v_actor, updated_at = now(),
    last_sent_on = case when gold.guide_settings.frequency = f and gold.guide_settings.remind_time = t then gold.guide_settings.last_sent_on else null end;
  if f <> 'off' then insert into gold.guide_reminder_registry (tenant_id) values (v_tenant) on conflict do nothing;
  else delete from gold.guide_reminder_registry where tenant_id = v_tenant; end if;
  perform gold.audit('guide.reminders_changed', 'guide_settings', v_tenant::text, null, jsonb_build_object('frequency', f, 'time', t, 'weekday', d, 'audience', w));
  return gold.guide_reminders_json();
end $_$;


--
-- Name: set_margin(uuid, numeric, boolean); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.set_margin(p_branch uuid, p_margin numeric, p_approve boolean) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare v_user uuid := gold.require_actor(); v_snap uuid;
begin
  perform 1 from gold.branches where id = p_branch and is_active;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Branch was not found.'); end if;
  if p_margin is null then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the margin.'); end if;
  select id into v_snap from gold.price_snapshots order by published_at desc, fetched_at desc limit 1;
  if v_snap is null then perform gold.fail(409, 'NO_BASE_PRICE', 'Set the reference price first.'); end if;
  insert into gold.branch_prices (tenant_id, branch_id, snapshot_id, margin, status, set_by, approved_by, approved_at, effective_from, created_at)
  values (gold.current_tenant(), p_branch, v_snap, p_margin, case when p_approve then 'approved' else 'provisional' end, v_user,
          case when p_approve then v_user end, case when p_approve then now() end, clock_timestamp(), clock_timestamp());
  return gold.current_price(p_branch);
end $$;


--
-- Name: set_price_feed_settings(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.set_price_feed_settings(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $_$
declare
  v_tenant uuid := gold.current_tenant(); v_user uuid := gold.require_actor(); w jsonb; v_wd smallint[]; v_policy text := coalesce(p->>'marginPolicy', 'approve');
  v_jump numeric := coalesce((p->>'maxJumpPct')::numeric, 10); v_tz text := coalesce(nullif(p->>'timezone', ''), 'Africa/Accra'); v_on boolean := coalesce((p->>'enabled')::boolean, false);
begin
  if jsonb_typeof(p->'windows') <> 'array' or jsonb_array_length(p->'windows') > 6 or (v_on and jsonb_array_length(p->'windows') = 0) then
    perform gold.fail(422, 'VALIDATION_FAILED', 'Give 1 to 6 check times.');
  end if;
  for w in select * from jsonb_array_elements(p->'windows') loop
    if (w->>'start') !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' or (w->>'end') !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$' or (w->>'start') >= (w->>'end') then
      perform gold.fail(422, 'VALIDATION_FAILED', 'Each check time needs a start and a later end, like 10:30 to 11:30.');
    end if;
    if coalesce((w->>'everyMinutes')::int, 0) not between 1 and 120 then perform gold.fail(422, 'VALIDATION_FAILED', 'Check every 1 to 120 minutes.'); end if;
  end loop;
  select coalesce(array_agg(distinct x::smallint order by x::smallint), '{}') into v_wd from jsonb_array_elements_text(coalesce(p->'weekdays', '[]'::jsonb)) x where x::int between 1 and 7;
  if cardinality(v_wd) = 0 then perform gold.fail(422, 'VALIDATION_FAILED', 'Choose at least one day of the week.'); end if;
  if v_policy not in ('approve', 'carry') then perform gold.fail(422, 'VALIDATION_FAILED', 'Unknown margin choice.'); end if;
  if v_jump < 1 or v_jump > 50 then perform gold.fail(422, 'VALIDATION_FAILED', 'The largest change allowed must be between 1 and 50 percent.'); end if;
  if not exists (select 1 from pg_timezone_names where name = v_tz) then perform gold.fail(422, 'VALIDATION_FAILED', 'Unknown time zone.'); end if;

  insert into gold.price_feed_settings (tenant_id, enabled, windows, weekdays, timezone, margin_policy, max_jump_pct, updated_by)
  values (v_tenant, v_on, p->'windows', v_wd, v_tz, v_policy, v_jump, v_user)
  on conflict (tenant_id) do update set enabled = excluded.enabled, windows = excluded.windows, weekdays = excluded.weekdays, timezone = excluded.timezone,
    margin_policy = excluded.margin_policy, max_jump_pct = excluded.max_jump_pct, updated_by = excluded.updated_by, updated_at = now();
  if v_on then insert into gold.price_feed_registry (tenant_id) values (v_tenant) on conflict do nothing;
  else delete from gold.price_feed_registry where tenant_id = v_tenant; end if;
  return gold.price_feed_json();
end $_$;


--
-- Name: set_settings(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.set_settings(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant(); v_user uuid := gold.require_actor();
  v_defaults jsonb := gold.setting_defaults(); v_before jsonb := gold.settings_json(); r record; v_t text;
begin
  if p is null or jsonb_typeof(p) <> 'object' or p = '{}'::jsonb then perform gold.fail(422, 'VALIDATION_FAILED', 'Nothing to change.'); end if;
  for r in select key, value from jsonb_each(p) loop
    if not v_defaults ? r.key then perform gold.fail(422, 'VALIDATION_FAILED', format('"%s" is not a setting.', r.key)); end if;
    v_t := jsonb_typeof(v_defaults -> r.key);
    if jsonb_typeof(r.value) <> v_t then perform gold.fail(422, 'VALIDATION_FAILED', format('The setting "%s" must be a %s.', r.key, v_t)); end if;
    if r.key = 'allowance.perPerson' and ((r.value #>> '{}')::numeric < 0 or (r.value #>> '{}')::numeric > 10000 or (r.value #>> '{}')::numeric <> trunc((r.value #>> '{}')::numeric)) then
      perform gold.fail(422, 'VALIDATION_FAILED', 'The allowance must be a whole number of cedis from 0 to 10,000.');
    end if;
    if r.key = 'receipt.paper' and (r.value #>> '{}') not in ('80', '58', 'a4') then perform gold.fail(422, 'VALIDATION_FAILED', 'Paper must be 80, 58 or a4.'); end if;
    if v_t = 'string' and char_length(r.value #>> '{}') > 200 then perform gold.fail(422, 'VALIDATION_FAILED', format('"%s" is too long (200 characters at most).', r.key)); end if;
    insert into gold.tenant_settings (tenant_id, key, value, updated_by) values (v_tenant, r.key, r.value, v_user)
    on conflict (tenant_id, key) do update set value = excluded.value, updated_by = excluded.updated_by, updated_at = now();
  end loop;
  perform gold.audit('settings.changed', 'settings', v_tenant::text, v_before, gold.settings_json());
  return gold.settings_json();
end $$;


--
-- Name: setting(text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.setting(p_key text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select gold.settings_json() -> p_key
$$;


--
-- Name: setting_defaults(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.setting_defaults() RETURNS jsonb
    LANGUAGE sql IMMUTABLE
    AS $$
  select jsonb_build_object(
    'payout.twoStep', false,
    'payout.sameUserMayPay', true,
    'payout.blindCheck', false,
    'count.blind', false,
    'customers.autoCreate', true,
    'offline.maxDays', 7,
    'allowance.perPerson', 100,
    'receipt.printer', false,
    'receipt.paper', '80',
    'receipt.businessName', '',
    'receipt.tagline', '',
    'receipt.address', '',
    'receipt.phone', '',
    'receipt.footer', '')
$$;


--
-- Name: settings_json(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.settings_json() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select gold.setting_defaults() || coalesce((select jsonb_object_agg(key, value) from gold.tenant_settings), '{}'::jsonb)
$$;


--
-- Name: signoff_day(uuid, text, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.signoff_day(p_day uuid, p_decision text, p_note text) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare v_user uuid := gold.require_actor(); d gold.business_days; v_note text := nullif(trim(coalesce(p_note, '')), '');
begin
  select * into d from gold.business_days where id = p_day for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That day was not found.'); end if;
  if d.status <> 'closed' or d.signoff_status <> 'pending' then
    perform gold.fail(409, 'NOTHING_TO_SIGN', 'This day has no closing difference waiting for sign-off.');
  end if;
  if p_decision not in ('approved', 'rejected') then perform gold.fail(422, 'VALIDATION_FAILED', 'Decision must be approved or rejected.'); end if;
  if p_decision = 'rejected' and not gold.has_text(v_note, 5) then
    perform gold.fail(422, 'VALIDATION_FAILED', 'Say why you reject it (at least 5 characters).');
  end if;
  if d.closed_by = v_user then
    perform gold.fail(403, 'SELF_SIGNOFF', 'The person who closed the day cannot sign it off.');
  end if;
  update gold.business_days set signoff_status = p_decision, signoff_by = v_user, signoff_at = now(), signoff_note = v_note where id = p_day;
  return gold.day_json(p_day);
end $$;


--
-- Name: staff_json(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.staff_json() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(jsonb_build_object('id', id, 'displayName', display_name) order by display_name), '[]'::jsonb)
  from gold.users where is_active
$$;


--
-- Name: sync_apply(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.sync_apply(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant();
  v_user uuid := gold.require_actor();
  v_id uuid := (p->>'id')::uuid;
  v_type text := p->>'type';
  v_payload jsonb := p->'payload';
  v_at timestamptz := nullif(p->>'capturedAt', '')::timestamptz;
  v_branch uuid := nullif(v_payload->>'branchId', '')::uuid;
  v_row gold.sync_commands;
  v_res jsonb; v_code text; v_msg text; v_status text := 'applied'; v_flags text[] := '{}'; v_late numeric;
begin
  select * into v_row from gold.sync_commands where id = v_id;
  if found then
    return jsonb_build_object('id', v_id, 'status', v_row.status, 'code', v_row.code, 'message', v_row.message, 'flags', to_jsonb(v_row.flags), 'replayed', true);
  end if;
  if v_type not in ('transaction.create', 'transaction.pay', 'drawer.movement', 'drawer.exchange', 'day.open', 'day.close') then
    perform gold.fail(422, 'VALIDATION_FAILED', 'Unknown command type.');
  end if;
  if v_payload is null or jsonb_typeof(v_payload) <> 'object' then perform gold.fail(422, 'VALIDATION_FAILED', 'The command has no content.'); end if;

  begin
    v_res := gold.sync_run(v_type, v_payload);
  exception when others then
    if sqlstate not like 'GV%' then raise; end if;      -- a real fault (not a business rule) is an error for the caller, nothing is recorded
    v_code := split_part(sqlerrm, '|', 1);
    v_msg := substr(sqlerrm, char_length(v_code) + 2);
    v_status := gold.sync_failure_kind(v_code);
    if v_status = 'duplicate' then v_status := 'applied'; v_flags := array['duplicate']; v_code := null; v_msg := null; end if;
  end;

  if v_status = 'applied' then
    if coalesce((v_res->>'replayed')::boolean, false) then v_flags := array_append(v_flags, 'already-recorded'); end if;
    if v_at is not null then
      v_late := extract(epoch from (now() - v_at));
      if v_late > 120 then v_flags := array_append(v_flags, 'offline'); end if;
      if v_late > 86400 then v_flags := array_append(v_flags, 'very-late'); end if;
    end if;
  end if;

  insert into gold.sync_commands (id, tenant_id, user_id, device_id, type, payload, branch_id, captured_at, status, code, message, flags)
  values (v_id, v_tenant, v_user, nullif(p->>'deviceId', ''), v_type, v_payload, v_branch, v_at, v_status, v_code, v_msg, v_flags);

  if v_status in ('held', 'rejected') then
    perform gold.notify(v_tenant, 'sync_review', 'An offline entry needs review', v_type || ': ' || coalesce(v_msg, 'could not be applied'), '/sync/review',
                        case when v_branch is null then null else array[v_branch] end, 'discrepancies:review');
  end if;
  return jsonb_build_object('id', v_id, 'status', v_status, 'code', v_code, 'message', v_msg, 'flags', to_jsonb(v_flags), 'replayed', false);
end $$;


--
-- Name: sync_author(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.sync_author(p_user uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object('active', u.is_active,
                            'permissions', coalesce((select jsonb_agg(x) from gold.effective_permissions(u.id) x), '[]'::jsonb))
  from gold.users u where u.id = p_user
$$;


--
-- Name: sync_failure_kind(text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.sync_failure_kind(p_code text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  select case
    when p_code in ('NO_OPEN_DAY', 'DAY_CLOSED', 'DAY_ALREADY_CLOSED', 'DAY_ALREADY_OPEN', 'TRANSACTION_VOID', 'NOT_FOUND') then 'held'
    when p_code = 'ALREADY_PAID' then 'duplicate'
    else 'rejected' end
$$;


--
-- Name: sync_resolve(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.sync_resolve(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_me uuid := gold.require_actor();
  v_id uuid := (p->>'id')::uuid;
  v_act text := p->>'action';
  v_note text := nullif(trim(coalesce(p->>'note', '')), '');
  c gold.sync_commands; v_res jsonb; v_code text; v_msg text; v_kind text;
begin
  select * into c from gold.sync_commands where id = v_id for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That entry was not found.'); end if;
  if c.status not in ('held', 'rejected') then perform gold.fail(409, 'ALREADY_RESOLVED', 'That entry was already dealt with.'); end if;
  if v_act not in ('retry', 'dismiss') then perform gold.fail(422, 'VALIDATION_FAILED', 'action must be retry or dismiss.'); end if;

  if v_act = 'dismiss' then
    if not gold.has_text(v_note, 5) then perform gold.fail(422, 'VALIDATION_FAILED', 'Say why this entry is dismissed (at least 5 characters).'); end if;
    update gold.sync_commands set status = 'dismissed', resolved_by = v_me, resolved_at = now(), resolution = v_note where id = v_id;
    perform gold.audit('sync.dismissed', 'sync_command', v_id::text, jsonb_build_object('type', c.type, 'message', c.message), jsonb_build_object('note', v_note));
    return jsonb_build_object('id', v_id, 'status', 'dismissed');
  end if;

  perform set_config('app.user_id', c.user_id::text, true);       -- the books show who really made it
  begin
    v_res := gold.sync_run(c.type, c.payload);
    perform set_config('app.user_id', v_me::text, true);
    update gold.sync_commands set status = 'applied', code = null, message = null, flags = array_append(c.flags, 'reviewed'),
           resolved_by = v_me, resolved_at = now(), resolution = coalesce(v_note, 'Retried') where id = v_id;
    perform gold.audit('sync.retried', 'sync_command', v_id::text, jsonb_build_object('type', c.type), jsonb_build_object('status', 'applied'));
    return jsonb_build_object('id', v_id, 'status', 'applied');
  exception when others then
    perform set_config('app.user_id', v_me::text, true);
    if sqlstate not like 'GV%' then raise; end if;
    v_code := split_part(sqlerrm, '|', 1);
    v_msg := substr(sqlerrm, char_length(v_code) + 2);
    v_kind := gold.sync_failure_kind(v_code);
    if v_kind = 'duplicate' then
      update gold.sync_commands set status = 'applied', code = null, message = null, flags = array_append(c.flags, 'duplicate'), resolved_by = v_me, resolved_at = now(), resolution = 'Already recorded' where id = v_id;
      return jsonb_build_object('id', v_id, 'status', 'applied');
    end if;
    update gold.sync_commands set status = v_kind, code = v_code, message = v_msg where id = v_id;
    return jsonb_build_object('id', v_id, 'status', v_kind, 'code', v_code, 'message', v_msg);
  end;
end $$;


--
-- Name: sync_review_json(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.sync_review_json() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'held', (select count(*) from gold.sync_commands where status = 'held'),
    'rejected', (select count(*) from gold.sync_commands where status = 'rejected'),
    'items', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', c.id, 'type', c.type, 'status', c.status, 'code', c.code, 'message', c.message, 'flags', to_jsonb(c.flags),
        'capturedAt', gold.iso(c.captured_at), 'receivedAt', gold.iso(c.received_at), 'deviceId', c.device_id,
        'branchId', c.branch_id, 'branchName', b.name,
        'by', jsonb_build_object('id', u.id, 'name', u.display_name),
        'payload', c.payload) order by c.received_at)
      from gold.sync_commands c
      join gold.users u on u.id = c.user_id
      left join gold.branches b on b.id = c.branch_id
      where c.status in ('held', 'rejected')), '[]'::jsonb),
    'recent', coalesce((
      select jsonb_agg(jsonb_build_object('id', r.id, 'type', r.type, 'status', r.status, 'message', r.message, 'resolution', r.resolution,
                                          'resolvedAt', gold.iso(r.resolved_at), 'by', jsonb_build_object('id', u.id, 'name', u.display_name)) order by r.resolved_at desc)
      from (select * from gold.sync_commands where resolved_at is not null order by resolved_at desc limit 20) r
      join gold.users u on u.id = r.user_id), '[]'::jsonb))
$$;


--
-- Name: sync_run(text, jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.sync_run(p_type text, p_payload jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
begin
  return case p_type
    when 'transaction.create' then gold.post_transaction(p_payload)
    when 'transaction.pay'    then gold.pay_transaction(p_payload)
    when 'drawer.movement'    then gold.record_movement(p_payload)
    when 'drawer.exchange'    then gold.record_exchange(p_payload)
    when 'day.open'           then gold.open_day(p_payload)
    when 'day.close'          then gold.close_day(p_payload)
    else null end;
end $$;


--
-- Name: to_pay_json(uuid, text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.to_pay_json(p_branch uuid, p_search text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(gold.transaction_json(x.id) order by x.created_at desc), '[]'::jsonb)
  from (select t.id, t.created_at from gold.transactions t
         where t.branch_id = p_branch and t.stage = 'to_pay' and t.status <> 'void'
           and (nullif(trim(p_search), '') is null
                or t.reference ilike '%' || trim(p_search) || '%' or t.customer_name ilike '%' || trim(p_search) || '%'
                or t.customer_phone like '%' || regexp_replace(trim(p_search), '\s', '', 'g') || '%')
         order by t.created_at desc limit 100) x
$$;


--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  new.updated_at := now();
  return new;
end $$;


--
-- Name: town_key(text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.town_key(p text) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$
  select lower(regexp_replace(coalesce(p, ''), '[^[:alnum:]]', '', 'g'))
$$;


--
-- Name: towns_json(text); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.towns_json(p_q text DEFAULT NULL::text) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(x order by uses desc, name), '[]'::jsonb) from (
    select o.name, o.id, (select count(*) from gold.transactions t where t.origin_town_id = o.id) as uses
    from gold.origin_towns o
    where nullif(trim(coalesce(p_q, '')), '') is null or o.name_key like '%' || gold.town_key(p_q) || '%'
    order by 3 desc, 1 limit 500
  ) y, lateral (select jsonb_build_object('id', y.id, 'name', y.name, 'uses', y.uses) as x) z
$$;


--
-- Name: transaction_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transaction_json(p_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'id', t.id, 'branchId', t.branch_id, 'reference', t.reference, 'customerId', t.customer_id,
    'customerName', t.customer_name, 'customerPhone', t.customer_phone, 'status', t.status,
    'representative', case when t.represented_by_name is null then null else jsonb_build_object('name', t.represented_by_name, 'phone', t.represented_by_phone) end,
    'originTown', (select jsonb_build_object('id', o.id, 'name', o.name) from gold.origin_towns o where o.id = t.origin_town_id),
    'items', coalesce((select jsonb_agg(jsonb_build_object(
        'id', i.id, 'label', i.label, 'top', gold.ts(i.top), 'down', gold.ts(i.down), 'price', gold.ts(i.price),
        'result', jsonb_build_object('density', gold.ts(i.density), 'karat', gold.ts(i.karat), 'purity', gold.ts(i.purity),
                                     'netWeight', gold.ts(i.net_weight), 'pounds', gold.ts(i.pounds), 'amount', gold.ts(i.amount))) order by i.line_no)
        from gold.transaction_items i where i.transaction_id = t.id), '[]'::jsonb),
    'formulaVersion', t.formula_version, 'calculatedAmount', gold.ts(t.calculated_amount),
    'payout', jsonb_build_object(
        'policy', t.payout_policy, 'strategy', t.payout_strategy, 'payable', gold.ts(t.payable),
        'lines', gold.lines_json('transaction_payout', t.id), 'difference', gold.ts(t.payout_difference),
        'totalNotes', (select coalesce(sum(abs(delta_count)), 0) from gold.ledger_entries
                       where asset = 'cash' and source_type = 'transaction_payout' and source_id = t.id),
        'stage', t.stage, 'cashDue', gold.ts(t.cash_due), 'suggestedLines', case when t.stage = 'to_pay' then t.suggested_lines else null end,
        'paidBy', case when t.paid_by is null then null else gold.person_json(t.paid_by) end,
        'paidAt', case when t.paid_at is null then null else gold.iso(t.paid_at) end,
        'checkMatched', t.check_matched),
    'payments', coalesce((select jsonb_agg(gold.payment_json(p.id) order by p.created_at, p.id)
                          from gold.transaction_payments p where p.transaction_id = t.id), '[]'::jsonb),
    'capturedAt', gold.iso(t.captured_at), 'createdAt', gold.iso(t.created_at), 'createdBy', gold.person_json(t.created_by),
    'flags', to_jsonb(t.flags),
    'priceAsOf', gold.iso(t.price_as_of),
    'voidedAt', case when t.voided_at is null then null else gold.iso(t.voided_at) end,
    'voidReason', t.void_reason,
    'voidedBy', case when t.voided_by is null then null else gold.person_json(t.voided_by) end)
  from gold.transactions t where t.id = p_id
$$;


--
-- Name: transactions_export_json(uuid, timestamp with time zone, timestamp with time zone, integer); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transactions_export_json(p_branch uuid, p_from timestamp with time zone, p_to timestamp with time zone, p_limit integer) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  with picked as (
    select t.* from gold.transactions t
    where t.branch_id = p_branch
      and (p_from is null or t.captured_at >= p_from) and (p_to is null or t.captured_at < p_to)
    order by t.captured_at, t.created_at
    limit least(coalesce(p_limit, 5000), 5000) + 1
  ), shown as (select * from picked order by captured_at, created_at limit least(coalesce(p_limit, 5000), 5000))
  select jsonb_build_object(
    'truncated', (select count(*) from picked) > least(coalesce(p_limit, 5000), 5000),
    'rows', coalesce((select jsonb_agg(jsonb_build_object(
        'reference', s.reference, 'capturedAt', gold.iso(s.captured_at), 'status', s.status,
        'customerName', s.customer_name, 'customerPhone', s.customer_phone,
        'pieces', (select count(*) from gold.transaction_items i where i.transaction_id = s.id),
        'topWeight', gold.ts((select coalesce(sum(i.top), 0) from gold.transaction_items i where i.transaction_id = s.id)),
        'netWeight', gold.ts((select coalesce(sum(i.net_weight), 0) from gold.transaction_items i where i.transaction_id = s.id)),
        'calculated', gold.ts(s.calculated_amount), 'payable', gold.ts(s.payable), 'difference', gold.ts(s.payout_difference),
        'cash', gold.ts((select coalesce(sum(p.amount), 0) from gold.transaction_payments p where p.transaction_id = s.id and p.method = 'cash' and p.status <> 'failed')),
        'mobileMoney', gold.ts((select coalesce(sum(p.amount), 0) from gold.transaction_payments p where p.transaction_id = s.id and p.method = 'mobile_money' and p.status <> 'failed')),
        'owed', gold.ts((select coalesce(sum(p.amount), 0) from gold.transaction_payments p where p.transaction_id = s.id and p.method = 'owed')),
        'flags', array_to_string(s.flags, ', '), 'imported', s.imported_batch is not null, 'receiptNo', s.import_ref,
        'createdBy', (select display_name from gold.users u where u.id = s.created_by), 'voidReason', s.void_reason) order by s.captured_at, s.created_at)
      from shown s), '[]'::jsonb))
$$;


--
-- Name: transactions_json(uuid, integer); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transactions_json(p_branch uuid, p_limit integer) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(gold.transaction_json(id) order by captured_at desc, created_at desc), '[]'::jsonb)
  from (select id, captured_at, created_at from gold.transactions where branch_id = p_branch order by captured_at desc, created_at desc limit least(coalesce(p_limit, 50), 200)) x
$$;


--
-- Name: transactions_search(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transactions_search(p jsonb) RETURNS jsonb
    LANGUAGE plpgsql STABLE
    AS $$
declare
  v_scope uuid[] := array(select jsonb_array_elements_text(coalesce(p->'scope', '[]'::jsonb))::uuid);
  v_branch uuid := nullif(p->>'branchId', '')::uuid;
  v_customer uuid := nullif(p->>'customerId', '')::uuid;
  v_q text := nullif(trim(coalesce(p->>'q', '')), '');
  v_from date := nullif(p->>'from', '')::date;
  v_to date := nullif(p->>'to', '')::date;
  v_status text := nullif(p->>'status', '');
  v_flag boolean := coalesce((p->>'flag')::boolean, false);
  v_min numeric := nullif(p->>'minAmount', '')::numeric;
  v_max numeric := nullif(p->>'maxAmount', '')::numeric;
  v_sort text := coalesce(nullif(p->>'sort', ''), 'newest');
  v_limit int := least(greatest(coalesce((p->>'limit')::int, 25), 1), 100);
  v_offset int := greatest(coalesce((p->>'offset')::int, 0), 0);
  v_like text; v_total bigint; v_sum numeric; v_items jsonb;
begin
  if v_sort not in ('newest', 'oldest', 'amount_desc', 'amount_asc') then perform gold.fail(422, 'VALIDATION_FAILED', 'That sort order is not known.'); end if;
  if v_status is not null and v_status not in ('saved', 'paid', 'void') then perform gold.fail(422, 'VALIDATION_FAILED', 'That status is not known.'); end if;
  if v_branch is not null and not (v_branch = any (v_scope)) then perform gold.fail(403, 'FORBIDDEN', 'You do not have access to that branch.'); end if;
  v_like := case when v_q is null then null else '%' || replace(replace(replace(v_q, '\', '\\'), '%', '\%'), '_', '\_') || '%' end;

  with hits as (
    select t.id, t.captured_at, t.created_at, t.payable
    from gold.transactions t join gold.branches b on b.id = t.branch_id
    where t.branch_id = any (v_scope)
      and (v_branch is null or t.branch_id = v_branch)
      and (v_customer is null or t.customer_id = v_customer)
      and (v_like is null or t.customer_name ilike v_like or t.reference ilike v_like or coalesce(t.customer_phone, '') ilike v_like)
      and (v_from is null or (t.captured_at at time zone b.timezone)::date >= v_from)
      and (v_to is null or (t.captured_at at time zone b.timezone)::date <= v_to)
      and (v_status is null or t.status = v_status)
      and (not v_flag or cardinality(t.flags) > 0)
      and (v_min is null or t.payable >= v_min)
      and (v_max is null or t.payable <= v_max)
  ), ranked as (
    select id, row_number() over (order by
        case when v_sort = 'amount_desc' then payable end desc nulls last,
        case when v_sort = 'amount_asc' then payable end asc nulls last,
        case when v_sort = 'oldest' then captured_at end asc,
        case when v_sort in ('newest', 'amount_desc', 'amount_asc') then captured_at end desc,
        created_at desc) as rn
    from hits
  )
  select (select count(*) from hits), (select coalesce(sum(payable), 0) from hits),
         (select coalesce(jsonb_agg(gold.transaction_json(id) order by rn), '[]'::jsonb) from ranked where rn > v_offset and rn <= v_offset + v_limit)
  into v_total, v_sum, v_items;

  return jsonb_build_object('items', v_items, 'total', v_total, 'sumPayable', gold.ts(v_sum));
end $$;


--
-- Name: transfer_add_item(uuid, uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transfer_add_item(p_transfer uuid, p_item uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare t gold.transfers; i gold.transaction_items; n smallint;
begin
  select * into i from gold.transaction_items where id = p_item;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That piece of gold was not found.'); end if;
  select * into t from gold.transfers where id = p_transfer;
  if i.location_branch_id <> t.origin_branch_id or i.location_state <> 'on_hand' then
    perform gold.fail(409, 'ITEM_NOT_AVAILABLE', 'That gold is not on hand at the sending branch.');
  end if;
  if exists (select 1 from gold.transfer_goods_lines l join gold.transfers x on x.id = l.transfer_id
             where l.transaction_item_id = p_item and x.status in ('draft', 'released')) then
    perform gold.fail(409, 'ITEM_ALREADY_ON_TRANSFER', 'That gold is already on another transfer.');
  end if;
  select coalesce(max(line_no), 0) + 1 into n from gold.transfer_goods_lines where transfer_id = p_transfer;
  insert into gold.transfer_goods_lines (tenant_id, transfer_id, line_no, transaction_item_id, released_top, released_down, released_value)
  values (t.tenant_id, p_transfer, n, p_item, i.top, i.down, gold.item_booked_value(p_item));
  perform gold.transfer_event(p_transfer, 'goods_added', jsonb_build_object('itemId', p_item, 'top', gold.ts(i.top), 'down', gold.ts(i.down)));
end $$;


--
-- Name: transfer_edit(uuid, jsonb, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transfer_edit(p_id uuid, p jsonb, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare t gold.transfers; v_item text; v_line gold.transfer_goods_lines;
begin
  t := gold.transfer_for(p_id, 'origin', p_scope);
  if t.status not in ('draft') and not (t.status = 'released' and p ? 'collector' and not (p ? 'addItemIds' or p ? 'removeLineIds')) then
    perform gold.fail(409, 'TRANSFER_LOCKED', 'Only a draft can have its goods changed; a released transfer can only change its collector.');
  end if;
  if p ? 'addItemIds' then
    if t.kind <> 'goods' then perform gold.fail(422, 'VALIDATION_FAILED', 'Cash transfers have no goods.'); end if;
    for v_item in select jsonb_array_elements_text(p->'addItemIds') loop perform gold.transfer_add_item(p_id, v_item::uuid); end loop;
  end if;
  if p ? 'removeLineIds' then
    for v_item in select jsonb_array_elements_text(p->'removeLineIds') loop
      select * into v_line from gold.transfer_goods_lines where id = v_item::uuid and transfer_id = p_id;
      if found then
        delete from gold.transfer_goods_lines where id = v_line.id;
        perform gold.transfer_event(p_id, 'goods_removed', jsonb_build_object('itemId', v_line.transaction_item_id, 'lineNo', v_line.line_no));
      end if;
    end loop;
  end if;
  if p ? 'collector' then perform gold.transfer_set_collector_row(p_id, p->'collector'); end if;
  update gold.transfers set purpose = coalesce(p->>'purpose', purpose), purpose_note = coalesce(nullif(trim(coalesce(p->>'purposeNote', '')), ''), purpose_note),
    method = coalesce(p->>'method', method), expected_arrival_at = coalesce(nullif(p->>'expectedArrivalAt', '')::timestamptz, expected_arrival_at)
  where id = p_id and status = 'draft';
  return gold.transfer_json(p_id);
end $$;


--
-- Name: transfer_event(uuid, text, jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transfer_event(p_transfer uuid, p_type text, p_data jsonb DEFAULT '{}'::jsonb) RETURNS void
    LANGUAGE sql
    AS $$
  insert into gold.transfer_events (tenant_id, transfer_id, event_type, actor_user_id, occurred_at, data)
  values (gold.current_tenant(), p_transfer, p_type, gold.current_actor(), now(), coalesce(p_data, '{}'))
$$;


--
-- Name: transfers; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.transfers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    reference text NOT NULL,
    origin_branch_id uuid NOT NULL,
    destination_branch_id uuid NOT NULL,
    purpose text NOT NULL,
    purpose_note text,
    method text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    released_by uuid,
    released_at timestamp with time zone,
    release_note text,
    collector_type text,
    collector_user_id uuid,
    collector_name text,
    collector_phone text,
    collector_id_type text,
    collector_id_number text,
    collector_relationship text,
    collected_at timestamp with time zone,
    expected_arrival_at timestamp with time zone,
    declared_top numeric(14,4),
    declared_down numeric(14,4),
    declared_value numeric(18,2),
    received_by uuid,
    received_at timestamp with time zone,
    received_top numeric(14,4),
    received_down numeric(14,4),
    received_value numeric(18,2),
    receipt_note text,
    cancelled_at timestamp with time zone,
    cancelled_by uuid,
    cancel_reason text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    kind text DEFAULT 'goods'::text NOT NULL,
    visit_id uuid,
    declared_cash numeric(18,2),
    received_cash numeric(18,2),
    CONSTRAINT cancelled_is_complete CHECK (((status <> 'cancelled'::text) OR ((cancelled_at IS NOT NULL) AND (cancelled_by IS NOT NULL) AND gold.has_text(cancel_reason, 5)))),
    CONSTRAINT received_is_complete CHECK (((status <> ALL (ARRAY['received'::text, 'received_with_discrepancy'::text])) OR ((received_by IS NOT NULL) AND (received_at IS NOT NULL) AND (((kind = 'goods'::text) AND (received_top IS NOT NULL) AND (received_down IS NOT NULL) AND (received_value IS NOT NULL)) OR ((kind = 'cash'::text) AND (received_cash IS NOT NULL)))))),
    CONSTRAINT released_is_complete CHECK (((status = ANY (ARRAY['draft'::text, 'cancelled'::text])) OR ((released_by IS NOT NULL) AND (released_at IS NOT NULL) AND (collector_type IS NOT NULL) AND (collected_at IS NOT NULL) AND (((kind = 'goods'::text) AND (declared_top IS NOT NULL) AND (declared_down IS NOT NULL) AND (declared_value IS NOT NULL)) OR ((kind = 'cash'::text) AND (declared_cash IS NOT NULL)))))),
    CONSTRAINT transfers_check CHECK ((origin_branch_id <> destination_branch_id)),
    CONSTRAINT transfers_check1 CHECK (((collector_type IS DISTINCT FROM 'staff'::text) OR (collector_user_id IS NOT NULL))),
    CONSTRAINT transfers_check2 CHECK (((collector_type IS DISTINCT FROM 'external'::text) OR gold.has_text(collector_name, 1))),
    CONSTRAINT transfers_collector_type_check CHECK ((collector_type = ANY (ARRAY['staff'::text, 'external'::text]))),
    CONSTRAINT transfers_kind_check CHECK ((kind = ANY (ARRAY['goods'::text, 'cash'::text]))),
    CONSTRAINT transfers_method_check CHECK ((method = ANY (ARRAY['collector_from_destination'::text, 'staff_travelling'::text, 'designated_courier'::text, 'branch_delivery'::text, 'other'::text]))),
    CONSTRAINT transfers_purpose_check CHECK ((purpose = ANY (ARRAY['stock_collection'::text, 'restock_funding'::text, 'cash_return'::text, 'payment_on_collection'::text, 'other'::text]))),
    CONSTRAINT transfers_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'released'::text, 'received'::text, 'received_with_discrepancy'::text, 'cancelled'::text])))
);

ALTER TABLE ONLY gold.transfers FORCE ROW LEVEL SECURITY;


--
-- Name: transfer_for(uuid, text, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transfer_for(p_id uuid, p_end text, p_scope uuid[]) RETURNS gold.transfers
    LANGUAGE plpgsql
    AS $$
declare t gold.transfers;
begin
  select * into t from gold.transfers where id = p_id for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'That transfer was not found.'); end if;
  if p_end = 'origin' then perform gold.in_scope(t.origin_branch_id, p_scope);
  elsif p_end = 'destination' then perform gold.in_scope(t.destination_branch_id, p_scope);
  elsif not (t.origin_branch_id = any(coalesce(p_scope, '{}')) or t.destination_branch_id = any(coalesce(p_scope, '{}'))) then
    perform gold.fail(404, 'NOT_FOUND', 'That transfer was not found.');
  end if;
  return t;
end $$;


--
-- Name: transfer_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transfer_json(p_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'id', t.id, 'reference', t.reference, 'kind', t.kind, 'status', t.status,
    'originBranchId', t.origin_branch_id, 'originBranchName', ob.name,
    'destinationBranchId', t.destination_branch_id, 'destinationBranchName', db.name,
    'purpose', t.purpose, 'purposeNote', t.purpose_note, 'method', t.method,
    'collector', case when t.collector_type is null then null else jsonb_build_object(
        'type', t.collector_type, 'userId', t.collector_user_id,
        'name', coalesce(t.collector_name, (select display_name from gold.users where id = t.collector_user_id)),
        'phone', t.collector_phone, 'idType', t.collector_id_type, 'idNumber', t.collector_id_number,
        'relationship', t.collector_relationship, 'collectedAt', gold.iso(t.collected_at)) end,
    'expectedArrivalAt', gold.iso(t.expected_arrival_at),
    'release', case when t.released_at is null then null else jsonb_build_object(
        'by', gold.person_json(t.released_by), 'at', gold.iso(t.released_at), 'note', t.release_note) end,
    'declared', case when t.released_at is null then null else jsonb_build_object(
        'top', gold.ts(t.declared_top), 'down', gold.ts(t.declared_down), 'value', gold.ts(t.declared_value),
        'cash', gold.ts(t.declared_cash), 'cashLines', gold.lines_json('transfer_release', t.id)) end,
    'receipt', case when t.received_at is null then null else jsonb_build_object(
        'by', gold.person_json(t.received_by), 'at', gold.iso(t.received_at), 'note', t.receipt_note,
        'top', gold.ts(t.received_top), 'down', gold.ts(t.received_down), 'value', gold.ts(t.received_value),
        'cash', gold.ts(t.received_cash), 'cashLines', gold.lines_json('transfer_receipt', t.id)) end,
    'cancellation', case when t.cancelled_at is null then null else jsonb_build_object(
        'by', gold.person_json(t.cancelled_by), 'at', gold.iso(t.cancelled_at), 'reason', t.cancel_reason) end,
    'lines', coalesce((select jsonb_agg(jsonb_build_object(
        'id', l.id, 'lineNo', l.line_no, 'itemId', l.transaction_item_id,
        'description', coalesce(l.description, nullif(i.label, ''), 'Item ' || i.line_no),
        'reference', tx.reference, 'customerName', tx.customer_name,
        'releasedTop', gold.ts(l.released_top), 'releasedDown', gold.ts(l.released_down), 'releasedValue', gold.ts(l.released_value),
        'receivedTop', gold.ts(l.received_top), 'receivedDown', gold.ts(l.received_down), 'receivedValue', gold.ts(l.received_value),
        'outcome', l.outcome) order by l.line_no)
      from gold.transfer_goods_lines l
      left join gold.transaction_items i on i.id = l.transaction_item_id
      left join gold.transactions tx on tx.id = i.transaction_id
      where l.transfer_id = t.id), '[]'::jsonb),
    'payments', coalesce((select jsonb_agg(jsonb_build_object(
        'id', p.id, 'direction', p.direction, 'amount', gold.ts(p.amount), 'method', p.method, 'purpose', p.purpose,
        'externalRef', p.external_ref, 'paidAt', gold.iso(p.paid_at), 'recordedBy', gold.person_json(p.recorded_by), 'note', p.note,
        'lines', gold.lines_json('transfer_payment', p.id)) order by p.paid_at, p.created_at)
      from gold.transfer_payments p where p.transfer_id = t.id), '[]'::jsonb),
    'events', coalesce((select jsonb_agg(jsonb_build_object(
        'id', e.id, 'type', e.event_type, 'by', gold.person_json(e.actor_user_id), 'at', gold.iso(e.occurred_at), 'data', e.data) order by e.id)
      from gold.transfer_events e where e.transfer_id = t.id), '[]'::jsonb),
    'discrepancies', coalesce((select jsonb_agg(jsonb_build_object(
        'id', d.id, 'status', d.status, 'asset', d.asset, 'lineId', d.transfer_line_id,
        'expected', gold.ts(d.expected), 'actual', gold.ts(d.actual), 'difference', gold.ts(d.difference), 'explanation', d.reported_explanation)
        order by d.opened_at) from gold.discrepancies d where d.transfer_id = t.id), '[]'::jsonb),
    'createdBy', gold.person_json(t.created_by), 'createdAt', gold.iso(t.created_at))
  from gold.transfers t
  join gold.branches ob on ob.id = t.origin_branch_id
  join gold.branches db on db.id = t.destination_branch_id
  where t.id = p_id
$$;


--
-- Name: transfer_note(uuid, text, uuid[]); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transfer_note(p_id uuid, p_text text, p_scope uuid[]) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
begin
  perform gold.transfer_for(p_id, 'either', p_scope);
  if not gold.has_text(p_text, 1) then perform gold.fail(422, 'VALIDATION_FAILED', 'Write the note.'); end if;
  perform gold.transfer_event(p_id, 'note_added', jsonb_build_object('text', trim(p_text)));
  return gold.transfer_json(p_id);
end $$;


--
-- Name: transfer_set_collector_row(uuid, jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transfer_set_collector_row(p_transfer uuid, c jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare v_type text := c->>'type'; v_user uuid := nullif(c->>'userId', '')::uuid; v_name text := nullif(trim(coalesce(c->>'name', '')), '');
        old gold.transfers;
begin
  if v_type not in ('staff', 'external') then perform gold.fail(422, 'VALIDATION_FAILED', 'Say whether the collector is staff or someone outside.'); end if;
  if v_type = 'staff' then
    perform 1 from gold.users where id = v_user and is_active;
    if not found then perform gold.fail(422, 'VALIDATION_FAILED', 'Pick the staff member who will carry it.'); end if;
    v_name := null;
  else
    v_user := null;
    if not gold.has_text(v_name, 1) then perform gold.fail(422, 'VALIDATION_FAILED', 'Write the collector''s name.'); end if;
  end if;
  select * into old from gold.transfers where id = p_transfer;
  update gold.transfers set collector_type = v_type, collector_user_id = v_user, collector_name = v_name,
    collector_phone = nullif(trim(coalesce(c->>'phone', '')), ''), collector_id_type = nullif(trim(coalesce(c->>'idType', '')), ''),
    collector_id_number = nullif(trim(coalesce(c->>'idNumber', '')), ''), collector_relationship = nullif(trim(coalesce(c->>'relationship', '')), '')
  where id = p_transfer;
  perform gold.transfer_event(p_transfer, 'collector_set', jsonb_build_object(
    'type', v_type, 'userId', v_user, 'name', v_name, 'phone', c->>'phone', 'idType', c->>'idType', 'idNumber', c->>'idNumber',
    'previous', case when old.collector_type is null then null else jsonb_build_object('type', old.collector_type, 'userId', old.collector_user_id, 'name', old.collector_name) end));
end $$;


--
-- Name: transferable_items_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transferable_items_json(p_branch uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(jsonb_build_object(
      'itemId', i.id, 'transactionId', t.id, 'reference', t.reference, 'customerName', t.customer_name,
      'label', coalesce(nullif(i.label, ''), 'Item ' || i.line_no), 'top', gold.ts(i.top), 'down', gold.ts(i.down),
      'value', gold.ts(gold.item_booked_value(i.id)), 'purchasedAt', gold.iso(t.captured_at))
    order by t.captured_at desc, i.line_no), '[]'::jsonb)
  from gold.transaction_items i join gold.transactions t on t.id = i.transaction_id
  where i.location_branch_id = p_branch and i.location_state = 'on_hand'
    and not exists (select 1 from gold.transfer_goods_lines l join gold.transfers x on x.id = l.transfer_id
                    where l.transaction_item_id = i.id and x.status in ('draft', 'released'))
$$;


--
-- Name: transfers_json(uuid, text, text, integer); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.transfers_json(p_branch uuid, p_status text, p_direction text, p_limit integer DEFAULT 100) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(row order by created desc), '[]'::jsonb) from (
    select t.created_at as created, jsonb_build_object(
      'id', t.id, 'reference', t.reference, 'kind', t.kind, 'status', t.status,
      'originBranchId', t.origin_branch_id, 'originBranchName', ob.name,
      'destinationBranchId', t.destination_branch_id, 'destinationBranchName', db.name,
      'purpose', t.purpose, 'method', t.method,
      'collectorName', coalesce(t.collector_name, (select display_name from gold.users where id = t.collector_user_id)),
      'lineCount', (select count(*) from gold.transfer_goods_lines l where l.transfer_id = t.id),
      'declaredValue', gold.ts(case when t.kind = 'cash' then t.declared_cash else t.declared_value end),
      'receivedValue', gold.ts(case when t.kind = 'cash' then t.received_cash else t.received_value end),
      'hasDiscrepancy', t.status = 'received_with_discrepancy',
      'releasedAt', gold.iso(t.released_at), 'receivedAt', gold.iso(t.received_at), 'createdAt', gold.iso(t.created_at)) as row
    from gold.transfers t
    join gold.branches ob on ob.id = t.origin_branch_id
    join gold.branches db on db.id = t.destination_branch_id
    where (p_status is null or t.status = p_status)
      and case coalesce(p_direction, 'all')
            when 'outgoing' then t.origin_branch_id = p_branch
            when 'incoming' then t.destination_branch_id = p_branch
            else t.origin_branch_id = p_branch or t.destination_branch_id = p_branch end
    order by t.created_at desc limit p_limit
  ) x
$$;


--
-- Name: trg_publish_day(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.trg_publish_day() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare v_name text;
begin
  perform gold.publish(new.tenant_id, 'days', array[new.branch_id]);
  if tg_op = 'UPDATE' and new.signoff_status is distinct from old.signoff_status then
    select name into v_name from gold.branches where id = new.branch_id;
    if new.signoff_status = 'pending' then
      perform gold.notify(new.tenant_id, 'signoff_needed', format('%s closed with differences: sign-off needed', v_name), null, '/drawer/history', array[new.branch_id], 'days:signoff');
    elsif new.signoff_status in ('approved', 'rejected') then
      perform gold.notify_user(new.tenant_id, new.closed_by, 'signoff_decided', format('Your closing at %s was %s', v_name, new.signoff_status), new.signoff_note, '/drawer/history');
      -- A rejection is not the end of it: the cases stay open for review, with the reason written on each, and reviewers are told.
      if new.signoff_status = 'rejected' then
        update gold.discrepancies set status = 'under_review', resolved_at = null, resolved_by = null, resolution_type = null, resolution_summary = null
         where business_day_id = new.id and status in ('resolved', 'written_off');
        insert into gold.discrepancy_actions (tenant_id, discrepancy_id, action_type, note, actor_user_id)
        select d.tenant_id, d.id, 'note', 'Closing rejected: ' || coalesce(new.signoff_note, ''), new.signoff_by
        from gold.discrepancies d where d.business_day_id = new.id;
        perform gold.notify(new.tenant_id, 'signoff_rejected', format('The closing at %s was rejected', v_name), new.signoff_note, '/review/cases', array[new.branch_id], 'discrepancies:review');
      end if;
    end if;
  end if;
  return null;
end $$;


--
-- Name: trg_publish_discrepancy(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.trg_publish_discrepancy() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare v_name text;
begin
  perform gold.publish(new.tenant_id, 'review', array[new.branch_id]);
  if tg_op = 'INSERT' then
    select name into v_name from gold.branches where id = new.branch_id;
    perform gold.notify(new.tenant_id, 'difference_opened', format('A difference needs a look at %s', v_name), null, '/review/cases', array[new.branch_id], 'discrepancies:review');
  end if;
  return null;
end $$;


--
-- Name: trg_publish_payment(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.trg_publish_payment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare v_branch uuid; v_name text;
begin
  select t.branch_id into v_branch from gold.transactions t where t.id = new.transaction_id;
  perform gold.publish(new.tenant_id, 'payments', array[v_branch, new.paid_by_branch_id]);
  if tg_op = 'INSERT' and new.method = 'mobile_money' and new.status = 'pending' and new.paid_by_branch_id is not null then
    select name into v_name from gold.branches where id = v_branch;
    perform gold.notify(new.tenant_id, 'payment_to_send', format('Mobile money to send for a purchase at %s', v_name), null, '/payments', array[new.paid_by_branch_id], 'payments:confirm');
  end if;
  return null;
end $$;


--
-- Name: trg_publish_price(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.trg_publish_price() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare v_name text;
begin
  perform gold.publish(new.tenant_id, 'prices', array[new.branch_id]);
  select name into v_name from gold.branches where id = new.branch_id;
  if tg_op = 'INSERT' and new.status = 'provisional' then
    perform gold.notify(new.tenant_id, 'margin_to_approve', format('A margin for %s is waiting for approval', v_name), null, '/prices', null, 'prices:approve');
  elsif tg_op = 'INSERT' and new.status = 'approved' then
    perform gold.notify(new.tenant_id, 'price_updated', format('The price for %s was updated', v_name), null, '/prices', array[new.branch_id], 'transactions:create');
  end if;
  return null;
end $$;


--
-- Name: trg_publish_quiet(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.trg_publish_quiet() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  perform gold.publish(new.tenant_id, tg_argv[0], array[new.branch_id]);
  return null;
end $$;


--
-- Name: trg_publish_snapshot(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.trg_publish_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
  perform gold.publish(new.tenant_id, 'prices', null);
  return null;
end $$;


--
-- Name: trg_publish_transfers(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.trg_publish_transfers() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare v_name text; v_dest text;
begin
  perform gold.publish(new.tenant_id, 'transfers', array[new.origin_branch_id, new.destination_branch_id]);
  if tg_op = 'UPDATE' and new.status is distinct from old.status then
    select name into v_name from gold.branches where id = new.origin_branch_id;
    select name into v_dest from gold.branches where id = new.destination_branch_id;
    if new.status = 'released' then
      perform gold.notify(new.tenant_id, 'transfer_on_the_way', format('%s is on the way from %s', new.reference, v_name), null, '/transfers/' || new.id, array[new.destination_branch_id], 'transfers:receive');
    elsif new.status = 'received' then
      perform gold.notify(new.tenant_id, 'transfer_received', format('%s was received at %s', new.reference, v_dest), null, '/transfers/' || new.id, array[new.origin_branch_id], 'transfers:read');
    elsif new.status = 'received_with_discrepancy' then
      perform gold.notify(new.tenant_id, 'transfer_received', format('%s was received at %s with differences', new.reference, v_dest), null, '/transfers/' || new.id, array[new.origin_branch_id], 'transfers:read');
    end if;
  end if;
  return null;
end $$;


--
-- Name: ts(numeric); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.ts(p numeric) RETURNS text
    LANGUAGE sql IMMUTABLE
    AS $$ select trim_scale(p)::text $$;


--
-- Name: update_branch(uuid, jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.update_branch(p_id uuid, p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare b gold.branches; v_before jsonb; v_tz text;
begin
  perform gold.require_actor();
  select * into b from gold.branches where id = p_id for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Branch was not found.'); end if;
  v_before := gold.branch_admin_json(p_id);
  if p ? 'name' then
    if char_length(trim(coalesce(p->>'name', ''))) < 2 or char_length(trim(p->>'name')) > 80 then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the branch name.'); end if;
    update gold.branches set name = trim(p->>'name') where id = p_id;
  end if;
  if p ? 'timezone' then
    v_tz := trim(coalesce(p->>'timezone', ''));
    if not exists (select 1 from pg_timezone_names where name = v_tz) then perform gold.fail(422, 'VALIDATION_FAILED', 'That time zone is not known.'); end if;
    update gold.branches set timezone = v_tz where id = p_id;
  end if;
  if p ? 'isActive' and (p->>'isActive')::boolean <> b.is_active then
    if not (p->>'isActive')::boolean then
      if b.is_main then perform gold.fail(409, 'MAIN_BRANCH', 'The main branch cannot be switched off.'); end if;
      if exists (select 1 from gold.business_days d where d.branch_id = p_id and d.status = 'open') then
        perform gold.fail(409, 'DAY_OPEN', 'Close the branch''s day before switching it off.');
      end if;
    end if;
    update gold.branches set is_active = (p->>'isActive')::boolean where id = p_id;
  end if;
  perform gold.audit('branch.updated', 'branch', p_id::text, v_before, gold.branch_admin_json(p_id));
  return gold.branch_admin_json(p_id);
end $$;


--
-- Name: update_customer(uuid, jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.update_customer(p_id uuid, p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare c gold.customers; v_before jsonb; v_name text; v_phone text;
begin
  perform gold.require_actor();
  select * into c from gold.customers where id = p_id for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Customer was not found.'); end if;
  v_before := gold.customer_row_json(c);
  -- Someone else saved this customer after this person opened it: say so instead of silently overwriting their change.
  if jsonb_typeof(p->'expected') = 'object' then
    if (p ? 'name' and p->'expected' ? 'name' and trim(coalesce(p->'expected'->>'name', '')) is distinct from c.name)
       or (p ? 'phone' and p->'expected' ? 'phone' and nullif(regexp_replace(coalesce(p->'expected'->>'phone', ''), '\s', '', 'g'), '') is distinct from c.phone)
       or (p ? 'notes' and p->'expected' ? 'notes' and nullif(trim(coalesce(p->'expected'->>'notes', '')), '') is distinct from c.notes) then
      perform gold.fail(409, 'EDIT_CONFLICT', 'Someone else changed this customer while you were editing. Close this and open the customer again to see their change.');
    end if;
  end if;
  v_name := case when p ? 'name' then trim(coalesce(p->>'name', '')) else c.name end;
  v_phone := case when p ? 'phone' then nullif(regexp_replace(coalesce(p->>'phone', ''), '\s', '', 'g'), '') else c.phone end;
  if char_length(v_name) < 2 or char_length(v_name) > 120 then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the customer''s name.'); end if;
  if v_phone is null or char_length(v_phone) < 6 then perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the customer''s phone number.'); end if;
  if exists (select 1 from gold.customers where id <> p_id and lower(name) = lower(v_name) and phone = v_phone) then
    perform gold.fail(409, 'DUPLICATE_CUSTOMER', 'Another customer has this name and phone number. Merge them instead.');
  end if;
  update gold.customers set name = v_name, phone = v_phone,
         notes = case when p ? 'notes' then nullif(trim(coalesce(p->>'notes', '')), '') else notes end
  where id = p_id;
  -- Names on debts follow the customer. Receipts keep the name used on the day.
  update gold.debts set party_name = v_name where customer_id = p_id and party_type = 'customer';
  perform gold.audit('customer.updated', 'customer', p_id::text, v_before, gold.customer_row_json((select x from gold.customers x where x.id = p_id)));
  return gold.customer_detail_json(p_id);
end $$;


--
-- Name: update_role(text, jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.update_role(p_key text, p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant();
  r gold.roles; v_before jsonb; v_perms text[];
begin
  perform gold.require_actor();
  select * into r from gold.roles where key = p_key for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'Role was not found.'); end if;
  if r.is_system then perform gold.fail(409, 'SYSTEM_ROLE', 'The standard roles cannot be changed. Make a copy and change that.'); end if;
  v_before := gold.role_json(p_key);
  if p ? 'name' then
    if char_length(trim(p->>'name')) < 2 or char_length(trim(p->>'name')) > 40 then perform gold.fail(422, 'VALIDATION_FAILED', 'Give the role a name of 2 to 40 characters.'); end if;
    if exists (select 1 from gold.roles where lower(name) = lower(trim(p->>'name')) and id <> r.id) then perform gold.fail(409, 'ROLE_EXISTS', 'A role with that name already exists.'); end if;
    update gold.roles set name = trim(p->>'name') where id = r.id;
  end if;
  if p ? 'description' then update gold.roles set description = nullif(trim(coalesce(p->>'description', '')), '') where id = r.id; end if;
  if p ? 'permissions' then
    v_perms := gold.clean_permissions(p->'permissions');
    delete from gold.role_permissions where role_id = r.id;
    insert into gold.role_permissions (tenant_id, role_id, permission) select v_tenant, r.id, x from unnest(v_perms) x;
    update gold.refresh_tokens set revoked_at = now() where user_id in (select id from gold.users where role_id = r.id) and revoked_at is null;
    if gold.user_managers() = 0 then
      perform gold.fail(409, 'LAST_DIRECTOR', 'The company must keep at least one active person who can manage users.');
    end if;
  end if;
  perform gold.audit('role.updated', 'role', p_key, v_before, gold.role_json(p_key));
  return gold.role_json(p_key);
end $$;


--
-- Name: update_user(uuid, jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.update_user(p_id uuid, p jsonb) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
declare
  v_tenant uuid := gold.current_tenant();
  v_me uuid := gold.require_actor();
  u gold.users; v_before jsonb; v_role uuid; v_branches uuid[]; o jsonb; i int := 0; b uuid;
  v_access boolean := (p ? 'roleKey') or (p ? 'branchIds') or (p ? 'overrides') or (p ? 'isActive');
  v_signout boolean := false;
begin
  select * into u from gold.users where id = p_id for update;
  if not found then perform gold.fail(404, 'NOT_FOUND', 'User was not found.'); end if;
  if p_id = v_me and v_access then
    perform gold.fail(409, 'CANNOT_CHANGE_OWN_ACCESS', 'Ask another director to change your own role, branches or access.');
  end if;
  v_before := gold.user_admin_json(p_id);

  if p ? 'displayName' then
    if char_length(trim(p->>'displayName')) < 2 or char_length(trim(p->>'displayName')) > 80 then
      perform gold.fail(422, 'VALIDATION_FAILED', 'Enter the person''s name.');
    end if;
    update gold.users set display_name = trim(p->>'displayName') where id = p_id;
  end if;
  if p ? 'email' then update gold.users set email = nullif(trim(coalesce(p->>'email', '')), '') where id = p_id; end if;
  if p ? 'phone' then update gold.users set phone = nullif(trim(coalesce(p->>'phone', '')), '') where id = p_id; end if;

  if p ? 'roleKey' then
    select id into v_role from gold.roles where key = p->>'roleKey';
    if v_role is null then perform gold.fail(422, 'VALIDATION_FAILED', 'Choose a role.'); end if;
    if v_role <> u.role_id then update gold.users set role_id = v_role where id = p_id; v_signout := true; end if;
  end if;
  if p ? 'isActive' and (p->>'isActive')::boolean <> u.is_active then
    update gold.users set is_active = (p->>'isActive')::boolean, failed_login_count = 0, locked_until = null where id = p_id;
    v_signout := true;
  end if;
  if p ? 'branchIds' then
    v_branches := gold.valid_branch_ids(p->'branchIds');
    delete from gold.user_branches where user_id = p_id;
    foreach b in array v_branches loop
      i := i + 1;
      insert into gold.user_branches (tenant_id, user_id, branch_id, is_primary) values (v_tenant, p_id, b, i = 1);
    end loop;
    v_signout := true;
  end if;
  if p ? 'overrides' then
    delete from gold.user_permission_overrides where user_id = p_id;
    for o in select * from jsonb_array_elements(coalesce(p->'overrides', '[]'::jsonb)) loop
      insert into gold.user_permission_overrides (tenant_id, user_id, permission, effect) values (v_tenant, p_id, o->>'permission', o->>'effect')
      on conflict (user_id, permission) do update set effect = excluded.effect;
    end loop;
    v_signout := true;
  end if;

  if v_access then
    if not exists (select 1 from gold.effective_permissions(p_id) e where e = 'branches:all')
       and not exists (select 1 from gold.user_branches where user_id = p_id) then
      perform gold.fail(422, 'BRANCH_REQUIRED', 'Choose at least one branch for this person.');
    end if;
    -- The company must always keep someone who can manage users (checked after the change, so the whole change is undone if not).
    if gold.other_holders('users:manage', p_id) = 0
       and not (exists (select 1 from gold.users x where x.id = p_id and x.is_active)
                and exists (select 1 from gold.effective_permissions(p_id) e where e = 'users:manage')) then
      perform gold.fail(409, 'LAST_DIRECTOR', 'The company must keep at least one active person who can manage users.');
    end if;
  end if;
  if v_signout then
    update gold.refresh_tokens set revoked_at = now() where user_id = p_id and revoked_at is null;
  end if;
  perform gold.audit('user.updated', 'user', p_id::text, v_before, gold.user_admin_json(p_id));
  return gold.user_admin_json(p_id);
end $$;


--
-- Name: user_admin_json(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.user_admin_json(p_id uuid) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select jsonb_build_object(
    'id', u.id, 'username', u.username::text, 'displayName', u.display_name, 'email', u.email::text, 'phone', u.phone,
    'role', jsonb_build_object('key', r.key, 'name', r.name),
    'branchIds', coalesce((select jsonb_agg(ub.branch_id order by ub.is_primary desc, ub.branch_id) from gold.user_branches ub where ub.user_id = u.id), '[]'::jsonb),
    'isActive', u.is_active, 'mustChangePassword', u.must_change_password,
    'lastLoginAt', case when u.last_login_at is null then null else gold.iso(u.last_login_at) end,
    'createdAt', gold.iso(u.created_at),
    'overrides', coalesce((select jsonb_agg(jsonb_build_object('permission', o.permission, 'effect', o.effect) order by o.permission)
                           from gold.user_permission_overrides o where o.user_id = u.id), '[]'::jsonb),
    'permissions', coalesce((select jsonb_agg(e.perm) from gold.effective_permissions(u.id) as e(perm)), '[]'::jsonb))
  from gold.users u join gold.roles r on r.id = u.role_id and r.tenant_id = u.tenant_id
  where u.id = p_id
$$;


--
-- Name: user_branch_ids(uuid); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.user_branch_ids(p_user uuid) RETURNS SETOF uuid
    LANGUAGE sql STABLE
    AS $$
  select b.id
  from gold.branches b
  where b.is_active
    and (
      exists (select 1 from gold.effective_permissions(p_user) p where p = 'branches:all')
      or exists (select 1 from gold.user_branches ub where ub.user_id = p_user and ub.branch_id = b.id)
    )
  order by b.is_main desc, b.name
$$;


--
-- Name: user_managers(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.user_managers() RETURNS integer
    LANGUAGE sql STABLE
    AS $$
  select count(*)::int from gold.users u where u.is_active and exists (select 1 from gold.effective_permissions(u.id) e where e = 'users:manage')
$$;


--
-- Name: users_admin_json(); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.users_admin_json() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select coalesce(jsonb_agg(gold.user_admin_json(id) order by is_active desc, lower(display_name)), '[]'::jsonb) from gold.users
$$;


--
-- Name: valid_branch_ids(jsonb); Type: FUNCTION; Schema: gold; Owner: -
--

CREATE FUNCTION gold.valid_branch_ids(p jsonb) RETURNS uuid[]
    LANGUAGE plpgsql STABLE
    AS $$
declare ids uuid[]; n int;
begin
  select coalesce(array_agg(distinct x::uuid), '{}') into ids from jsonb_array_elements_text(coalesce(p, '[]'::jsonb)) x;
  select count(*) into n from gold.branches where id = any(ids) and is_active;
  if n <> cardinality(ids) then perform gold.fail(422, 'VALIDATION_FAILED', 'One of the chosen branches does not exist or is switched off.'); end if;
  return ids;
end $$;


--
-- Name: audit_events; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.audit_events (
    id bigint NOT NULL,
    tenant_id uuid NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    actor_user_id uuid,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text NOT NULL,
    branch_id uuid,
    before jsonb,
    after jsonb,
    trace_id text,
    ip inet
);

ALTER TABLE ONLY gold.audit_events FORCE ROW LEVEL SECURITY;


--
-- Name: branch_prices; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.branch_prices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    snapshot_id uuid NOT NULL,
    margin numeric(18,2) NOT NULL,
    status text NOT NULL,
    set_by uuid NOT NULL,
    approved_by uuid,
    approved_at timestamp with time zone,
    effective_from timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT branch_prices_check CHECK (((status = 'approved'::text) = ((approved_by IS NOT NULL) AND (approved_at IS NOT NULL)))),
    CONSTRAINT branch_prices_status_check CHECK ((status = ANY (ARRAY['provisional'::text, 'approved'::text])))
);

ALTER TABLE ONLY gold.branch_prices FORCE ROW LEVEL SECURITY;


--
-- Name: business_days; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.business_days (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    business_date date NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    previous_day_id uuid,
    opened_at timestamp with time zone NOT NULL,
    opened_by uuid NOT NULL,
    opened_offline boolean DEFAULT false NOT NULL,
    closed_at timestamp with time zone,
    closed_by uuid,
    closing_confirmed boolean DEFAULT false NOT NULL,
    closing_confirmation_version text,
    closing_confirmation_text text,
    signoff_status text DEFAULT 'not_required'::text NOT NULL,
    signoff_by uuid,
    signoff_at timestamp with time zone,
    signoff_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    opening_source text DEFAULT 'counted'::text NOT NULL,
    closing_command_id uuid,
    continuation_reason text,
    session_no smallint DEFAULT 1 NOT NULL,
    CONSTRAINT business_days_opening_source_check CHECK ((opening_source = ANY (ARRAY['counted'::text, 'carried'::text]))),
    CONSTRAINT business_days_signoff_status_check CHECK ((signoff_status = ANY (ARRAY['not_required'::text, 'pending'::text, 'approved'::text, 'rejected'::text]))),
    CONSTRAINT business_days_status_check CHECK ((status = ANY (ARRAY['open'::text, 'closed'::text]))),
    CONSTRAINT closed_requires_confirmation CHECK (((status = 'open'::text) OR ((closed_at IS NOT NULL) AND (closed_by IS NOT NULL) AND closing_confirmed AND (closing_confirmation_version IS NOT NULL) AND gold.has_text(closing_confirmation_text, 1)))),
    CONSTRAINT signoff_decision_complete CHECK (((signoff_status = ANY (ARRAY['not_required'::text, 'pending'::text])) OR ((signoff_by IS NOT NULL) AND (signoff_at IS NOT NULL))))
);

ALTER TABLE ONLY gold.business_days FORCE ROW LEVEL SECURITY;


--
-- Name: collateral_holdings; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.collateral_holdings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    customer_id uuid NOT NULL,
    debt_id uuid NOT NULL,
    top_weight numeric(14,4) NOT NULL,
    description text,
    status text DEFAULT 'held'::text NOT NULL,
    received_by uuid NOT NULL,
    received_at timestamp with time zone NOT NULL,
    converted_transaction_id uuid,
    closed_by uuid,
    closed_at timestamp with time zone,
    close_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT collateral_holdings_check CHECK (((status = 'held'::text) OR ((closed_by IS NOT NULL) AND (closed_at IS NOT NULL)))),
    CONSTRAINT collateral_holdings_check1 CHECK (((status <> 'converted'::text) OR (converted_transaction_id IS NOT NULL))),
    CONSTRAINT collateral_holdings_status_check CHECK ((status = ANY (ARRAY['held'::text, 'converted'::text, 'returned'::text]))),
    CONSTRAINT collateral_holdings_top_weight_check CHECK ((top_weight > (0)::numeric))
);

ALTER TABLE ONLY gold.collateral_holdings FORCE ROW LEVEL SECURITY;


--
-- Name: debt_repayments; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.debt_repayments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    debt_id uuid NOT NULL,
    amount numeric(18,2) NOT NULL,
    received_at timestamp with time zone NOT NULL,
    received_by uuid NOT NULL,
    note text,
    method text DEFAULT 'cash'::text NOT NULL,
    paid_by_branch_id uuid,
    external_ref text,
    source_transaction_id uuid,
    CONSTRAINT debt_repayments_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT debt_repayments_method_check CHECK ((method = ANY (ARRAY['cash'::text, 'mobile_money'::text, 'bank'::text, 'gold'::text, 'other'::text]))),
    CONSTRAINT gold_repayment_names_transaction CHECK (((method <> 'gold'::text) OR (source_transaction_id IS NOT NULL))),
    CONSTRAINT momo_names_the_payer CHECK (((method <> 'mobile_money'::text) OR (paid_by_branch_id IS NOT NULL)))
);

ALTER TABLE ONLY gold.debt_repayments FORCE ROW LEVEL SECURITY;


--
-- Name: debts; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.debts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    customer_id uuid,
    party_name text NOT NULL,
    party_type text NOT NULL,
    principal numeric(18,2) NOT NULL,
    reason text NOT NULL,
    issued_at timestamp with time zone NOT NULL,
    issued_by uuid NOT NULL,
    due_date date,
    status text DEFAULT 'open'::text NOT NULL,
    closed_at timestamp with time zone,
    closed_by uuid,
    close_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    direction text DEFAULT 'receivable'::text NOT NULL,
    source_transaction_id uuid,
    imported_batch uuid,
    CONSTRAINT debts_check CHECK (((status = 'open'::text) OR ((closed_at IS NOT NULL) AND (closed_by IS NOT NULL)))),
    CONSTRAINT debts_check1 CHECK (((status <> 'written_off'::text) OR gold.has_text(close_reason, 5))),
    CONSTRAINT debts_direction_check CHECK ((direction = ANY (ARRAY['receivable'::text, 'payable'::text]))),
    CONSTRAINT debts_party_type_check CHECK ((party_type = ANY (ARRAY['customer'::text, 'staff'::text, 'other'::text]))),
    CONSTRAINT debts_principal_check CHECK ((principal > (0)::numeric)),
    CONSTRAINT debts_status_check CHECK ((status = ANY (ARRAY['open'::text, 'settled'::text, 'written_off'::text])))
);

ALTER TABLE ONLY gold.debts FORCE ROW LEVEL SECURITY;


--
-- Name: discrepancy_actions; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.discrepancy_actions (
    id bigint NOT NULL,
    tenant_id uuid NOT NULL,
    discrepancy_id uuid NOT NULL,
    action_type text NOT NULL,
    from_status text,
    to_status text,
    note text,
    ledger_entry_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    actor_user_id uuid,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT discrepancy_actions_action_type_check CHECK ((action_type = ANY (ARRAY['opened'::text, 'note'::text, 'assigned'::text, 'status_changed'::text, 'adjustment_posted'::text, 'evidence_added'::text, 'resolved'::text, 'reopened'::text])))
);

ALTER TABLE ONLY gold.discrepancy_actions FORCE ROW LEVEL SECURITY;


--
-- Name: drawer_movements; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.drawer_movements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    business_day_id uuid,
    kind text NOT NULL,
    note text NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    people smallint,
    transaction_id uuid,
    CONSTRAINT drawer_movements_kind_check CHECK ((kind = ANY (ARRAY['topup'::text, 'withdrawal'::text, 'allowance'::text, 'exchange'::text]))),
    CONSTRAINT drawer_movements_note_check CHECK (gold.has_text(note, 1)),
    CONSTRAINT drawer_movements_people_check CHECK (((people IS NULL) OR ((people >= 1) AND (people <= 200))))
);

ALTER TABLE ONLY gold.drawer_movements FORCE ROW LEVEL SECURITY;


--
-- Name: price_feed_events; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.price_feed_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    kind text NOT NULL,
    state text DEFAULT 'done'::text NOT NULL,
    message text NOT NULL,
    base_price numeric(18,2),
    published_at timestamp with time zone,
    usd_per_ounce numeric(18,4),
    rate numeric(18,6),
    discount_pct numeric(7,4),
    computed numeric(18,2),
    excerpt text,
    decided_by uuid,
    decided_at timestamp with time zone,
    CONSTRAINT price_feed_events_kind_check CHECK ((kind = ANY (ARRAY['applied'::text, 'held'::text, 'failed'::text, 'missed'::text]))),
    CONSTRAINT price_feed_events_state_check CHECK ((state = ANY (ARRAY['done'::text, 'pending'::text, 'accepted'::text, 'dismissed'::text])))
);

ALTER TABLE ONLY gold.price_feed_events FORCE ROW LEVEL SECURITY;


--
-- Name: transaction_payments; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.transaction_payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    method text NOT NULL,
    amount numeric(18,2) NOT NULL,
    paid_by_branch_id uuid,
    external_ref text,
    debt_id uuid,
    status text DEFAULT 'confirmed'::text NOT NULL,
    confirmed_by uuid,
    confirmed_at timestamp with time zone,
    recorded_by uuid NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT debt_offset_names_debt CHECK (((method <> 'debt_offset'::text) OR (debt_id IS NOT NULL))),
    CONSTRAINT transaction_payments_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT transaction_payments_check CHECK (((method <> 'mobile_money'::text) OR (paid_by_branch_id IS NOT NULL))),
    CONSTRAINT transaction_payments_check1 CHECK (((method <> 'owed'::text) OR (debt_id IS NOT NULL))),
    CONSTRAINT transaction_payments_check2 CHECK (((method = 'mobile_money'::text) OR (status = 'confirmed'::text))),
    CONSTRAINT transaction_payments_method_check CHECK ((method = ANY (ARRAY['cash'::text, 'mobile_money'::text, 'owed'::text, 'debt_offset'::text]))),
    CONSTRAINT transaction_payments_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'confirmed'::text, 'failed'::text])))
);

ALTER TABLE ONLY gold.transaction_payments FORCE ROW LEVEL SECURITY;


--
-- Name: transactions; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    business_day_id uuid,
    reference text NOT NULL,
    customer_id uuid,
    customer_name text NOT NULL,
    customer_phone text,
    status text DEFAULT 'saved'::text NOT NULL,
    formula_version text NOT NULL,
    price_as_of timestamp with time zone NOT NULL,
    client_amount numeric(18,2) NOT NULL,
    calculated_amount numeric(18,2) NOT NULL,
    payout_policy text NOT NULL,
    payout_strategy text NOT NULL,
    payable numeric(18,2) NOT NULL,
    payout_difference numeric(18,2) NOT NULL,
    captured_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid NOT NULL,
    flags text[] DEFAULT '{}'::text[] NOT NULL,
    voided_at timestamp with time zone,
    voided_by uuid,
    void_reason text,
    represented_by_name text,
    represented_by_phone text,
    imported_batch uuid,
    import_key text,
    import_ref text,
    import_note text,
    stage text DEFAULT 'paid'::text NOT NULL,
    cash_due numeric(18,2) DEFAULT 0 NOT NULL,
    suggested_lines jsonb,
    paid_by uuid,
    paid_at timestamp with time zone,
    check_amount numeric(18,2),
    check_matched boolean,
    origin_town_id uuid,
    CONSTRAINT import_has_key CHECK (((imported_batch IS NULL) = (import_key IS NULL))),
    CONSTRAINT representative_phone_needs_name CHECK (((represented_by_phone IS NULL) OR (represented_by_name IS NOT NULL))),
    CONSTRAINT represented_by_has_name CHECK (((represented_by_name IS NULL) OR gold.has_text(represented_by_name, 1))),
    CONSTRAINT to_pay_has_amount CHECK (((stage <> 'to_pay'::text) OR (cash_due > (0)::numeric))),
    CONSTRAINT transactions_cash_due_check CHECK ((cash_due >= (0)::numeric)),
    CONSTRAINT transactions_check CHECK (((status <> 'void'::text) OR ((voided_at IS NOT NULL) AND (voided_by IS NOT NULL) AND gold.has_text(void_reason, 5)))),
    CONSTRAINT transactions_payable_check CHECK ((payable >= (0)::numeric)),
    CONSTRAINT transactions_payout_policy_check CHECK ((payout_policy = ANY (ARRAY['down'::text, 'up'::text, 'nearest'::text]))),
    CONSTRAINT transactions_payout_strategy_check CHECK ((payout_strategy = ANY (ARRAY['fewest-notes'::text, 'prefer-100s'::text]))),
    CONSTRAINT transactions_stage_check CHECK ((stage = ANY (ARRAY['paid'::text, 'to_pay'::text]))),
    CONSTRAINT transactions_status_check CHECK ((status = ANY (ARRAY['saved'::text, 'paid'::text, 'void'::text])))
);

ALTER TABLE ONLY gold.transactions FORCE ROW LEVEL SECURITY;


--
-- Name: activity_feed; Type: VIEW; Schema: gold; Owner: -
--

CREATE VIEW gold.activity_feed WITH (security_invoker='true') AS
 SELECT ('tx:'::text || t.id) AS uid,
    t.created_at AS at,
    t.created_by AS actor_id,
    t.branch_id,
    'purchase'::text AS category,
    'purchase.saved'::text AS action,
    'transaction'::text AS entity_type,
    (t.id)::text AS entity_id,
    format('Saved purchase %s for %s'::text, t.reference, t.customer_name) AS summary,
    t.payable AS amount,
    jsonb_build_object('reference', t.reference, 'customer', t.customer_name, 'status', t.status, 'capturedAt', t.captured_at) AS detail
   FROM gold.transactions t
UNION ALL
 SELECT ('txv:'::text || t.id) AS uid,
    t.voided_at AS at,
    t.voided_by AS actor_id,
    t.branch_id,
    'purchase'::text AS category,
    'purchase.voided'::text AS action,
    'transaction'::text AS entity_type,
    (t.id)::text AS entity_id,
    format('Voided purchase %s'::text, t.reference) AS summary,
    t.payable AS amount,
    jsonb_build_object('reference', t.reference, 'reason', t.void_reason) AS detail
   FROM gold.transactions t
  WHERE (t.voided_at IS NOT NULL)
UNION ALL
 SELECT ('dayo:'::text || d.id) AS uid,
    d.opened_at AS at,
    d.opened_by AS actor_id,
    d.branch_id,
    'day'::text AS category,
    'day.opened'::text AS action,
    'day'::text AS entity_type,
    (d.id)::text AS entity_id,
    format('Opened the day for %s'::text, d.business_date) AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('businessDate', d.business_date, 'source', d.opening_source) AS detail
   FROM gold.business_days d
UNION ALL
 SELECT ('dayc:'::text || d.id) AS uid,
    d.closed_at AS at,
    d.closed_by AS actor_id,
    d.branch_id,
    'day'::text AS category,
    'day.closed'::text AS action,
    'day'::text AS entity_type,
    (d.id)::text AS entity_id,
    format('Closed the day for %s'::text, d.business_date) AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('businessDate', d.business_date, 'signoff', d.signoff_status) AS detail
   FROM gold.business_days d
  WHERE (d.closed_at IS NOT NULL)
UNION ALL
 SELECT ('days:'::text || d.id) AS uid,
    d.signoff_at AS at,
    d.signoff_by AS actor_id,
    d.branch_id,
    'day'::text AS category,
        CASE
            WHEN (d.signoff_status = 'rejected'::text) THEN 'day.signoff_rejected'::text
            ELSE 'day.signed_off'::text
        END AS action,
    'day'::text AS entity_type,
    (d.id)::text AS entity_id,
    format('%s the closing of %s'::text,
        CASE
            WHEN (d.signoff_status = 'rejected'::text) THEN 'Rejected'::text
            ELSE 'Signed off'::text
        END, d.business_date) AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('businessDate', d.business_date, 'note', d.signoff_note) AS detail
   FROM gold.business_days d
  WHERE (d.signoff_at IS NOT NULL)
UNION ALL
 SELECT ('mv:'::text || m.id) AS uid,
    m.created_at AS at,
    m.created_by AS actor_id,
    m.branch_id,
    'cash'::text AS category,
    ('cash.'::text || m.kind) AS action,
    'drawer_movement'::text AS entity_type,
    (m.id)::text AS entity_id,
    ((
        CASE m.kind
            WHEN 'topup'::text THEN 'Added cash to the drawer'::text
            WHEN 'exchange'::text THEN 'Changed notes'::text
            WHEN 'allowance'::text THEN 'Paid the office allowance'::text
            ELSE 'Took cash out of the drawer'::text
        END || ': '::text) || m.note) AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('note', m.note, 'occurredAt', m.occurred_at) AS detail
   FROM gold.drawer_movements m
UNION ALL
 SELECT ('trc:'::text || x.id) AS uid,
    x.created_at AS at,
    x.created_by AS actor_id,
    x.origin_branch_id AS branch_id,
    'transfer'::text AS category,
    'transfer.drafted'::text AS action,
    'transfer'::text AS entity_type,
    (x.id)::text AS entity_id,
    format('Drafted transfer %s'::text, x.reference) AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('reference', x.reference, 'to', x.destination_branch_id) AS detail
   FROM gold.transfers x
UNION ALL
 SELECT ('trr:'::text || x.id) AS uid,
    x.released_at AS at,
    x.released_by AS actor_id,
    x.origin_branch_id AS branch_id,
    'transfer'::text AS category,
    'transfer.released'::text AS action,
    'transfer'::text AS entity_type,
    (x.id)::text AS entity_id,
    format('Released transfer %s'::text, x.reference) AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('reference', x.reference, 'to', x.destination_branch_id) AS detail
   FROM gold.transfers x
  WHERE (x.released_at IS NOT NULL)
UNION ALL
 SELECT ('trv:'::text || x.id) AS uid,
    x.received_at AS at,
    x.received_by AS actor_id,
    x.destination_branch_id AS branch_id,
    'transfer'::text AS category,
        CASE
            WHEN (x.status = 'received_with_discrepancy'::text) THEN 'transfer.received_with_difference'::text
            ELSE 'transfer.received'::text
        END AS action,
    'transfer'::text AS entity_type,
    (x.id)::text AS entity_id,
    format('Received transfer %s%s'::text, x.reference,
        CASE
            WHEN (x.status = 'received_with_discrepancy'::text) THEN ' with a difference'::text
            ELSE ''::text
        END) AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('reference', x.reference, 'from', x.origin_branch_id) AS detail
   FROM gold.transfers x
  WHERE (x.received_at IS NOT NULL)
UNION ALL
 SELECT ('trx:'::text || x.id) AS uid,
    x.cancelled_at AS at,
    x.cancelled_by AS actor_id,
    x.origin_branch_id AS branch_id,
    'transfer'::text AS category,
    'transfer.cancelled'::text AS action,
    'transfer'::text AS entity_type,
    (x.id)::text AS entity_id,
    format('Cancelled transfer %s'::text, x.reference) AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('reference', x.reference) AS detail
   FROM gold.transfers x
  WHERE (x.cancelled_at IS NOT NULL)
UNION ALL
 SELECT ('dca:'::text || a.id) AS uid,
    a.occurred_at AS at,
    a.actor_user_id AS actor_id,
    d.branch_id,
    'case'::text AS category,
    ('case.'::text || a.action_type) AS action,
    'discrepancy'::text AS entity_type,
    (d.id)::text AS entity_id,
        CASE a.action_type
            WHEN 'opened'::text THEN 'Opened a difference case'::text
            WHEN 'note'::text THEN 'Added a note to a case'::text
            WHEN 'assigned'::text THEN 'Took over a case'::text
            WHEN 'resolved'::text THEN 'Resolved a case'::text
            WHEN 'reopened'::text THEN 'Reopened a case'::text
            WHEN 'status_changed'::text THEN 'Changed the status of a case'::text
            WHEN 'adjustment_posted'::text THEN 'Posted an adjustment for a case'::text
            ELSE 'Added evidence to a case'::text
        END AS summary,
    d.difference AS amount,
    jsonb_build_object('note', a.note, 'from', a.from_status, 'to', a.to_status, 'kind', d.kind, 'asset', d.asset) AS detail
   FROM (gold.discrepancy_actions a
     JOIN gold.discrepancies d ON ((d.id = a.discrepancy_id)))
UNION ALL
 SELECT ('dbi:'::text || b.id) AS uid,
    b.issued_at AS at,
    b.issued_by AS actor_id,
    b.branch_id,
    'debt'::text AS category,
        CASE
            WHEN (b.direction = 'payable'::text) THEN 'debt.owed_recorded'::text
            ELSE 'debt.issued'::text
        END AS action,
    'debt'::text AS entity_type,
    (b.id)::text AS entity_id,
    ((
        CASE
            WHEN (b.direction = 'payable'::text) THEN 'Recorded an amount we owe'::text
            ELSE 'Gave a loan'::text
        END || ': '::text) || b.reason) AS summary,
    b.principal AS amount,
    jsonb_build_object('reason', b.reason, 'direction', b.direction, 'party', b.party_type) AS detail
   FROM gold.debts b
UNION ALL
 SELECT ('dbr:'::text || r.id) AS uid,
    r.received_at AS at,
    r.received_by AS actor_id,
    b.branch_id,
    'debt'::text AS category,
    'debt.repaid'::text AS action,
    'debt'::text AS entity_type,
    (b.id)::text AS entity_id,
    'Recorded a repayment'::text AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('note', r.note, 'reason', b.reason) AS detail
   FROM (gold.debt_repayments r
     JOIN gold.debts b ON ((b.id = r.debt_id)))
UNION ALL
 SELECT ('dbc:'::text || b.id) AS uid,
    b.closed_at AS at,
    b.closed_by AS actor_id,
    b.branch_id,
    'debt'::text AS category,
        CASE
            WHEN (b.status = 'written_off'::text) THEN 'debt.written_off'::text
            ELSE 'debt.settled'::text
        END AS action,
    'debt'::text AS entity_type,
    (b.id)::text AS entity_id,
        CASE
            WHEN (b.status = 'written_off'::text) THEN 'Wrote off a debt'::text
            ELSE 'Settled a debt'::text
        END AS summary,
    b.principal AS amount,
    jsonb_build_object('reason', b.close_reason) AS detail
   FROM gold.debts b
  WHERE (b.closed_at IS NOT NULL)
UNION ALL
 SELECT ('colr:'::text || c.id) AS uid,
    c.received_at AS at,
    c.received_by AS actor_id,
    c.branch_id,
    'debt'::text AS category,
    'gold.held'::text AS action,
    'collateral'::text AS entity_type,
    (c.id)::text AS entity_id,
    'Took gold as security for a loan'::text AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('debtId', c.debt_id) AS detail
   FROM gold.collateral_holdings c
UNION ALL
 SELECT ('colc:'::text || c.id) AS uid,
    c.closed_at AS at,
    c.closed_by AS actor_id,
    c.branch_id,
    'debt'::text AS category,
    ('gold.'::text || c.status) AS action,
    'collateral'::text AS entity_type,
    (c.id)::text AS entity_id,
        CASE c.status
            WHEN 'converted'::text THEN 'Bought the gold held as security'::text
            ELSE 'Returned the gold held as security'::text
        END AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('note', c.close_note) AS detail
   FROM gold.collateral_holdings c
  WHERE (c.closed_at IS NOT NULL)
UNION ALL
 SELECT ('pay:'::text || p.id) AS uid,
    p.confirmed_at AS at,
    p.confirmed_by AS actor_id,
    t.branch_id,
    'payment'::text AS category,
    ('payment.'::text || p.status) AS action,
    'payment'::text AS entity_type,
    (p.id)::text AS entity_id,
    (
        CASE p.status
            WHEN 'failed'::text THEN 'Marked a mobile payment as failed'::text
            ELSE 'Confirmed a mobile payment'::text
        END || format(' for %s'::text, t.reference)) AS summary,
    p.amount,
    jsonb_build_object('note', p.note, 'reference', t.reference) AS detail
   FROM (gold.transaction_payments p
     JOIN gold.transactions t ON ((t.id = p.transaction_id)))
  WHERE ((p.method = 'mobile_money'::text) AND (p.confirmed_at IS NOT NULL))
UNION ALL
 SELECT ('bps:'::text || b.id) AS uid,
    b.created_at AS at,
    b.set_by AS actor_id,
    b.branch_id,
    'price'::text AS category,
    'price.set'::text AS action,
    'branch_price'::text AS entity_type,
    (b.id)::text AS entity_id,
    'Set a branch margin'::text AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('status', b.status) AS detail
   FROM gold.branch_prices b
UNION ALL
 SELECT ('bpa:'::text || b.id) AS uid,
    b.approved_at AS at,
    b.approved_by AS actor_id,
    b.branch_id,
    'price'::text AS category,
    'price.approved'::text AS action,
    'branch_price'::text AS entity_type,
    (b.id)::text AS entity_id,
    'Approved a branch margin'::text AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('status', b.status) AS detail
   FROM gold.branch_prices b
  WHERE (b.approved_at IS NOT NULL)
UNION ALL
 SELECT ('pfe:'::text || e.id) AS uid,
    e.at,
    e.decided_by AS actor_id,
    NULL::uuid AS branch_id,
    'price'::text AS category,
    ('price.feed_'::text || e.kind) AS action,
    'price_feed'::text AS entity_type,
    (e.id)::text AS entity_id,
    e.message AS summary,
    e.base_price AS amount,
    jsonb_build_object('state', e.state, 'publishedAt', e.published_at) AS detail
   FROM gold.price_feed_events e
UNION ALL
 SELECT ('aud:'::text || a.id) AS uid,
    a.occurred_at AS at,
    a.actor_user_id AS actor_id,
    a.branch_id,
        CASE
            WHEN (a.entity_type = ANY (ARRAY['user'::text, 'role'::text])) THEN 'people'::text
            WHEN (a.entity_type = 'customer'::text) THEN 'customer'::text
            ELSE 'setup'::text
        END AS category,
    a.action,
    a.entity_type,
    a.entity_id,
        CASE a.action
            WHEN 'user.created'::text THEN 'Added a user'::text
            WHEN 'user.updated'::text THEN 'Changed a user'::text
            WHEN 'user.password_reset'::text THEN 'Reset a user''s password'::text
            WHEN 'user.password_changed'::text THEN 'Changed their own password'::text
            WHEN 'customer.created'::text THEN 'Added a customer'::text
            WHEN 'customer.updated'::text THEN 'Edited a customer'::text
            WHEN 'customer.merged'::text THEN 'Merged duplicate customers'::text
            WHEN 'branch.created'::text THEN 'Added a branch'::text
            WHEN 'branch.updated'::text THEN 'Changed a branch'::text
            ELSE replace(a.action, '.'::text, ' '::text)
        END AS summary,
    NULL::numeric AS amount,
    jsonb_build_object('before', a.before, 'after', a.after) AS detail
   FROM gold.audit_events a;


--
-- Name: attachments; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    storage_key text NOT NULL,
    file_name text NOT NULL,
    content_type text NOT NULL,
    size_bytes bigint NOT NULL,
    sha256 bytea NOT NULL,
    uploaded_by uuid,
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT attachments_size_bytes_check CHECK ((size_bytes >= 0))
);

ALTER TABLE ONLY gold.attachments FORCE ROW LEVEL SECURITY;


--
-- Name: audit_events_id_seq; Type: SEQUENCE; Schema: gold; Owner: -
--

ALTER TABLE gold.audit_events ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME gold.audit_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: branches; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.branches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    is_main boolean DEFAULT false NOT NULL,
    timezone text DEFAULT 'Africa/Accra'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY gold.branches FORCE ROW LEVEL SECURITY;


--
-- Name: day_balances; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.day_balances (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    business_day_id uuid NOT NULL,
    kind text NOT NULL,
    cash_lines jsonb DEFAULT '{}'::jsonb NOT NULL,
    cash_value numeric(18,2) NOT NULL,
    goods_top numeric(14,4) NOT NULL,
    goods_down numeric(14,4) NOT NULL,
    goods_value numeric(18,2) NOT NULL,
    debt_value numeric(18,2) NOT NULL,
    ledger_seq bigint,
    captured_at timestamp with time zone DEFAULT now() NOT NULL,
    captured_by uuid,
    payable_value numeric(18,2) DEFAULT 0 NOT NULL,
    custody_top numeric(14,4) DEFAULT 0 NOT NULL,
    CONSTRAINT day_balances_kind_check CHECK ((kind = ANY (ARRAY['opening_expected'::text, 'opening_declared'::text, 'closing_expected'::text, 'closing_declared'::text])))
);

ALTER TABLE ONLY gold.day_balances FORCE ROW LEVEL SECURITY;


--
-- Name: day_reconciliations; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.day_reconciliations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    business_day_id uuid NOT NULL,
    phase text NOT NULL,
    asset text NOT NULL,
    expected numeric(18,4) NOT NULL,
    actual numeric(18,4) NOT NULL,
    difference numeric(18,4) GENERATED ALWAYS AS ((actual - expected)) STORED,
    outcome text GENERATED ALWAYS AS (
CASE
    WHEN (actual = expected) THEN 'balanced'::text
    WHEN (actual > expected) THEN 'surplus'::text
    ELSE 'shortage'::text
END) STORED,
    detail jsonb,
    explanation text,
    explained_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT day_reconciliations_asset_check CHECK ((asset = ANY (ARRAY['cash'::text, 'goods_top'::text, 'goods_down'::text, 'goods_value'::text, 'debt'::text, 'payable'::text, 'custody_top'::text]))),
    CONSTRAINT day_reconciliations_phase_check CHECK ((phase = ANY (ARRAY['opening'::text, 'closing'::text]))),
    CONSTRAINT difference_needs_explanation CHECK (((actual = expected) OR ((explanation IS NOT NULL) AND gold.has_text(explanation, 5) AND (explained_by IS NOT NULL))))
);

ALTER TABLE ONLY gold.day_reconciliations FORCE ROW LEVEL SECURITY;


--
-- Name: device_keys; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.device_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    device_id text NOT NULL,
    public_key text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT device_keys_device_id_check CHECK (((char_length(device_id) >= 8) AND (char_length(device_id) <= 80))),
    CONSTRAINT device_keys_public_key_check CHECK (((char_length(public_key) >= 80) AND (char_length(public_key) <= 400)))
);

ALTER TABLE ONLY gold.device_keys FORCE ROW LEVEL SECURITY;


--
-- Name: discrepancy_actions_id_seq; Type: SEQUENCE; Schema: gold; Owner: -
--

ALTER TABLE gold.discrepancy_actions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME gold.discrepancy_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: document_counters; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.document_counters (
    tenant_id uuid NOT NULL,
    kind text NOT NULL,
    branch_id uuid NOT NULL,
    business_date date NOT NULL,
    last_value integer DEFAULT 0 NOT NULL
);

ALTER TABLE ONLY gold.document_counters FORCE ROW LEVEL SECURITY;


--
-- Name: formula_versions; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.formula_versions (
    tenant_id uuid NOT NULL,
    key text NOT NULL,
    params jsonb NOT NULL,
    effective_from date DEFAULT CURRENT_DATE NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY gold.formula_versions FORCE ROW LEVEL SECURITY;


--
-- Name: guide_categories; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.guide_categories (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT guide_categories_name_check CHECK (((char_length(TRIM(BOTH FROM name)) >= 2) AND (char_length(TRIM(BOTH FROM name)) <= 60)))
);

ALTER TABLE ONLY gold.guide_categories FORCE ROW LEVEL SECURITY;


--
-- Name: guide_reads; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.guide_reads (
    tenant_id uuid NOT NULL,
    article_id uuid NOT NULL,
    user_id uuid NOT NULL,
    version integer NOT NULL,
    read_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY gold.guide_reads FORCE ROW LEVEL SECURITY;


--
-- Name: guide_reminder_registry; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.guide_reminder_registry (
    tenant_id uuid NOT NULL
);


--
-- Name: guide_settings; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.guide_settings (
    tenant_id uuid NOT NULL,
    frequency text DEFAULT 'off'::text NOT NULL,
    remind_time text DEFAULT '08:00'::text NOT NULL,
    weekday integer DEFAULT 1 NOT NULL,
    audience text DEFAULT 'unread'::text NOT NULL,
    last_sent_on date,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT guide_settings_audience_check CHECK ((audience = ANY (ARRAY['unread'::text, 'everyone'::text]))),
    CONSTRAINT guide_settings_frequency_check CHECK ((frequency = ANY (ARRAY['off'::text, 'daily'::text, 'weekly'::text, 'monthly'::text]))),
    CONSTRAINT guide_settings_remind_time_check CHECK ((remind_time ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'::text)),
    CONSTRAINT guide_settings_weekday_check CHECK (((weekday >= 1) AND (weekday <= 7)))
);

ALTER TABLE ONLY gold.guide_settings FORCE ROW LEVEL SECURITY;


--
-- Name: idempotency_keys; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.idempotency_keys (
    tenant_id uuid NOT NULL,
    key text NOT NULL,
    user_id uuid NOT NULL,
    request_hash bytea NOT NULL,
    status_code integer,
    response jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY gold.idempotency_keys FORCE ROW LEVEL SECURITY;


--
-- Name: import_batches; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.import_batches (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    kind text NOT NULL,
    label text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    undone_at timestamp with time zone,
    undone_by uuid,
    CONSTRAINT import_batches_kind_check CHECK ((kind = ANY (ARRAY['history'::text, 'customers'::text, 'opening'::text])))
);

ALTER TABLE ONLY gold.import_batches FORCE ROW LEVEL SECURITY;


--
-- Name: ledger_entries; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.ledger_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    seq bigint NOT NULL,
    tenant_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    business_day_id uuid,
    occurred_at timestamp with time zone NOT NULL,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL,
    recorded_by uuid,
    asset text NOT NULL,
    denomination integer,
    delta_count integer,
    delta_top numeric(14,4),
    delta_down numeric(14,4),
    delta_value numeric(18,2) NOT NULL,
    source_type text NOT NULL,
    source_id uuid NOT NULL,
    memo text,
    reverses_entry_id uuid,
    CONSTRAINT ledger_entries_asset_check CHECK ((asset = ANY (ARRAY['cash'::text, 'goods'::text, 'debt'::text, 'payable'::text, 'custody'::text]))),
    CONSTRAINT ledger_entries_denomination_check CHECK ((denomination > 0)),
    CONSTRAINT ledger_entries_source_type_check CHECK ((source_type = ANY (ARRAY['go_live_balance'::text, 'transaction_purchase'::text, 'transaction_payout'::text, 'drawer_movement'::text, 'transfer_release'::text, 'transfer_receipt'::text, 'transfer_payment'::text, 'transfer_recall'::text, 'debt_issued'::text, 'debt_repayment'::text, 'payable_issued'::text, 'payable_settlement'::text, 'custody_in'::text, 'custody_out'::text, 'opening_adjustment'::text, 'closing_adjustment'::text, 'discrepancy_resolution'::text, 'reversal'::text]))),
    CONSTRAINT ledger_shape CHECK ((((asset = 'cash'::text) AND (denomination IS NOT NULL) AND (delta_count IS NOT NULL) AND (delta_count <> 0) AND (delta_top IS NULL) AND (delta_down IS NULL) AND (delta_value = ((denomination * delta_count))::numeric)) OR ((asset = 'goods'::text) AND (denomination IS NULL) AND (delta_count IS NULL) AND (delta_top IS NOT NULL) AND (delta_down IS NOT NULL)) OR ((asset = ANY (ARRAY['debt'::text, 'payable'::text])) AND (denomination IS NULL) AND (delta_count IS NULL) AND (delta_top IS NULL) AND (delta_down IS NULL)) OR ((asset = 'custody'::text) AND (denomination IS NULL) AND (delta_count IS NULL) AND (delta_top IS NOT NULL) AND (delta_down IS NULL) AND (delta_value = (0)::numeric)))),
    CONSTRAINT reversal_points_at_entry CHECK (((source_type = 'reversal'::text) = (reverses_entry_id IS NOT NULL)))
);

ALTER TABLE ONLY gold.ledger_entries FORCE ROW LEVEL SECURITY;


--
-- Name: ledger_entries_seq_seq; Type: SEQUENCE; Schema: gold; Owner: -
--

ALTER TABLE gold.ledger_entries ALTER COLUMN seq ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME gold.ledger_entries_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notifications; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    kind text NOT NULL,
    title text NOT NULL,
    body text,
    link text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    read_at timestamp with time zone
);

ALTER TABLE ONLY gold.notifications FORCE ROW LEVEL SECURITY;


--
-- Name: origin_towns; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.origin_towns (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    name_key text NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT origin_towns_name_check CHECK (((char_length(name) >= 2) AND (char_length(name) <= 80))),
    CONSTRAINT origin_towns_name_key_check CHECK ((name_key <> ''::text))
);

ALTER TABLE ONLY gold.origin_towns FORCE ROW LEVEL SECURITY;


--
-- Name: price_feed_registry; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.price_feed_registry (
    tenant_id uuid NOT NULL
);


--
-- Name: price_feed_settings; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.price_feed_settings (
    tenant_id uuid NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    windows jsonb DEFAULT '[{"end": "11:30", "start": "10:30", "everyMinutes": 5}, {"end": "16:00", "start": "15:00", "everyMinutes": 5}]'::jsonb NOT NULL,
    weekdays smallint[] DEFAULT '{1,2,3,4,5}'::smallint[] NOT NULL,
    timezone text DEFAULT 'Africa/Accra'::text NOT NULL,
    margin_policy text DEFAULT 'approve'::text NOT NULL,
    max_jump_pct numeric(5,2) DEFAULT 10 NOT NULL,
    updated_by uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_checked_at timestamp with time zone,
    last_result text,
    CONSTRAINT price_feed_settings_margin_policy_check CHECK ((margin_policy = ANY (ARRAY['approve'::text, 'carry'::text]))),
    CONSTRAINT price_feed_settings_max_jump_pct_check CHECK (((max_jump_pct >= (1)::numeric) AND (max_jump_pct <= (50)::numeric)))
);

ALTER TABLE ONLY gold.price_feed_settings FORCE ROW LEVEL SECURITY;


--
-- Name: price_snapshots; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.price_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    source text NOT NULL,
    base_price numeric(18,2) NOT NULL,
    published_at timestamp with time zone NOT NULL,
    fetched_at timestamp with time zone DEFAULT now() NOT NULL,
    raw jsonb,
    created_by uuid,
    CONSTRAINT price_snapshots_base_price_check CHECK ((base_price >= (0)::numeric)),
    CONSTRAINT price_snapshots_source_check CHECK ((source = ANY (ARRAY['goldbod'::text, 'manual'::text])))
);

ALTER TABLE ONLY gold.price_snapshots FORCE ROW LEVEL SECURITY;


--
-- Name: refresh_tokens; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.refresh_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    family_id uuid NOT NULL,
    token_hash bytea NOT NULL,
    issued_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    replaced_by uuid,
    user_agent text,
    ip inet
);

ALTER TABLE ONLY gold.refresh_tokens FORCE ROW LEVEL SECURITY;


--
-- Name: role_permissions; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.role_permissions (
    tenant_id uuid NOT NULL,
    role_id uuid NOT NULL,
    permission text NOT NULL,
    CONSTRAINT role_permissions_permission_check CHECK ((permission ~ '^[a-z][a-z0-9-]*:[a-z][a-z0-9-]*$'::text))
);

ALTER TABLE ONLY gold.role_permissions FORCE ROW LEVEL SECURITY;


--
-- Name: roles; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    description text
);

ALTER TABLE ONLY gold.roles FORCE ROW LEVEL SECURITY;


--
-- Name: schema_migrations; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.schema_migrations (
    version text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sync_commands; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.sync_commands (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    device_id text,
    type text NOT NULL,
    payload jsonb NOT NULL,
    branch_id uuid,
    captured_at timestamp with time zone,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    status text NOT NULL,
    code text,
    message text,
    flags text[] DEFAULT '{}'::text[] NOT NULL,
    resolved_by uuid,
    resolved_at timestamp with time zone,
    resolution text,
    CONSTRAINT sync_commands_status_check CHECK ((status = ANY (ARRAY['applied'::text, 'held'::text, 'rejected'::text, 'dismissed'::text])))
);

ALTER TABLE ONLY gold.sync_commands FORCE ROW LEVEL SECURITY;


--
-- Name: tenant_settings; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.tenant_settings (
    tenant_id uuid NOT NULL,
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY gold.tenant_settings FORCE ROW LEVEL SECURITY;


--
-- Name: tenants; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug public.citext NOT NULL,
    name text NOT NULL,
    currency character(3) DEFAULT 'GHS'::bpchar NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY gold.tenants FORCE ROW LEVEL SECURITY;


--
-- Name: transaction_items; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.transaction_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    transaction_id uuid NOT NULL,
    line_no smallint NOT NULL,
    label text,
    top numeric(14,4) NOT NULL,
    down numeric(14,4) NOT NULL,
    price numeric(18,2) NOT NULL,
    density numeric(10,2) NOT NULL,
    karat numeric(10,2) NOT NULL,
    purity numeric(10,4) NOT NULL,
    net_weight numeric(14,4) NOT NULL,
    pounds numeric(14,4) NOT NULL,
    amount numeric(18,2) NOT NULL,
    location_branch_id uuid NOT NULL,
    location_state text DEFAULT 'on_hand'::text NOT NULL,
    CONSTRAINT transaction_items_down_check CHECK ((down > (0)::numeric)),
    CONSTRAINT transaction_items_line_no_check CHECK ((line_no > 0)),
    CONSTRAINT transaction_items_location_state_check CHECK ((location_state = ANY (ARRAY['on_hand'::text, 'in_transit'::text, 'historical'::text]))),
    CONSTRAINT transaction_items_price_check CHECK ((price >= (0)::numeric)),
    CONSTRAINT transaction_items_top_check CHECK ((top > (0)::numeric))
);

ALTER TABLE ONLY gold.transaction_items FORCE ROW LEVEL SECURITY;


--
-- Name: transfer_events; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.transfer_events (
    id bigint NOT NULL,
    tenant_id uuid NOT NULL,
    transfer_id uuid NOT NULL,
    event_type text NOT NULL,
    actor_user_id uuid,
    occurred_at timestamp with time zone NOT NULL,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT transfer_events_event_type_check CHECK ((event_type = ANY (ARRAY['created'::text, 'goods_added'::text, 'goods_removed'::text, 'collector_set'::text, 'released'::text, 'payment_recorded'::text, 'received'::text, 'discrepancy_flagged'::text, 'note_added'::text, 'cancelled'::text, 'attachment_added'::text, 'recalled'::text])))
);

ALTER TABLE ONLY gold.transfer_events FORCE ROW LEVEL SECURITY;


--
-- Name: transfer_events_id_seq; Type: SEQUENCE; Schema: gold; Owner: -
--

ALTER TABLE gold.transfer_events ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME gold.transfer_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: transfer_goods_lines; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.transfer_goods_lines (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    transfer_id uuid NOT NULL,
    line_no smallint NOT NULL,
    transaction_item_id uuid,
    description text,
    released_top numeric(14,4) NOT NULL,
    released_down numeric(14,4) NOT NULL,
    released_value numeric(18,2) NOT NULL,
    received_top numeric(14,4),
    received_down numeric(14,4),
    received_value numeric(18,2),
    outcome text DEFAULT 'pending'::text NOT NULL,
    CONSTRAINT transfer_goods_lines_check CHECK (((transaction_item_id IS NOT NULL) OR gold.has_text(description, 1))),
    CONSTRAINT transfer_goods_lines_check1 CHECK (((outcome = 'pending'::text) OR ((received_top IS NOT NULL) AND (received_down IS NOT NULL) AND (received_value IS NOT NULL)) OR (outcome = 'missing'::text))),
    CONSTRAINT transfer_goods_lines_line_no_check CHECK ((line_no > 0)),
    CONSTRAINT transfer_goods_lines_outcome_check CHECK ((outcome = ANY (ARRAY['pending'::text, 'matched'::text, 'differs'::text, 'missing'::text]))),
    CONSTRAINT transfer_goods_lines_released_down_check CHECK ((released_down >= (0)::numeric)),
    CONSTRAINT transfer_goods_lines_released_top_check CHECK ((released_top >= (0)::numeric)),
    CONSTRAINT transfer_goods_lines_released_value_check CHECK ((released_value >= (0)::numeric))
);

ALTER TABLE ONLY gold.transfer_goods_lines FORCE ROW LEVEL SECURITY;


--
-- Name: transfer_payments; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.transfer_payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    transfer_id uuid NOT NULL,
    direction text NOT NULL,
    amount numeric(18,2) NOT NULL,
    method text NOT NULL,
    purpose text NOT NULL,
    external_ref text,
    paid_at timestamp with time zone NOT NULL,
    recorded_by uuid NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT transfer_payments_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT transfer_payments_direction_check CHECK ((direction = ANY (ARRAY['paid_to_collector'::text, 'received_from_collector'::text]))),
    CONSTRAINT transfer_payments_method_check CHECK ((method = ANY (ARRAY['cash'::text, 'mobile_money'::text, 'bank'::text, 'other'::text]))),
    CONSTRAINT transfer_payments_purpose_check CHECK (gold.has_text(purpose, 1))
);

ALTER TABLE ONLY gold.transfer_payments FORCE ROW LEVEL SECURITY;


--
-- Name: user_branches; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.user_branches (
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    branch_id uuid NOT NULL,
    is_primary boolean DEFAULT false NOT NULL
);

ALTER TABLE ONLY gold.user_branches FORCE ROW LEVEL SECURITY;


--
-- Name: user_permission_overrides; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.user_permission_overrides (
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    permission text NOT NULL,
    effect text NOT NULL,
    CONSTRAINT user_permission_overrides_effect_check CHECK ((effect = ANY (ARRAY['allow'::text, 'deny'::text]))),
    CONSTRAINT user_permission_overrides_permission_check CHECK ((permission ~ '^[a-z][a-z0-9-]*:[a-z][a-z0-9-]*$'::text))
);

ALTER TABLE ONLY gold.user_permission_overrides FORCE ROW LEVEL SECURITY;


--
-- Name: users; Type: TABLE; Schema: gold; Owner: -
--

CREATE TABLE gold.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    username public.citext NOT NULL,
    display_name text NOT NULL,
    email public.citext,
    phone text,
    password_hash text NOT NULL,
    role_id uuid NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    failed_login_count integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    must_change_password boolean DEFAULT false NOT NULL
);

ALTER TABLE ONLY gold.users FORCE ROW LEVEL SECURITY;


--
-- Name: v_branch_timeline; Type: VIEW; Schema: gold; Owner: -
--

CREATE VIEW gold.v_branch_timeline WITH (security_invoker='true') AS
 SELECT id,
    seq,
    tenant_id,
    branch_id,
    business_day_id,
    occurred_at,
    recorded_at,
    recorded_by,
    asset,
    denomination,
    delta_count,
    delta_top,
    delta_down,
    delta_value,
    source_type,
    source_id,
    memo,
    reverses_entry_id,
    sum(
        CASE
            WHEN (asset = 'cash'::text) THEN delta_value
            ELSE (0)::numeric
        END) OVER w AS running_cash,
    sum(
        CASE
            WHEN (asset = 'goods'::text) THEN delta_top
            ELSE (0)::numeric
        END) OVER w AS running_goods_top,
    sum(
        CASE
            WHEN (asset = 'goods'::text) THEN delta_down
            ELSE (0)::numeric
        END) OVER w AS running_goods_down,
    sum(
        CASE
            WHEN (asset = 'goods'::text) THEN delta_value
            ELSE (0)::numeric
        END) OVER w AS running_goods_value,
    sum(
        CASE
            WHEN (asset = 'debt'::text) THEN delta_value
            ELSE (0)::numeric
        END) OVER w AS running_debt,
    sum(
        CASE
            WHEN (asset = 'payable'::text) THEN delta_value
            ELSE (0)::numeric
        END) OVER w AS running_payable,
    sum(
        CASE
            WHEN (asset = 'custody'::text) THEN delta_top
            ELSE (0)::numeric
        END) OVER w AS running_custody_top
   FROM gold.ledger_entries l
  WINDOW w AS (PARTITION BY branch_id ORDER BY seq ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW);


--
-- Name: v_debts_outstanding; Type: VIEW; Schema: gold; Owner: -
--

CREATE VIEW gold.v_debts_outstanding WITH (security_invoker='true') AS
 SELECT d.id,
    d.tenant_id,
    d.branch_id,
    d.customer_id,
    d.party_name,
    d.party_type,
    d.principal,
    d.reason,
    d.issued_at,
    d.issued_by,
    d.due_date,
    d.status,
    d.closed_at,
    d.closed_by,
    d.close_reason,
    d.created_at,
    d.direction,
    d.source_transaction_id,
    (d.principal - COALESCE(r.paid, (0)::numeric)) AS outstanding
   FROM (gold.debts d
     LEFT JOIN LATERAL ( SELECT sum(x.amount) AS paid
           FROM gold.debt_repayments x
          WHERE (x.debt_id = d.id)) r ON (true));


--
-- Name: v_interbranch_position; Type: VIEW; Schema: gold; Owner: -
--

CREATE VIEW gold.v_interbranch_position WITH (security_invoker='true') AS
 SELECT tenant_id,
    sender_branch_id,
    receiver_branch_id,
    sum(cash) AS cash_sent,
    sum(momo) AS mobile_money_paid_on_behalf,
    sum(goods) AS goods_value_sent,
    sum(momo_failed) AS mobile_money_failed_covered_by_cash
   FROM ( SELECT transfers.tenant_id,
            transfers.origin_branch_id AS sender_branch_id,
            transfers.destination_branch_id AS receiver_branch_id,
            COALESCE(transfers.received_cash, (0)::numeric) AS cash,
            (0)::numeric AS momo,
            (0)::numeric AS goods,
            (0)::numeric AS momo_failed
           FROM gold.transfers
          WHERE ((transfers.kind = 'cash'::text) AND (transfers.status = ANY (ARRAY['received'::text, 'received_with_discrepancy'::text])))
        UNION ALL
         SELECT transfers.tenant_id,
            transfers.origin_branch_id,
            transfers.destination_branch_id,
            0,
            0,
            COALESCE(transfers.received_value, (0)::numeric) AS "coalesce",
            0
           FROM gold.transfers
          WHERE ((transfers.kind = 'goods'::text) AND (transfers.status = ANY (ARRAY['received'::text, 'received_with_discrepancy'::text])))
        UNION ALL
         SELECT p.tenant_id,
            p.paid_by_branch_id,
            t.branch_id,
            0,
            p.amount,
            0,
            0
           FROM (gold.transaction_payments p
             JOIN gold.transactions t ON ((t.id = p.transaction_id)))
          WHERE ((p.method = 'mobile_money'::text) AND (p.status = 'confirmed'::text) AND (p.paid_by_branch_id <> t.branch_id))
        UNION ALL
         SELECT r.tenant_id,
            r.paid_by_branch_id,
            d.branch_id,
            0,
            r.amount,
            0,
            0
           FROM (gold.debt_repayments r
             JOIN gold.debts d ON ((d.id = r.debt_id)))
          WHERE ((r.method = 'mobile_money'::text) AND (r.paid_by_branch_id <> d.branch_id))
        UNION ALL
         SELECT p.tenant_id,
            p.paid_by_branch_id,
            t.branch_id,
            0,
            0,
            0,
            p.amount
           FROM (gold.transaction_payments p
             JOIN gold.transactions t ON ((t.id = p.transaction_id)))
          WHERE ((p.method = 'mobile_money'::text) AND (p.status = 'failed'::text) AND (p.paid_by_branch_id <> t.branch_id))) x
  GROUP BY tenant_id, sender_branch_id, receiver_branch_id;


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.attachments (id, tenant_id, entity_type, entity_id, storage_key, file_name, content_type, size_bytes, sha256, uploaded_by, uploaded_at) FROM stdin;
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.audit_events (id, tenant_id, occurred_at, actor_user_id, action, entity_type, entity_id, branch_id, before, after, trace_id, ip) FROM stdin;
\.


--
-- Data for Name: branch_prices; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.branch_prices (id, tenant_id, branch_id, snapshot_id, margin, status, set_by, approved_by, approved_at, effective_from, created_at) FROM stdin;
\.


--
-- Data for Name: branches; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.branches (id, tenant_id, code, name, is_main, timezone, is_active, created_at) FROM stdin;
32e7c258-477e-418a-91a2-e455fd4ad46b	31e4ae7d-209c-4bca-8d64-b851570071d1	KSI	Kumasi	t	Africa/Accra	t	2026-11-07 17:49:07.666499+00
\.


--
-- Data for Name: business_days; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.business_days (id, tenant_id, branch_id, business_date, status, previous_day_id, opened_at, opened_by, opened_offline, closed_at, closed_by, closing_confirmed, closing_confirmation_version, closing_confirmation_text, signoff_status, signoff_by, signoff_at, signoff_note, created_at, opening_source, closing_command_id, continuation_reason, session_no) FROM stdin;
\.


--
-- Data for Name: collateral_holdings; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.collateral_holdings (id, tenant_id, branch_id, customer_id, debt_id, top_weight, description, status, received_by, received_at, converted_transaction_id, closed_by, closed_at, close_note, created_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.customers (id, tenant_id, name, phone, notes, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: day_balances; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.day_balances (id, tenant_id, business_day_id, kind, cash_lines, cash_value, goods_top, goods_down, goods_value, debt_value, ledger_seq, captured_at, captured_by, payable_value, custody_top) FROM stdin;
\.


--
-- Data for Name: day_reconciliations; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.day_reconciliations (id, tenant_id, business_day_id, phase, asset, expected, actual, detail, explanation, explained_by, created_at) FROM stdin;
\.


--
-- Data for Name: debt_repayments; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.debt_repayments (id, tenant_id, debt_id, amount, received_at, received_by, note, method, paid_by_branch_id, external_ref, source_transaction_id) FROM stdin;
\.


--
-- Data for Name: debts; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.debts (id, tenant_id, branch_id, customer_id, party_name, party_type, principal, reason, issued_at, issued_by, due_date, status, closed_at, closed_by, close_reason, created_at, direction, source_transaction_id, imported_batch) FROM stdin;
\.


--
-- Data for Name: device_keys; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.device_keys (id, tenant_id, user_id, device_id, public_key, created_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: discrepancies; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.discrepancies (id, tenant_id, branch_id, business_day_id, kind, asset, reconciliation_id, transfer_id, transfer_line_id, expected, actual, difference, reported_explanation, status, assigned_to, opened_at, opened_by, resolved_at, resolved_by, resolution_type, resolution_summary) FROM stdin;
\.


--
-- Data for Name: discrepancy_actions; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.discrepancy_actions (id, tenant_id, discrepancy_id, action_type, from_status, to_status, note, ledger_entry_ids, actor_user_id, occurred_at) FROM stdin;
\.


--
-- Data for Name: document_counters; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.document_counters (tenant_id, kind, branch_id, business_date, last_value) FROM stdin;
\.


--
-- Data for Name: drawer_movements; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.drawer_movements (id, tenant_id, branch_id, business_day_id, kind, note, occurred_at, created_by, created_at, people, transaction_id) FROM stdin;
\.


--
-- Data for Name: formula_versions; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.formula_versions (tenant_id, key, params, effective_from, created_at) FROM stdin;
31e4ae7d-209c-4bca-8d64-b851570071d1	ExcelV1	{"poundGrams": "7.75", "densityScale": "52.838", "densityOffset": "10.51", "correctionRate": "0.007", "priceReferenceKarat": "23"}	2026-11-07	2026-11-07 17:49:07.666499+00
\.


--
-- Data for Name: guide_articles; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.guide_articles (id, tenant_id, category_id, title, summary, kind, blocks, status, version, rev, must_read, "position", published_at, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: guide_categories; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.guide_categories (id, tenant_id, name, "position", created_at) FROM stdin;
\.


--
-- Data for Name: guide_reads; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.guide_reads (tenant_id, article_id, user_id, version, read_at) FROM stdin;
\.


--
-- Data for Name: guide_reminder_registry; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.guide_reminder_registry (tenant_id) FROM stdin;
\.


--
-- Data for Name: guide_settings; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.guide_settings (tenant_id, frequency, remind_time, weekday, audience, last_sent_on, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.idempotency_keys (tenant_id, key, user_id, request_hash, status_code, response, created_at) FROM stdin;
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.import_batches (id, tenant_id, kind, label, created_by, created_at, undone_at, undone_by) FROM stdin;
\.


--
-- Data for Name: ledger_entries; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.ledger_entries (id, seq, tenant_id, branch_id, business_day_id, occurred_at, recorded_at, recorded_by, asset, denomination, delta_count, delta_top, delta_down, delta_value, source_type, source_id, memo, reverses_entry_id) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.notifications (id, tenant_id, user_id, kind, title, body, link, created_at, read_at) FROM stdin;
\.


--
-- Data for Name: origin_towns; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.origin_towns (id, tenant_id, name, name_key, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: price_feed_events; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.price_feed_events (id, tenant_id, at, kind, state, message, base_price, published_at, usd_per_ounce, rate, discount_pct, computed, excerpt, decided_by, decided_at) FROM stdin;
\.


--
-- Data for Name: price_feed_registry; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.price_feed_registry (tenant_id) FROM stdin;
\.


--
-- Data for Name: price_feed_settings; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.price_feed_settings (tenant_id, enabled, windows, weekdays, timezone, margin_policy, max_jump_pct, updated_by, updated_at, last_checked_at, last_result) FROM stdin;
\.


--
-- Data for Name: price_snapshots; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.price_snapshots (id, tenant_id, source, base_price, published_at, fetched_at, raw, created_by) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.refresh_tokens (id, tenant_id, user_id, family_id, token_hash, issued_at, expires_at, revoked_at, replaced_by, user_agent, ip) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.role_permissions (tenant_id, role_id, permission) FROM stdin;
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	calculator:use
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	transactions:read
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	transactions:create
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	days:read
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	days:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	debts:read
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	debts:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	customers:read
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	transfers:read
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	transfers:create
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	transfers:receive
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	days:signoff
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	kumasi:set-value
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	reports:read
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	branches:all
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	payments:confirm
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	customers:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	discrepancies:review
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	notes:exchange
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	sync:review
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	prices:approve
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	users:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	branches:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	imports:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	audit:read
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	settings:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	guide:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	calculator:use
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	transactions:read
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	transactions:create
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	days:read
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	days:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	debts:read
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	debts:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	customers:read
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	transfers:read
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	transfers:create
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	transfers:receive
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	days:signoff
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	kumasi:set-value
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	reports:read
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	branches:all
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	payments:confirm
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	customers:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	discrepancies:review
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	notes:exchange
31e4ae7d-209c-4bca-8d64-b851570071d1	0519b92e-ae38-43ab-8c83-8ae6a2924eff	sync:review
31e4ae7d-209c-4bca-8d64-b851570071d1	30d15a69-0bfa-42d0-b3bc-a98b1508ab27	calculator:use
31e4ae7d-209c-4bca-8d64-b851570071d1	30d15a69-0bfa-42d0-b3bc-a98b1508ab27	transactions:read
31e4ae7d-209c-4bca-8d64-b851570071d1	30d15a69-0bfa-42d0-b3bc-a98b1508ab27	transactions:create
31e4ae7d-209c-4bca-8d64-b851570071d1	30d15a69-0bfa-42d0-b3bc-a98b1508ab27	days:read
31e4ae7d-209c-4bca-8d64-b851570071d1	30d15a69-0bfa-42d0-b3bc-a98b1508ab27	days:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	30d15a69-0bfa-42d0-b3bc-a98b1508ab27	debts:read
31e4ae7d-209c-4bca-8d64-b851570071d1	30d15a69-0bfa-42d0-b3bc-a98b1508ab27	debts:manage
31e4ae7d-209c-4bca-8d64-b851570071d1	30d15a69-0bfa-42d0-b3bc-a98b1508ab27	customers:read
31e4ae7d-209c-4bca-8d64-b851570071d1	30d15a69-0bfa-42d0-b3bc-a98b1508ab27	transfers:read
31e4ae7d-209c-4bca-8d64-b851570071d1	30d15a69-0bfa-42d0-b3bc-a98b1508ab27	transfers:create
31e4ae7d-209c-4bca-8d64-b851570071d1	30d15a69-0bfa-42d0-b3bc-a98b1508ab27	transfers:receive
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.roles (id, tenant_id, key, name, is_system, description) FROM stdin;
5c5b7ee1-7265-44fe-9e44-b34167ca7c81	31e4ae7d-209c-4bca-8d64-b851570071d1	director	Director	t	\N
0519b92e-ae38-43ab-8c83-8ae6a2924eff	31e4ae7d-209c-4bca-8d64-b851570071d1	manager	Manager	t	\N
30d15a69-0bfa-42d0-b3bc-a98b1508ab27	31e4ae7d-209c-4bca-8d64-b851570071d1	teller	Teller	t	\N
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.schema_migrations (version, checksum, applied_at) FROM stdin;
0001_foundation.sql	0B6701391DDCBD31DE80D6A747321613F317289AB507161A165B6392B0A4065A	2026-11-07 15:45:33.632879+00
0002_pricing_customers.sql	13F0CF87D55873449BB7C84A7597D5E49F46B042EA1386237380AD25D5AF4DED	2026-11-07 15:45:34.139275+00
0003_days_ledger.sql	610A6CEBCAE6862D1909F163F315FB2A5314A8A75CF226C9E6326B231127796B	2026-11-07 15:45:34.26544+00
0004_transactions.sql	541708E615CBF6278B36BA1B33A0EBF0E83678337C92BD8E0F790767C3253B37	2026-11-07 15:45:34.484688+00
0005_transfers.sql	10EBF20519556B5E8297B61A9FDC6E77CB58A68D47C3EAD22699F08F34410157	2026-11-07 15:45:34.676331+00
0006_discrepancies.sql	49A6BC49204865B7285B7474186635DE25FA9FD8F8F8AF67D802D9210AC5C052	2026-11-07 15:45:34.87087+00
0007_tenant_isolation.sql	AEAFB294C471066292E3E019D8493B5EDBADFFEFAB69E6E0B8615887DB430A79	2026-11-07 15:45:35.061953+00
0008_app_grants.sql	6AC93A5732AA636711881E05C16BDFDCB02C07BE558C1D5C85B04AABEF728C69	2026-11-07 15:45:35.210419+00
0009_payables_split_payments_cash_transfers.sql	37A87F8CA176809485EC9C8786F2671F538E5DDE13FE3B0D2942D6B5AD770DC9	2026-11-07 15:45:35.251051+00
0010_auth_support.sql	0FAE666FA6272AE9D8E0D2E64B67B493382B36083C4589B7B697438A23DFB294	2026-11-07 15:45:35.829728+00
0011_operations_core.sql	0895BB52E4E6E8F6A7E91911BF95C8152F28A194B2B6C3CE528C6B8C3132ED4D	2026-11-07 15:45:36.287486+00
0012_day_closing.sql	2C7E91C3EEDECAAE33006BF8E1121FF633D56D8D4C0CE388561995C28D1A561D	2026-11-07 15:45:37.000552+00
0013_pending_payments.sql	7A1FFC672DAE710778FF1E33643AB63A0E8CB90335E972A1B62E6F9BEDFF238D	2026-11-07 15:45:37.130428+00
0014_people.sql	67505D99D0D0B50A96581BEE50E975946E6F481F6E590DF32DA7B7C42787654C	2026-11-07 15:45:37.228551+00
0015_transfers.sql	575AA09417EBB2A7CB6505AB5EBF29CDF1F9AF86339D2A0B8C8349E48C777A63	2026-11-07 15:45:37.416252+00
0016_customer_lookup.sql	18284D53BA5AF59FB602323F8D3DDE84863D22A503F0CDC85A00B930542FE72D	2026-11-07 15:45:37.643189+00
0017_day_activity.sql	4FAC4FEB4A4BA5EC99ED598B898B84959E03AC6CA767B5B8E1FEB7D238741E79	2026-11-07 15:45:37.794401+00
0018_review.sql	EF5DE42B5021182A695F84961ABC8814430AA1F9ADFA7D515F50BDF7130E8BEB	2026-11-07 15:45:37.923221+00
0019_notifications.sql	502F5648385DB7C692B30194B4D525E3512CC6652776FE92AA18FFD37BECC754	2026-11-07 15:45:38.056339+00
0020_history_import.sql	FC4D115FAAB582B6CB6077A317539551BD833B639A78D3DD3871D7A6AEF72AA9	2026-11-07 15:45:38.242298+00
0021_opening_balances.sql	B6F3F6A87D4D5C20EB6504ADD2B4487CB09BC21862490E48203E5DA4DFEB47A3	2026-11-07 15:45:38.394176+00
0022_transactions_export.sql	EE2A8BFF4AD3F07DCF0739A3C3A8CE0E88DFDA12D0280CBE7604360CE01A9DD1	2026-11-07 15:45:38.574043+00
0023_price_feed.sql	C93684D52D34475546238293DDF9F7EDD84A74942ED97E86080E5165502BE377	2026-11-07 15:45:38.714142+00
0024_branch_starting_price.sql	8B9A32D292E1640D292E011B9E0C7F9D6A6FA41BE32592442D9AAB7311AC2CB1	2026-11-07 15:45:38.880601+00
0025_transactions_search.sql	801783E9446CB26AAFA207FCD124C7189370FDD875B6E0ADE6381EA7F362D97A	2026-11-07 15:45:38.950456+00
0026_dashboard.sql	021885900238697CDC965BEE903B6006CF7BE078A27B97EBB55381D98AAA2D4C	2026-11-07 15:45:39.049373+00
0027_customers_and_receipt.sql	E6F26FE6AF2902302AA2CAB8C009FF5F03714FB210D77EDDB199A26AB1BAF52F	2026-11-07 15:45:39.200285+00
0028_branch_overview.sql	4604677783035AC1D5256A7C69C320BD41C3D8FD2DB24CC475B3E650BAFF6902	2026-11-07 15:45:39.298585+00
0029_activity_feed.sql	583FB029951AD004FAF8C6B8F7761A96A659E480CEF50F5052DDFEA2576663A1	2026-11-07 15:45:39.393242+00
0030_roles.sql	87548A8B6188157B3DD5E739222B5D4AC47EF6AD849B561A400AE30647CC9D8B	2026-11-07 15:45:39.522444+00
0031_late_purchases.sql	3EAF82C8855EF4CAE15329EDCFD431F0D8DEAF9C4190700F1C6F78ED2CDCB106	2026-11-07 15:45:39.639596+00
0032_after_close_session.sql	BB870860CBF0306D9F237F8D6AD297E62B2AF2CAD992036C935E31AACA32C368	2026-11-07 15:45:39.74434+00
0033_late_movements.sql	65A96CF5FEF534A764FAB5548E78D7C9566DED835DE0608BFFB42617367C3665	2026-11-07 15:45:39.857915+00
0034_customer_edit_conflict.sql	43B0150BD0C8EBAC5D0E36D80E8BFA0E714D5F35186F72826F1A84CFC0FDFA3A	2026-11-07 15:45:39.958442+00
0035_rejected_signoff.sql	6C3EC8BD0E5681D593131920657BDFCD4B826CC4185B645796F97ED68CD7173F	2026-11-07 15:45:40.052249+00
0036_daily_account.sql	57744D3FB5D9001875FA2726885A0A2850DE047C243F58E7C4F553E1185E3CFF	2026-11-07 15:45:40.146498+00
0037_note_exchange.sql	8E9417DA237FA3A9627247F3CB9012D718B8409F6B6C7EFFEA243BCFDBFBBFA1	2026-11-07 15:45:40.274572+00
0038_two_step_payout.sql	0ABEC5C7EE7D7D677AF3D8EA5C41CD347F353C3A489633902B4DFF769F0A55D2	2026-11-07 15:45:40.471941+00
0039_transfer_recall.sql	2CC8EDFCD77BF868535C7815072A5A2A9573511A16FB91BD3378198BDA5A950E	2026-11-07 15:45:40.636289+00
0040_orgin_town.sql	7D896BA5D40B95432225689C79D90279174FD28B841FC39ED38C79614C8520E7	2026-11-07 15:45:40.748845+00
0041_carat_expectations.sql	426957C15E634DB2F0277332054B425365178CEF9C07E50E9721AE3152AA751B	2026-11-07 15:45:40.923707+00
0042_price_feed_gaps.sql	570DBC711F55D6490A4ACDC07E9801FA6459B42F4F70BE2CFFC2CCD062EA0276	2026-11-07 15:45:41.557767+00
0043_blind_count_setting.sql	D04408F4D2381C2D4557411019BD8BE6CF73C1DE8D887E6B3021020533A3DAB2	2026-11-07 15:45:41.644879+00
0044_branch_note_exchange.sql	078CBB076A4D5897D56F5BDBF5E510850EE678859BD9D25EA2A8D0CA0C4861BD	2026-11-07 15:45:41.708267+00
0045_customer_auto_create.sql	8F115F576FC0F5048CF1BBDB71A06DFEB649393DDE31B3A73FA176BE13EE5A5B	2026-11-07 15:45:41.801554+00
0046_guide.sql	8BDD201D5FB48902FA9338B21C3F6224CDD14E20324B0C1CFF7CDE203A9C3A38	2026-11-07 15:45:41.895562+00
0047_offline_days.sql	783A846F54ED371946327CF88DE211449C6EC956B4F4E5C2E0F13D80F842F643	2026-11-07 15:45:42.157526+00
0048_offline_sync.sql	C88E19B1BAED80BAB1DB75108BD3F2B8D96FDEDBA9AE8B7D630B650E3F36059A	2026-11-07 15:45:42.203704+00
\.


--
-- Data for Name: sync_commands; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.sync_commands (id, tenant_id, user_id, device_id, type, payload, branch_id, captured_at, received_at, status, code, message, flags, resolved_by, resolved_at, resolution) FROM stdin;
\.


--
-- Data for Name: tenant_settings; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.tenant_settings (tenant_id, key, value, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.tenants (id, slug, name, currency, settings, is_active, created_at) FROM stdin;
31e4ae7d-209c-4bca-8d64-b851570071d1	demo	Gilded Gold Enterprise	GHS	{}	t	2026-11-07 17:49:07.666499+00
\.


--
-- Data for Name: transaction_items; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.transaction_items (id, tenant_id, transaction_id, line_no, label, top, down, price, density, karat, purity, net_weight, pounds, amount, location_branch_id, location_state) FROM stdin;
\.


--
-- Data for Name: transaction_payments; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.transaction_payments (id, tenant_id, transaction_id, method, amount, paid_by_branch_id, external_ref, debt_id, status, confirmed_by, confirmed_at, recorded_by, note, created_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.transactions (id, tenant_id, branch_id, business_day_id, reference, customer_id, customer_name, customer_phone, status, formula_version, price_as_of, client_amount, calculated_amount, payout_policy, payout_strategy, payable, payout_difference, captured_at, created_at, created_by, flags, voided_at, voided_by, void_reason, represented_by_name, represented_by_phone, imported_batch, import_key, import_ref, import_note, stage, cash_due, suggested_lines, paid_by, paid_at, check_amount, check_matched, origin_town_id) FROM stdin;
\.


--
-- Data for Name: transfer_events; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.transfer_events (id, tenant_id, transfer_id, event_type, actor_user_id, occurred_at, recorded_at, data) FROM stdin;
\.


--
-- Data for Name: transfer_goods_lines; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.transfer_goods_lines (id, tenant_id, transfer_id, line_no, transaction_item_id, description, released_top, released_down, released_value, received_top, received_down, received_value, outcome) FROM stdin;
\.


--
-- Data for Name: transfer_payments; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.transfer_payments (id, tenant_id, transfer_id, direction, amount, method, purpose, external_ref, paid_at, recorded_by, note, created_at) FROM stdin;
\.


--
-- Data for Name: transfers; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.transfers (id, tenant_id, reference, origin_branch_id, destination_branch_id, purpose, purpose_note, method, status, released_by, released_at, release_note, collector_type, collector_user_id, collector_name, collector_phone, collector_id_type, collector_id_number, collector_relationship, collected_at, expected_arrival_at, declared_top, declared_down, declared_value, received_by, received_at, received_top, received_down, received_value, receipt_note, cancelled_at, cancelled_by, cancel_reason, created_by, created_at, kind, visit_id, declared_cash, received_cash) FROM stdin;
\.


--
-- Data for Name: user_branches; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.user_branches (tenant_id, user_id, branch_id, is_primary) FROM stdin;
31e4ae7d-209c-4bca-8d64-b851570071d1	8a30126a-e48f-47ac-8b8e-9945a66a837f	32e7c258-477e-418a-91a2-e455fd4ad46b	t
\.


--
-- Data for Name: user_permission_overrides; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.user_permission_overrides (tenant_id, user_id, permission, effect) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: gold; Owner: -
--

COPY gold.users (id, tenant_id, username, display_name, email, phone, password_hash, role_id, is_active, failed_login_count, locked_until, last_login_at, created_at, updated_at, must_change_password) FROM stdin;
8a30126a-e48f-47ac-8b8e-9945a66a837f	31e4ae7d-209c-4bca-8d64-b851570071d1	director	director	\N	\N	pbkdf2-sha256$600000$MY1f2KicTy5DMfLexCuHwQ==$4kfy9pJggihsDh3dnv1ibhoM5vP5jleyrseDmCHrg0s=	5c5b7ee1-7265-44fe-9e44-b34167ca7c81	t	0	\N	\N	2026-11-07 17:49:07.666499+00	2026-11-07 17:49:07.666499+00	f
\.


--
-- Name: audit_events_id_seq; Type: SEQUENCE SET; Schema: gold; Owner: -
--

SELECT pg_catalog.setval('gold.audit_events_id_seq', 1, false);


--
-- Name: discrepancy_actions_id_seq; Type: SEQUENCE SET; Schema: gold; Owner: -
--

SELECT pg_catalog.setval('gold.discrepancy_actions_id_seq', 1, false);


--
-- Name: ledger_entries_seq_seq; Type: SEQUENCE SET; Schema: gold; Owner: -
--

SELECT pg_catalog.setval('gold.ledger_entries_seq_seq', 1, false);


--
-- Name: transfer_events_id_seq; Type: SEQUENCE SET; Schema: gold; Owner: -
--

SELECT pg_catalog.setval('gold.transfer_events_id_seq', 1, false);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: branch_prices branch_prices_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.branch_prices
    ADD CONSTRAINT branch_prices_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: branches branches_tenant_id_code_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.branches
    ADD CONSTRAINT branches_tenant_id_code_key UNIQUE (tenant_id, code);


--
-- Name: branches branches_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.branches
    ADD CONSTRAINT branches_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: business_days business_days_closing_command_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.business_days
    ADD CONSTRAINT business_days_closing_command_id_key UNIQUE (closing_command_id);


--
-- Name: business_days business_days_one_per_session; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.business_days
    ADD CONSTRAINT business_days_one_per_session UNIQUE (tenant_id, branch_id, business_date, session_no);


--
-- Name: business_days business_days_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.business_days
    ADD CONSTRAINT business_days_pkey PRIMARY KEY (id);


--
-- Name: business_days business_days_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.business_days
    ADD CONSTRAINT business_days_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: collateral_holdings collateral_holdings_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.collateral_holdings
    ADD CONSTRAINT collateral_holdings_pkey PRIMARY KEY (id);


--
-- Name: collateral_holdings collateral_holdings_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.collateral_holdings
    ADD CONSTRAINT collateral_holdings_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: customers customers_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.customers
    ADD CONSTRAINT customers_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: day_balances day_balances_business_day_id_kind_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.day_balances
    ADD CONSTRAINT day_balances_business_day_id_kind_key UNIQUE (business_day_id, kind);


--
-- Name: day_balances day_balances_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.day_balances
    ADD CONSTRAINT day_balances_pkey PRIMARY KEY (id);


--
-- Name: day_reconciliations day_reconciliations_business_day_id_phase_asset_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.day_reconciliations
    ADD CONSTRAINT day_reconciliations_business_day_id_phase_asset_key UNIQUE (business_day_id, phase, asset);


--
-- Name: day_reconciliations day_reconciliations_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.day_reconciliations
    ADD CONSTRAINT day_reconciliations_pkey PRIMARY KEY (id);


--
-- Name: debt_repayments debt_repayments_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.debt_repayments
    ADD CONSTRAINT debt_repayments_pkey PRIMARY KEY (id);


--
-- Name: debts debts_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.debts
    ADD CONSTRAINT debts_pkey PRIMARY KEY (id);


--
-- Name: debts debts_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.debts
    ADD CONSTRAINT debts_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: device_keys device_keys_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.device_keys
    ADD CONSTRAINT device_keys_pkey PRIMARY KEY (id);


--
-- Name: device_keys device_keys_tenant_id_user_id_device_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.device_keys
    ADD CONSTRAINT device_keys_tenant_id_user_id_device_id_key UNIQUE (tenant_id, user_id, device_id);


--
-- Name: discrepancies discrepancies_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.discrepancies
    ADD CONSTRAINT discrepancies_pkey PRIMARY KEY (id);


--
-- Name: discrepancies discrepancies_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.discrepancies
    ADD CONSTRAINT discrepancies_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: discrepancy_actions discrepancy_actions_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.discrepancy_actions
    ADD CONSTRAINT discrepancy_actions_pkey PRIMARY KEY (id);


--
-- Name: document_counters document_counters_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.document_counters
    ADD CONSTRAINT document_counters_pkey PRIMARY KEY (tenant_id, kind, branch_id, business_date);


--
-- Name: drawer_movements drawer_movements_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.drawer_movements
    ADD CONSTRAINT drawer_movements_pkey PRIMARY KEY (id);


--
-- Name: drawer_movements drawer_movements_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.drawer_movements
    ADD CONSTRAINT drawer_movements_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: formula_versions formula_versions_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.formula_versions
    ADD CONSTRAINT formula_versions_pkey PRIMARY KEY (tenant_id, key);


--
-- Name: guide_articles guide_articles_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_articles
    ADD CONSTRAINT guide_articles_pkey PRIMARY KEY (id);


--
-- Name: guide_articles guide_articles_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_articles
    ADD CONSTRAINT guide_articles_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: guide_categories guide_categories_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_categories
    ADD CONSTRAINT guide_categories_pkey PRIMARY KEY (id);


--
-- Name: guide_categories guide_categories_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_categories
    ADD CONSTRAINT guide_categories_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: guide_reads guide_reads_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_reads
    ADD CONSTRAINT guide_reads_pkey PRIMARY KEY (article_id, user_id);


--
-- Name: guide_reminder_registry guide_reminder_registry_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_reminder_registry
    ADD CONSTRAINT guide_reminder_registry_pkey PRIMARY KEY (tenant_id);


--
-- Name: guide_settings guide_settings_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_settings
    ADD CONSTRAINT guide_settings_pkey PRIMARY KEY (tenant_id);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (tenant_id, key);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.import_batches
    ADD CONSTRAINT import_batches_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: ledger_entries ledger_entries_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.ledger_entries
    ADD CONSTRAINT ledger_entries_pkey PRIMARY KEY (id);


--
-- Name: ledger_entries ledger_entries_seq_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.ledger_entries
    ADD CONSTRAINT ledger_entries_seq_key UNIQUE (seq);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: origin_towns origin_towns_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.origin_towns
    ADD CONSTRAINT origin_towns_pkey PRIMARY KEY (id);


--
-- Name: origin_towns origin_towns_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.origin_towns
    ADD CONSTRAINT origin_towns_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: origin_towns origin_towns_tenant_id_name_key_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.origin_towns
    ADD CONSTRAINT origin_towns_tenant_id_name_key_key UNIQUE (tenant_id, name_key);


--
-- Name: price_feed_events price_feed_events_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.price_feed_events
    ADD CONSTRAINT price_feed_events_pkey PRIMARY KEY (id);


--
-- Name: price_feed_registry price_feed_registry_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.price_feed_registry
    ADD CONSTRAINT price_feed_registry_pkey PRIMARY KEY (tenant_id);


--
-- Name: price_feed_settings price_feed_settings_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.price_feed_settings
    ADD CONSTRAINT price_feed_settings_pkey PRIMARY KEY (tenant_id);


--
-- Name: price_snapshots price_snapshots_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.price_snapshots
    ADD CONSTRAINT price_snapshots_pkey PRIMARY KEY (id);


--
-- Name: price_snapshots price_snapshots_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.price_snapshots
    ADD CONSTRAINT price_snapshots_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_hash_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: roles roles_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.roles
    ADD CONSTRAINT roles_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: roles roles_tenant_id_key_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.roles
    ADD CONSTRAINT roles_tenant_id_key_key UNIQUE (tenant_id, key);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: sync_commands sync_commands_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.sync_commands
    ADD CONSTRAINT sync_commands_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (tenant_id, key);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: transaction_items transaction_items_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transaction_items
    ADD CONSTRAINT transaction_items_pkey PRIMARY KEY (id);


--
-- Name: transaction_items transaction_items_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transaction_items
    ADD CONSTRAINT transaction_items_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: transaction_items transaction_items_transaction_id_line_no_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transaction_items
    ADD CONSTRAINT transaction_items_transaction_id_line_no_key UNIQUE (transaction_id, line_no);


--
-- Name: transaction_payments transaction_payments_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transaction_payments
    ADD CONSTRAINT transaction_payments_pkey PRIMARY KEY (id);


--
-- Name: transaction_payments transaction_payments_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transaction_payments
    ADD CONSTRAINT transaction_payments_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_tenant_id_branch_id_reference_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transactions
    ADD CONSTRAINT transactions_tenant_id_branch_id_reference_key UNIQUE (tenant_id, branch_id, reference);


--
-- Name: transactions transactions_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transactions
    ADD CONSTRAINT transactions_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: transfer_events transfer_events_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfer_events
    ADD CONSTRAINT transfer_events_pkey PRIMARY KEY (id);


--
-- Name: transfer_goods_lines transfer_goods_lines_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfer_goods_lines
    ADD CONSTRAINT transfer_goods_lines_pkey PRIMARY KEY (id);


--
-- Name: transfer_goods_lines transfer_goods_lines_transfer_id_line_no_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfer_goods_lines
    ADD CONSTRAINT transfer_goods_lines_transfer_id_line_no_key UNIQUE (transfer_id, line_no);


--
-- Name: transfer_payments transfer_payments_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfer_payments
    ADD CONSTRAINT transfer_payments_pkey PRIMARY KEY (id);


--
-- Name: transfer_payments transfer_payments_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfer_payments
    ADD CONSTRAINT transfer_payments_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: transfers transfers_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfers
    ADD CONSTRAINT transfers_pkey PRIMARY KEY (id);


--
-- Name: transfers transfers_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfers
    ADD CONSTRAINT transfers_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: transfers transfers_tenant_id_reference_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfers
    ADD CONSTRAINT transfers_tenant_id_reference_key UNIQUE (tenant_id, reference);


--
-- Name: user_branches user_branches_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.user_branches
    ADD CONSTRAINT user_branches_pkey PRIMARY KEY (user_id, branch_id);


--
-- Name: user_permission_overrides user_permission_overrides_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.user_permission_overrides
    ADD CONSTRAINT user_permission_overrides_pkey PRIMARY KEY (user_id, permission);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_tenant_id_id_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.users
    ADD CONSTRAINT users_tenant_id_id_key UNIQUE (tenant_id, id);


--
-- Name: users users_tenant_id_username_key; Type: CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.users
    ADD CONSTRAINT users_tenant_id_username_key UNIQUE (tenant_id, username);


--
-- Name: attachments_entity; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX attachments_entity ON gold.attachments USING btree (tenant_id, entity_type, entity_id);


--
-- Name: audit_events_entity; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX audit_events_entity ON gold.audit_events USING btree (tenant_id, entity_type, entity_id);


--
-- Name: audit_events_when; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX audit_events_when ON gold.audit_events USING btree (tenant_id, occurred_at DESC);


--
-- Name: branch_prices_latest; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX branch_prices_latest ON gold.branch_prices USING btree (tenant_id, branch_id, effective_from DESC);


--
-- Name: branches_one_main_per_tenant; Type: INDEX; Schema: gold; Owner: -
--

CREATE UNIQUE INDEX branches_one_main_per_tenant ON gold.branches USING btree (tenant_id) WHERE is_main;


--
-- Name: business_days_branch_date; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX business_days_branch_date ON gold.business_days USING btree (tenant_id, branch_id, business_date DESC);


--
-- Name: business_days_one_open_per_branch; Type: INDEX; Schema: gold; Owner: -
--

CREATE UNIQUE INDEX business_days_one_open_per_branch ON gold.business_days USING btree (branch_id) WHERE (status = 'open'::text);


--
-- Name: collateral_branch_status; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX collateral_branch_status ON gold.collateral_holdings USING btree (tenant_id, branch_id, status);


--
-- Name: collateral_customer; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX collateral_customer ON gold.collateral_holdings USING btree (tenant_id, customer_id);


--
-- Name: customers_search; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX customers_search ON gold.customers USING btree (tenant_id, lower(name));


--
-- Name: debts_one_payable_per_transaction; Type: INDEX; Schema: gold; Owner: -
--

CREATE UNIQUE INDEX debts_one_payable_per_transaction ON gold.debts USING btree (source_transaction_id) WHERE ((direction = 'payable'::text) AND (source_transaction_id IS NOT NULL));


--
-- Name: discrepancies_one_per_reconciliation; Type: INDEX; Schema: gold; Owner: -
--

CREATE UNIQUE INDEX discrepancies_one_per_reconciliation ON gold.discrepancies USING btree (reconciliation_id) WHERE (reconciliation_id IS NOT NULL);


--
-- Name: discrepancies_one_per_transfer_line; Type: INDEX; Schema: gold; Owner: -
--

CREATE UNIQUE INDEX discrepancies_one_per_transfer_line ON gold.discrepancies USING btree (transfer_line_id) WHERE (transfer_line_id IS NOT NULL);


--
-- Name: discrepancies_open; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX discrepancies_open ON gold.discrepancies USING btree (tenant_id, branch_id, status) WHERE (status = ANY (ARRAY['open'::text, 'under_review'::text]));


--
-- Name: discrepancy_actions_case; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX discrepancy_actions_case ON gold.discrepancy_actions USING btree (discrepancy_id, id);


--
-- Name: guide_articles_cat; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX guide_articles_cat ON gold.guide_articles USING btree (tenant_id, category_id, "position");


--
-- Name: guide_categories_name; Type: INDEX; Schema: gold; Owner: -
--

CREATE UNIQUE INDEX guide_categories_name ON gold.guide_categories USING btree (tenant_id, lower(TRIM(BOTH FROM name)));


--
-- Name: idempotency_keys_age; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX idempotency_keys_age ON gold.idempotency_keys USING btree (created_at);


--
-- Name: ledger_branch_seq; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX ledger_branch_seq ON gold.ledger_entries USING btree (branch_id, seq);


--
-- Name: ledger_branch_time; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX ledger_branch_time ON gold.ledger_entries USING btree (branch_id, occurred_at);


--
-- Name: ledger_day; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX ledger_day ON gold.ledger_entries USING btree (business_day_id) WHERE (business_day_id IS NOT NULL);


--
-- Name: ledger_source; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX ledger_source ON gold.ledger_entries USING btree (source_type, source_id);


--
-- Name: notifications_inbox; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX notifications_inbox ON gold.notifications USING btree (user_id, created_at DESC);


--
-- Name: notifications_unread; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX notifications_unread ON gold.notifications USING btree (user_id) WHERE (read_at IS NULL);


--
-- Name: price_feed_events_recent; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX price_feed_events_recent ON gold.price_feed_events USING btree (tenant_id, at DESC);


--
-- Name: price_snapshots_latest; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX price_snapshots_latest ON gold.price_snapshots USING btree (tenant_id, published_at DESC);


--
-- Name: refresh_tokens_family; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX refresh_tokens_family ON gold.refresh_tokens USING btree (family_id);


--
-- Name: refresh_tokens_user; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX refresh_tokens_user ON gold.refresh_tokens USING btree (user_id) WHERE (revoked_at IS NULL);


--
-- Name: sync_commands_review; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX sync_commands_review ON gold.sync_commands USING btree (tenant_id, status, received_at);


--
-- Name: transaction_items_location; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX transaction_items_location ON gold.transaction_items USING btree (tenant_id, location_branch_id, location_state);


--
-- Name: transaction_payments_tx; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX transaction_payments_tx ON gold.transaction_payments USING btree (transaction_id);


--
-- Name: transactions_branch_time; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX transactions_branch_time ON gold.transactions USING btree (tenant_id, branch_id, captured_at DESC);


--
-- Name: transactions_customer; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX transactions_customer ON gold.transactions USING btree (tenant_id, customer_id) WHERE (customer_id IS NOT NULL);


--
-- Name: transactions_import_once; Type: INDEX; Schema: gold; Owner: -
--

CREATE UNIQUE INDEX transactions_import_once ON gold.transactions USING btree (tenant_id, imported_batch, import_key) WHERE (imported_batch IS NOT NULL);


--
-- Name: transactions_origin_town; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX transactions_origin_town ON gold.transactions USING btree (tenant_id, origin_town_id) WHERE (origin_town_id IS NOT NULL);


--
-- Name: transactions_to_pay; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX transactions_to_pay ON gold.transactions USING btree (tenant_id, branch_id, created_at DESC) WHERE ((stage = 'to_pay'::text) AND (status <> 'void'::text));


--
-- Name: transfer_events_transfer; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX transfer_events_transfer ON gold.transfer_events USING btree (transfer_id, id);


--
-- Name: transfer_goods_lines_item; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX transfer_goods_lines_item ON gold.transfer_goods_lines USING btree (transaction_item_id) WHERE (transaction_item_id IS NOT NULL);


--
-- Name: transfers_destination; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX transfers_destination ON gold.transfers USING btree (tenant_id, destination_branch_id, created_at DESC);


--
-- Name: transfers_open; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX transfers_open ON gold.transfers USING btree (tenant_id, status) WHERE (status = ANY (ARRAY['draft'::text, 'released'::text]));


--
-- Name: transfers_origin; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX transfers_origin ON gold.transfers USING btree (tenant_id, origin_branch_id, created_at DESC);


--
-- Name: transfers_visit; Type: INDEX; Schema: gold; Owner: -
--

CREATE INDEX transfers_visit ON gold.transfers USING btree (tenant_id, visit_id) WHERE (visit_id IS NOT NULL);


--
-- Name: attachments attachments_immutable; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER attachments_immutable BEFORE DELETE OR UPDATE ON gold.attachments FOR EACH ROW EXECUTE FUNCTION gold.forbid_mutation();


--
-- Name: audit_events audit_events_immutable; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER audit_events_immutable BEFORE DELETE OR UPDATE ON gold.audit_events FOR EACH ROW EXECUTE FUNCTION gold.forbid_mutation();


--
-- Name: branch_prices branch_prices_immutable; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER branch_prices_immutable BEFORE DELETE ON gold.branch_prices FOR EACH ROW EXECUTE FUNCTION gold.forbid_mutation();


--
-- Name: day_balances day_balances_immutable; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER day_balances_immutable BEFORE DELETE OR UPDATE ON gold.day_balances FOR EACH ROW EXECUTE FUNCTION gold.forbid_mutation();


--
-- Name: day_reconciliations day_reconciliations_immutable; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER day_reconciliations_immutable BEFORE DELETE OR UPDATE ON gold.day_reconciliations FOR EACH ROW EXECUTE FUNCTION gold.forbid_mutation();


--
-- Name: debt_repayments debt_repayments_immutable; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER debt_repayments_immutable BEFORE DELETE OR UPDATE ON gold.debt_repayments FOR EACH ROW EXECUTE FUNCTION gold.forbid_mutation();


--
-- Name: discrepancies discrepancies_guard; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER discrepancies_guard BEFORE DELETE ON gold.discrepancies FOR EACH ROW EXECUTE FUNCTION gold.discrepancy_guard();


--
-- Name: discrepancies discrepancies_guard_ins; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER discrepancies_guard_ins AFTER INSERT ON gold.discrepancies FOR EACH ROW EXECUTE FUNCTION gold.discrepancy_guard();


--
-- Name: discrepancies discrepancies_guard_upd; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER discrepancies_guard_upd AFTER UPDATE ON gold.discrepancies FOR EACH ROW EXECUTE FUNCTION gold.discrepancy_guard();


--
-- Name: discrepancy_actions discrepancy_actions_immutable; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER discrepancy_actions_immutable BEFORE DELETE OR UPDATE ON gold.discrepancy_actions FOR EACH ROW EXECUTE FUNCTION gold.forbid_mutation();


--
-- Name: drawer_movements drawer_movements_immutable; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER drawer_movements_immutable BEFORE DELETE OR UPDATE ON gold.drawer_movements FOR EACH ROW EXECUTE FUNCTION gold.forbid_mutation();


--
-- Name: ledger_entries ledger_immutable; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER ledger_immutable BEFORE DELETE OR UPDATE ON gold.ledger_entries FOR EACH ROW EXECUTE FUNCTION gold.forbid_mutation();


--
-- Name: business_days publish_day; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER publish_day AFTER INSERT OR UPDATE ON gold.business_days FOR EACH ROW EXECUTE FUNCTION gold.trg_publish_day();


--
-- Name: debts publish_debts; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER publish_debts AFTER INSERT OR UPDATE ON gold.debts FOR EACH ROW EXECUTE FUNCTION gold.trg_publish_quiet('debts');


--
-- Name: discrepancies publish_discrepancy; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER publish_discrepancy AFTER INSERT OR UPDATE ON gold.discrepancies FOR EACH ROW EXECUTE FUNCTION gold.trg_publish_discrepancy();


--
-- Name: ledger_entries publish_ledger; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER publish_ledger AFTER INSERT ON gold.ledger_entries FOR EACH ROW EXECUTE FUNCTION gold.trg_publish_quiet('ledger');


--
-- Name: transaction_payments publish_payment; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER publish_payment AFTER INSERT OR UPDATE ON gold.transaction_payments FOR EACH ROW EXECUTE FUNCTION gold.trg_publish_payment();


--
-- Name: branch_prices publish_price; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER publish_price AFTER INSERT OR UPDATE ON gold.branch_prices FOR EACH ROW EXECUTE FUNCTION gold.trg_publish_price();


--
-- Name: price_snapshots publish_snapshot; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER publish_snapshot AFTER INSERT ON gold.price_snapshots FOR EACH ROW EXECUTE FUNCTION gold.trg_publish_snapshot();


--
-- Name: transactions publish_transactions; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER publish_transactions AFTER INSERT ON gold.transactions FOR EACH ROW EXECUTE FUNCTION gold.trg_publish_quiet('transactions');


--
-- Name: transfers publish_transfers; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER publish_transfers AFTER INSERT OR UPDATE ON gold.transfers FOR EACH ROW EXECUTE FUNCTION gold.trg_publish_transfers();


--
-- Name: transaction_payments transaction_payments_guard; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER transaction_payments_guard BEFORE DELETE OR UPDATE ON gold.transaction_payments FOR EACH ROW EXECUTE FUNCTION gold.payment_guard();


--
-- Name: transaction_payments transaction_payments_split; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE CONSTRAINT TRIGGER transaction_payments_split AFTER INSERT OR UPDATE ON gold.transaction_payments DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION gold.check_payment_split();


--
-- Name: transfer_events transfer_events_immutable; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER transfer_events_immutable BEFORE DELETE OR UPDATE ON gold.transfer_events FOR EACH ROW EXECUTE FUNCTION gold.forbid_mutation();


--
-- Name: transfer_payments transfer_payments_immutable; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER transfer_payments_immutable BEFORE DELETE OR UPDATE ON gold.transfer_payments FOR EACH ROW EXECUTE FUNCTION gold.forbid_mutation();


--
-- Name: users users_touch; Type: TRIGGER; Schema: gold; Owner: -
--

CREATE TRIGGER users_touch BEFORE UPDATE ON gold.users FOR EACH ROW EXECUTE FUNCTION gold.touch_updated_at();


--
-- Name: attachments attachments_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.attachments
    ADD CONSTRAINT attachments_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: audit_events audit_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.audit_events
    ADD CONSTRAINT audit_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: branch_prices branch_prices_tenant_id_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.branch_prices
    ADD CONSTRAINT branch_prices_tenant_id_branch_id_fkey FOREIGN KEY (tenant_id, branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: branch_prices branch_prices_tenant_id_set_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.branch_prices
    ADD CONSTRAINT branch_prices_tenant_id_set_by_fkey FOREIGN KEY (tenant_id, set_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: branch_prices branch_prices_tenant_id_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.branch_prices
    ADD CONSTRAINT branch_prices_tenant_id_snapshot_id_fkey FOREIGN KEY (tenant_id, snapshot_id) REFERENCES gold.price_snapshots(tenant_id, id);


--
-- Name: branches branches_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.branches
    ADD CONSTRAINT branches_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: business_days business_days_tenant_id_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.business_days
    ADD CONSTRAINT business_days_tenant_id_branch_id_fkey FOREIGN KEY (tenant_id, branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: business_days business_days_tenant_id_closed_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.business_days
    ADD CONSTRAINT business_days_tenant_id_closed_by_fkey FOREIGN KEY (tenant_id, closed_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: business_days business_days_tenant_id_opened_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.business_days
    ADD CONSTRAINT business_days_tenant_id_opened_by_fkey FOREIGN KEY (tenant_id, opened_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: business_days business_days_tenant_id_previous_day_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.business_days
    ADD CONSTRAINT business_days_tenant_id_previous_day_id_fkey FOREIGN KEY (tenant_id, previous_day_id) REFERENCES gold.business_days(tenant_id, id);


--
-- Name: business_days business_days_tenant_id_signoff_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.business_days
    ADD CONSTRAINT business_days_tenant_id_signoff_by_fkey FOREIGN KEY (tenant_id, signoff_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: collateral_holdings collateral_holdings_tenant_id_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.collateral_holdings
    ADD CONSTRAINT collateral_holdings_tenant_id_branch_id_fkey FOREIGN KEY (tenant_id, branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: collateral_holdings collateral_holdings_tenant_id_closed_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.collateral_holdings
    ADD CONSTRAINT collateral_holdings_tenant_id_closed_by_fkey FOREIGN KEY (tenant_id, closed_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: collateral_holdings collateral_holdings_tenant_id_converted_transaction_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.collateral_holdings
    ADD CONSTRAINT collateral_holdings_tenant_id_converted_transaction_id_fkey FOREIGN KEY (tenant_id, converted_transaction_id) REFERENCES gold.transactions(tenant_id, id);


--
-- Name: collateral_holdings collateral_holdings_tenant_id_customer_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.collateral_holdings
    ADD CONSTRAINT collateral_holdings_tenant_id_customer_id_fkey FOREIGN KEY (tenant_id, customer_id) REFERENCES gold.customers(tenant_id, id);


--
-- Name: collateral_holdings collateral_holdings_tenant_id_debt_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.collateral_holdings
    ADD CONSTRAINT collateral_holdings_tenant_id_debt_id_fkey FOREIGN KEY (tenant_id, debt_id) REFERENCES gold.debts(tenant_id, id);


--
-- Name: collateral_holdings collateral_holdings_tenant_id_received_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.collateral_holdings
    ADD CONSTRAINT collateral_holdings_tenant_id_received_by_fkey FOREIGN KEY (tenant_id, received_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: customers customers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.customers
    ADD CONSTRAINT customers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: day_balances day_balances_tenant_id_business_day_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.day_balances
    ADD CONSTRAINT day_balances_tenant_id_business_day_id_fkey FOREIGN KEY (tenant_id, business_day_id) REFERENCES gold.business_days(tenant_id, id);


--
-- Name: day_reconciliations day_reconciliations_tenant_id_business_day_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.day_reconciliations
    ADD CONSTRAINT day_reconciliations_tenant_id_business_day_id_fkey FOREIGN KEY (tenant_id, business_day_id) REFERENCES gold.business_days(tenant_id, id);


--
-- Name: day_reconciliations day_reconciliations_tenant_id_explained_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.day_reconciliations
    ADD CONSTRAINT day_reconciliations_tenant_id_explained_by_fkey FOREIGN KEY (tenant_id, explained_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: debt_repayments debt_repayments_tenant_id_debt_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.debt_repayments
    ADD CONSTRAINT debt_repayments_tenant_id_debt_id_fkey FOREIGN KEY (tenant_id, debt_id) REFERENCES gold.debts(tenant_id, id);


--
-- Name: debt_repayments debt_repayments_tenant_id_paid_by_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.debt_repayments
    ADD CONSTRAINT debt_repayments_tenant_id_paid_by_branch_id_fkey FOREIGN KEY (tenant_id, paid_by_branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: debt_repayments debt_repayments_tenant_id_received_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.debt_repayments
    ADD CONSTRAINT debt_repayments_tenant_id_received_by_fkey FOREIGN KEY (tenant_id, received_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: debt_repayments debt_repayments_tenant_id_source_transaction_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.debt_repayments
    ADD CONSTRAINT debt_repayments_tenant_id_source_transaction_id_fkey FOREIGN KEY (tenant_id, source_transaction_id) REFERENCES gold.transactions(tenant_id, id);


--
-- Name: debts debts_tenant_id_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.debts
    ADD CONSTRAINT debts_tenant_id_branch_id_fkey FOREIGN KEY (tenant_id, branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: debts debts_tenant_id_customer_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.debts
    ADD CONSTRAINT debts_tenant_id_customer_id_fkey FOREIGN KEY (tenant_id, customer_id) REFERENCES gold.customers(tenant_id, id);


--
-- Name: debts debts_tenant_id_issued_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.debts
    ADD CONSTRAINT debts_tenant_id_issued_by_fkey FOREIGN KEY (tenant_id, issued_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: debts debts_tenant_id_source_transaction_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.debts
    ADD CONSTRAINT debts_tenant_id_source_transaction_id_fkey FOREIGN KEY (tenant_id, source_transaction_id) REFERENCES gold.transactions(tenant_id, id);


--
-- Name: device_keys device_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.device_keys
    ADD CONSTRAINT device_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: device_keys device_keys_tenant_id_user_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.device_keys
    ADD CONSTRAINT device_keys_tenant_id_user_id_fkey FOREIGN KEY (tenant_id, user_id) REFERENCES gold.users(tenant_id, id);


--
-- Name: discrepancies discrepancies_reconciliation_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.discrepancies
    ADD CONSTRAINT discrepancies_reconciliation_id_fkey FOREIGN KEY (reconciliation_id) REFERENCES gold.day_reconciliations(id);


--
-- Name: discrepancies discrepancies_tenant_id_assigned_to_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.discrepancies
    ADD CONSTRAINT discrepancies_tenant_id_assigned_to_fkey FOREIGN KEY (tenant_id, assigned_to) REFERENCES gold.users(tenant_id, id);


--
-- Name: discrepancies discrepancies_tenant_id_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.discrepancies
    ADD CONSTRAINT discrepancies_tenant_id_branch_id_fkey FOREIGN KEY (tenant_id, branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: discrepancies discrepancies_tenant_id_business_day_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.discrepancies
    ADD CONSTRAINT discrepancies_tenant_id_business_day_id_fkey FOREIGN KEY (tenant_id, business_day_id) REFERENCES gold.business_days(tenant_id, id);


--
-- Name: discrepancies discrepancies_tenant_id_resolved_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.discrepancies
    ADD CONSTRAINT discrepancies_tenant_id_resolved_by_fkey FOREIGN KEY (tenant_id, resolved_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: discrepancies discrepancies_tenant_id_transfer_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.discrepancies
    ADD CONSTRAINT discrepancies_tenant_id_transfer_id_fkey FOREIGN KEY (tenant_id, transfer_id) REFERENCES gold.transfers(tenant_id, id);


--
-- Name: discrepancies discrepancies_transfer_line_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.discrepancies
    ADD CONSTRAINT discrepancies_transfer_line_id_fkey FOREIGN KEY (transfer_line_id) REFERENCES gold.transfer_goods_lines(id);


--
-- Name: discrepancy_actions discrepancy_actions_tenant_id_discrepancy_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.discrepancy_actions
    ADD CONSTRAINT discrepancy_actions_tenant_id_discrepancy_id_fkey FOREIGN KEY (tenant_id, discrepancy_id) REFERENCES gold.discrepancies(tenant_id, id);


--
-- Name: document_counters document_counters_tenant_id_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.document_counters
    ADD CONSTRAINT document_counters_tenant_id_branch_id_fkey FOREIGN KEY (tenant_id, branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: document_counters document_counters_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.document_counters
    ADD CONSTRAINT document_counters_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: drawer_movements drawer_movements_tenant_id_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.drawer_movements
    ADD CONSTRAINT drawer_movements_tenant_id_branch_id_fkey FOREIGN KEY (tenant_id, branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: drawer_movements drawer_movements_tenant_id_business_day_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.drawer_movements
    ADD CONSTRAINT drawer_movements_tenant_id_business_day_id_fkey FOREIGN KEY (tenant_id, business_day_id) REFERENCES gold.business_days(tenant_id, id);


--
-- Name: drawer_movements drawer_movements_tenant_id_created_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.drawer_movements
    ADD CONSTRAINT drawer_movements_tenant_id_created_by_fkey FOREIGN KEY (tenant_id, created_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: drawer_movements drawer_movements_transaction_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.drawer_movements
    ADD CONSTRAINT drawer_movements_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES gold.transactions(id);


--
-- Name: formula_versions formula_versions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.formula_versions
    ADD CONSTRAINT formula_versions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: guide_articles guide_articles_tenant_id_category_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_articles
    ADD CONSTRAINT guide_articles_tenant_id_category_id_fkey FOREIGN KEY (tenant_id, category_id) REFERENCES gold.guide_categories(tenant_id, id);


--
-- Name: guide_articles guide_articles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_articles
    ADD CONSTRAINT guide_articles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: guide_categories guide_categories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_categories
    ADD CONSTRAINT guide_categories_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: guide_reads guide_reads_tenant_id_article_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_reads
    ADD CONSTRAINT guide_reads_tenant_id_article_id_fkey FOREIGN KEY (tenant_id, article_id) REFERENCES gold.guide_articles(tenant_id, id) ON DELETE CASCADE;


--
-- Name: guide_reads guide_reads_tenant_id_user_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_reads
    ADD CONSTRAINT guide_reads_tenant_id_user_id_fkey FOREIGN KEY (tenant_id, user_id) REFERENCES gold.users(tenant_id, id) ON DELETE CASCADE;


--
-- Name: guide_reminder_registry guide_reminder_registry_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_reminder_registry
    ADD CONSTRAINT guide_reminder_registry_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: guide_settings guide_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.guide_settings
    ADD CONSTRAINT guide_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: idempotency_keys idempotency_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.idempotency_keys
    ADD CONSTRAINT idempotency_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: import_batches import_batches_tenant_id_created_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.import_batches
    ADD CONSTRAINT import_batches_tenant_id_created_by_fkey FOREIGN KEY (tenant_id, created_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: ledger_entries ledger_entries_reverses_entry_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.ledger_entries
    ADD CONSTRAINT ledger_entries_reverses_entry_id_fkey FOREIGN KEY (reverses_entry_id) REFERENCES gold.ledger_entries(id);


--
-- Name: ledger_entries ledger_entries_tenant_id_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.ledger_entries
    ADD CONSTRAINT ledger_entries_tenant_id_branch_id_fkey FOREIGN KEY (tenant_id, branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: ledger_entries ledger_entries_tenant_id_business_day_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.ledger_entries
    ADD CONSTRAINT ledger_entries_tenant_id_business_day_id_fkey FOREIGN KEY (tenant_id, business_day_id) REFERENCES gold.business_days(tenant_id, id);


--
-- Name: ledger_entries ledger_entries_tenant_id_recorded_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.ledger_entries
    ADD CONSTRAINT ledger_entries_tenant_id_recorded_by_fkey FOREIGN KEY (tenant_id, recorded_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: notifications notifications_tenant_id_user_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.notifications
    ADD CONSTRAINT notifications_tenant_id_user_id_fkey FOREIGN KEY (tenant_id, user_id) REFERENCES gold.users(tenant_id, id) ON DELETE CASCADE;


--
-- Name: origin_towns origin_towns_tenant_id_created_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.origin_towns
    ADD CONSTRAINT origin_towns_tenant_id_created_by_fkey FOREIGN KEY (tenant_id, created_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: price_feed_events price_feed_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.price_feed_events
    ADD CONSTRAINT price_feed_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: price_feed_registry price_feed_registry_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.price_feed_registry
    ADD CONSTRAINT price_feed_registry_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: price_feed_settings price_feed_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.price_feed_settings
    ADD CONSTRAINT price_feed_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: price_feed_settings price_feed_settings_tenant_id_updated_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.price_feed_settings
    ADD CONSTRAINT price_feed_settings_tenant_id_updated_by_fkey FOREIGN KEY (tenant_id, updated_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: price_snapshots price_snapshots_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.price_snapshots
    ADD CONSTRAINT price_snapshots_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: refresh_tokens refresh_tokens_tenant_id_user_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.refresh_tokens
    ADD CONSTRAINT refresh_tokens_tenant_id_user_id_fkey FOREIGN KEY (tenant_id, user_id) REFERENCES gold.users(tenant_id, id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_tenant_id_role_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.role_permissions
    ADD CONSTRAINT role_permissions_tenant_id_role_id_fkey FOREIGN KEY (tenant_id, role_id) REFERENCES gold.roles(tenant_id, id) ON DELETE CASCADE;


--
-- Name: roles roles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.roles
    ADD CONSTRAINT roles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: sync_commands sync_commands_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.sync_commands
    ADD CONSTRAINT sync_commands_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: sync_commands sync_commands_tenant_id_user_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.sync_commands
    ADD CONSTRAINT sync_commands_tenant_id_user_id_fkey FOREIGN KEY (tenant_id, user_id) REFERENCES gold.users(tenant_id, id);


--
-- Name: tenant_settings tenant_settings_tenant_id_updated_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.tenant_settings
    ADD CONSTRAINT tenant_settings_tenant_id_updated_by_fkey FOREIGN KEY (tenant_id, updated_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: transaction_items transaction_items_tenant_id_location_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transaction_items
    ADD CONSTRAINT transaction_items_tenant_id_location_branch_id_fkey FOREIGN KEY (tenant_id, location_branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: transaction_items transaction_items_tenant_id_transaction_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transaction_items
    ADD CONSTRAINT transaction_items_tenant_id_transaction_id_fkey FOREIGN KEY (tenant_id, transaction_id) REFERENCES gold.transactions(tenant_id, id);


--
-- Name: transaction_payments transaction_payments_tenant_id_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transaction_payments
    ADD CONSTRAINT transaction_payments_tenant_id_confirmed_by_fkey FOREIGN KEY (tenant_id, confirmed_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: transaction_payments transaction_payments_tenant_id_debt_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transaction_payments
    ADD CONSTRAINT transaction_payments_tenant_id_debt_id_fkey FOREIGN KEY (tenant_id, debt_id) REFERENCES gold.debts(tenant_id, id);


--
-- Name: transaction_payments transaction_payments_tenant_id_paid_by_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transaction_payments
    ADD CONSTRAINT transaction_payments_tenant_id_paid_by_branch_id_fkey FOREIGN KEY (tenant_id, paid_by_branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: transaction_payments transaction_payments_tenant_id_recorded_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transaction_payments
    ADD CONSTRAINT transaction_payments_tenant_id_recorded_by_fkey FOREIGN KEY (tenant_id, recorded_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: transaction_payments transaction_payments_tenant_id_transaction_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transaction_payments
    ADD CONSTRAINT transaction_payments_tenant_id_transaction_id_fkey FOREIGN KEY (tenant_id, transaction_id) REFERENCES gold.transactions(tenant_id, id);


--
-- Name: transactions transactions_origin_town_fk; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transactions
    ADD CONSTRAINT transactions_origin_town_fk FOREIGN KEY (tenant_id, origin_town_id) REFERENCES gold.origin_towns(tenant_id, id);


--
-- Name: transactions transactions_tenant_id_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transactions
    ADD CONSTRAINT transactions_tenant_id_branch_id_fkey FOREIGN KEY (tenant_id, branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: transactions transactions_tenant_id_business_day_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transactions
    ADD CONSTRAINT transactions_tenant_id_business_day_id_fkey FOREIGN KEY (tenant_id, business_day_id) REFERENCES gold.business_days(tenant_id, id);


--
-- Name: transactions transactions_tenant_id_created_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transactions
    ADD CONSTRAINT transactions_tenant_id_created_by_fkey FOREIGN KEY (tenant_id, created_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: transactions transactions_tenant_id_customer_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transactions
    ADD CONSTRAINT transactions_tenant_id_customer_id_fkey FOREIGN KEY (tenant_id, customer_id) REFERENCES gold.customers(tenant_id, id);


--
-- Name: transactions transactions_tenant_id_formula_version_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transactions
    ADD CONSTRAINT transactions_tenant_id_formula_version_fkey FOREIGN KEY (tenant_id, formula_version) REFERENCES gold.formula_versions(tenant_id, key);


--
-- Name: transactions transactions_tenant_id_paid_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transactions
    ADD CONSTRAINT transactions_tenant_id_paid_by_fkey FOREIGN KEY (tenant_id, paid_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: transactions transactions_tenant_id_voided_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transactions
    ADD CONSTRAINT transactions_tenant_id_voided_by_fkey FOREIGN KEY (tenant_id, voided_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: transfer_events transfer_events_tenant_id_transfer_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfer_events
    ADD CONSTRAINT transfer_events_tenant_id_transfer_id_fkey FOREIGN KEY (tenant_id, transfer_id) REFERENCES gold.transfers(tenant_id, id);


--
-- Name: transfer_goods_lines transfer_goods_lines_tenant_id_transaction_item_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfer_goods_lines
    ADD CONSTRAINT transfer_goods_lines_tenant_id_transaction_item_id_fkey FOREIGN KEY (tenant_id, transaction_item_id) REFERENCES gold.transaction_items(tenant_id, id);


--
-- Name: transfer_goods_lines transfer_goods_lines_tenant_id_transfer_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfer_goods_lines
    ADD CONSTRAINT transfer_goods_lines_tenant_id_transfer_id_fkey FOREIGN KEY (tenant_id, transfer_id) REFERENCES gold.transfers(tenant_id, id);


--
-- Name: transfer_payments transfer_payments_tenant_id_recorded_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfer_payments
    ADD CONSTRAINT transfer_payments_tenant_id_recorded_by_fkey FOREIGN KEY (tenant_id, recorded_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: transfer_payments transfer_payments_tenant_id_transfer_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfer_payments
    ADD CONSTRAINT transfer_payments_tenant_id_transfer_id_fkey FOREIGN KEY (tenant_id, transfer_id) REFERENCES gold.transfers(tenant_id, id);


--
-- Name: transfers transfers_tenant_id_cancelled_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfers
    ADD CONSTRAINT transfers_tenant_id_cancelled_by_fkey FOREIGN KEY (tenant_id, cancelled_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: transfers transfers_tenant_id_collector_user_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfers
    ADD CONSTRAINT transfers_tenant_id_collector_user_id_fkey FOREIGN KEY (tenant_id, collector_user_id) REFERENCES gold.users(tenant_id, id);


--
-- Name: transfers transfers_tenant_id_created_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfers
    ADD CONSTRAINT transfers_tenant_id_created_by_fkey FOREIGN KEY (tenant_id, created_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: transfers transfers_tenant_id_destination_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfers
    ADD CONSTRAINT transfers_tenant_id_destination_branch_id_fkey FOREIGN KEY (tenant_id, destination_branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: transfers transfers_tenant_id_origin_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfers
    ADD CONSTRAINT transfers_tenant_id_origin_branch_id_fkey FOREIGN KEY (tenant_id, origin_branch_id) REFERENCES gold.branches(tenant_id, id);


--
-- Name: transfers transfers_tenant_id_received_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfers
    ADD CONSTRAINT transfers_tenant_id_received_by_fkey FOREIGN KEY (tenant_id, received_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: transfers transfers_tenant_id_released_by_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.transfers
    ADD CONSTRAINT transfers_tenant_id_released_by_fkey FOREIGN KEY (tenant_id, released_by) REFERENCES gold.users(tenant_id, id);


--
-- Name: user_branches user_branches_tenant_id_branch_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.user_branches
    ADD CONSTRAINT user_branches_tenant_id_branch_id_fkey FOREIGN KEY (tenant_id, branch_id) REFERENCES gold.branches(tenant_id, id) ON DELETE CASCADE;


--
-- Name: user_branches user_branches_tenant_id_user_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.user_branches
    ADD CONSTRAINT user_branches_tenant_id_user_id_fkey FOREIGN KEY (tenant_id, user_id) REFERENCES gold.users(tenant_id, id) ON DELETE CASCADE;


--
-- Name: user_permission_overrides user_permission_overrides_tenant_id_user_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.user_permission_overrides
    ADD CONSTRAINT user_permission_overrides_tenant_id_user_id_fkey FOREIGN KEY (tenant_id, user_id) REFERENCES gold.users(tenant_id, id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES gold.tenants(id);


--
-- Name: users users_tenant_id_role_id_fkey; Type: FK CONSTRAINT; Schema: gold; Owner: -
--

ALTER TABLE ONLY gold.users
    ADD CONSTRAINT users_tenant_id_role_id_fkey FOREIGN KEY (tenant_id, role_id) REFERENCES gold.roles(tenant_id, id);


--
-- Name: attachments; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.attachments ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_events; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.audit_events ENABLE ROW LEVEL SECURITY;

--
-- Name: branch_prices; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.branch_prices ENABLE ROW LEVEL SECURITY;

--
-- Name: branches; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.branches ENABLE ROW LEVEL SECURITY;

--
-- Name: business_days; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.business_days ENABLE ROW LEVEL SECURITY;

--
-- Name: collateral_holdings; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.collateral_holdings ENABLE ROW LEVEL SECURITY;

--
-- Name: customers; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.customers ENABLE ROW LEVEL SECURITY;

--
-- Name: day_balances; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.day_balances ENABLE ROW LEVEL SECURITY;

--
-- Name: day_reconciliations; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.day_reconciliations ENABLE ROW LEVEL SECURITY;

--
-- Name: debt_repayments; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.debt_repayments ENABLE ROW LEVEL SECURITY;

--
-- Name: debts; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.debts ENABLE ROW LEVEL SECURITY;

--
-- Name: device_keys; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.device_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: discrepancies; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.discrepancies ENABLE ROW LEVEL SECURITY;

--
-- Name: discrepancy_actions; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.discrepancy_actions ENABLE ROW LEVEL SECURITY;

--
-- Name: document_counters; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.document_counters ENABLE ROW LEVEL SECURITY;

--
-- Name: drawer_movements; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.drawer_movements ENABLE ROW LEVEL SECURITY;

--
-- Name: formula_versions; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.formula_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: guide_articles; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.guide_articles ENABLE ROW LEVEL SECURITY;

--
-- Name: guide_categories; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.guide_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: guide_reads; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.guide_reads ENABLE ROW LEVEL SECURITY;

--
-- Name: guide_settings; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.guide_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: idempotency_keys; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.idempotency_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: import_batches; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.import_batches ENABLE ROW LEVEL SECURITY;

--
-- Name: ledger_entries; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.ledger_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: origin_towns; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.origin_towns ENABLE ROW LEVEL SECURITY;

--
-- Name: price_feed_events; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.price_feed_events ENABLE ROW LEVEL SECURITY;

--
-- Name: price_feed_settings; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.price_feed_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: price_snapshots; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.price_snapshots ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: role_permissions; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.role_permissions ENABLE ROW LEVEL SECURITY;

--
-- Name: roles; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.roles ENABLE ROW LEVEL SECURITY;

--
-- Name: sync_commands; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.sync_commands ENABLE ROW LEVEL SECURITY;

--
-- Name: attachments tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.attachments USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: audit_events tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.audit_events USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: branch_prices tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.branch_prices USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: branches tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.branches USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: business_days tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.business_days USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: collateral_holdings tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.collateral_holdings USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: customers tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.customers USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: day_balances tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.day_balances USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: day_reconciliations tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.day_reconciliations USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: debt_repayments tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.debt_repayments USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: debts tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.debts USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: device_keys tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.device_keys USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: discrepancies tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.discrepancies USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: discrepancy_actions tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.discrepancy_actions USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: document_counters tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.document_counters USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: drawer_movements tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.drawer_movements USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: formula_versions tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.formula_versions USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: guide_articles tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.guide_articles USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: guide_categories tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.guide_categories USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: guide_reads tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.guide_reads USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: guide_settings tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.guide_settings USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: idempotency_keys tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.idempotency_keys USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: import_batches tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.import_batches USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: ledger_entries tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.ledger_entries USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: notifications tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.notifications USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: origin_towns tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.origin_towns USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: price_feed_events tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.price_feed_events USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: price_feed_settings tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.price_feed_settings USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: price_snapshots tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.price_snapshots USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: refresh_tokens tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.refresh_tokens USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: role_permissions tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.role_permissions USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: roles tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.roles USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: sync_commands tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.sync_commands USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: tenant_settings tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.tenant_settings USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: transaction_items tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.transaction_items USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: transaction_payments tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.transaction_payments USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: transactions tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.transactions USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: transfer_events tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.transfer_events USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: transfer_goods_lines tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.transfer_goods_lines USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: transfer_payments tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.transfer_payments USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: transfers tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.transfers USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: user_branches tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.user_branches USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: user_permission_overrides tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.user_permission_overrides USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: users tenant_isolation; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_isolation ON gold.users USING ((tenant_id = gold.current_tenant())) WITH CHECK ((tenant_id = gold.current_tenant()));


--
-- Name: tenants tenant_login; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_login ON gold.tenants FOR SELECT USING ((slug OPERATOR(public.=) (NULLIF(current_setting('app.login_company'::text, true), ''::text))::public.citext));


--
-- Name: tenants tenant_self; Type: POLICY; Schema: gold; Owner: -
--

CREATE POLICY tenant_self ON gold.tenants USING ((id = gold.current_tenant()));


--
-- Name: tenant_settings; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.tenant_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: transaction_items; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.transaction_items ENABLE ROW LEVEL SECURITY;

--
-- Name: transaction_payments; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.transaction_payments ENABLE ROW LEVEL SECURITY;

--
-- Name: transactions; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: transfer_events; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.transfer_events ENABLE ROW LEVEL SECURITY;

--
-- Name: transfer_goods_lines; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.transfer_goods_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: transfer_payments; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.transfer_payments ENABLE ROW LEVEL SECURITY;

--
-- Name: transfers; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.transfers ENABLE ROW LEVEL SECURITY;

--
-- Name: user_branches; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.user_branches ENABLE ROW LEVEL SECURITY;

--
-- Name: user_permission_overrides; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.user_permission_overrides ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: gold; Owner: -
--

ALTER TABLE gold.users ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA gold; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA gold TO gold_app;


--
-- Name: FUNCTION apply_payment(p_tx uuid, p_branch uuid, p_day uuid, p_at timestamp with time zone, p_customer uuid, p_ref text, p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.apply_payment(p_tx uuid, p_branch uuid, p_day uuid, p_at timestamp with time zone, p_customer uuid, p_ref text, p jsonb) TO gold_app;


--
-- Name: FUNCTION approve_margin(p_branch uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.approve_margin(p_branch uuid) TO gold_app;


--
-- Name: FUNCTION audit(p_action text, p_entity_type text, p_entity_id text, p_before jsonb, p_after jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.audit(p_action text, p_entity_type text, p_entity_id text, p_before jsonb, p_after jsonb) TO gold_app;


--
-- Name: FUNCTION audit_search_json(p_scope uuid[], p_f jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.audit_search_json(p_scope uuid[], p_f jsonb) TO gold_app;


--
-- Name: FUNCTION branch_admin_json(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.branch_admin_json(p_id uuid) TO gold_app;


--
-- Name: FUNCTION branch_balance(p_branch uuid, p_upto_seq bigint); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.branch_balance(p_branch uuid, p_upto_seq bigint) TO gold_app;


--
-- Name: FUNCTION branch_overview_json(p_branch uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.branch_overview_json(p_branch uuid) TO gold_app;


--
-- Name: FUNCTION branch_timeline_json(p_branch uuid, p_from timestamp with time zone, p_to timestamp with time zone, p_asset text, p_before bigint, p_limit integer); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.branch_timeline_json(p_branch uuid, p_from timestamp with time zone, p_to timestamp with time zone, p_asset text, p_before bigint, p_limit integer) TO gold_app;


--
-- Name: FUNCTION branches_admin_json(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.branches_admin_json() TO gold_app;


--
-- Name: FUNCTION branches_cash_json(p_scope uuid[], p_branch uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.branches_cash_json(p_scope uuid[], p_branch uuid) TO gold_app;


--
-- Name: FUNCTION cancel_transfer(p_id uuid, p_reason text, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.cancel_transfer(p_id uuid, p_reason text, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION carry_branch_prices(p_snap uuid, p_actor uuid, p_keep_status boolean); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.carry_branch_prices(p_snap uuid, p_actor uuid, p_keep_status boolean) TO gold_app;


--
-- Name: FUNCTION change_my_password(p_hash text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.change_my_password(p_hash text) TO gold_app;


--
-- Name: FUNCTION check_payment_split(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.check_payment_split() TO gold_app;


--
-- Name: FUNCTION clean_permissions(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.clean_permissions(p jsonb) TO gold_app;


--
-- Name: FUNCTION close_day(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.close_day(p jsonb) TO gold_app;


--
-- Name: FUNCTION closing_preview(p_day uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.closing_preview(p_day uuid) TO gold_app;


--
-- Name: FUNCTION collateral_json(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.collateral_json(p_id uuid) TO gold_app;


--
-- Name: FUNCTION collateral_list_json(p_branch uuid, p_status text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.collateral_list_json(p_branch uuid, p_status text) TO gold_app;


--
-- Name: FUNCTION create_branch(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.create_branch(p jsonb) TO gold_app;


--
-- Name: FUNCTION create_customer(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.create_customer(p jsonb) TO gold_app;


--
-- Name: FUNCTION create_role(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.create_role(p jsonb) TO gold_app;


--
-- Name: FUNCTION create_town(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.create_town(p jsonb) TO gold_app;


--
-- Name: FUNCTION create_transfer(p jsonb, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.create_transfer(p jsonb, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION create_user(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.create_user(p jsonb) TO gold_app;


--
-- Name: FUNCTION current_actor(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.current_actor() TO gold_app;


--
-- Name: FUNCTION current_price(p_branch uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.current_price(p_branch uuid) TO gold_app;


--
-- Name: FUNCTION current_tenant(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.current_tenant() TO gold_app;


--
-- Name: FUNCTION customer_detail_json(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.customer_detail_json(p_id uuid) TO gold_app;


--
-- Name: TABLE customers; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.customers TO gold_app;


--
-- Name: FUNCTION customer_row_json(c gold.customers); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.customer_row_json(c gold.customers) TO gold_app;


--
-- Name: FUNCTION customers_json(p_q text, p_limit integer); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.customers_json(p_q text, p_limit integer) TO gold_app;


--
-- Name: FUNCTION customers_lookup_json(p_q text, p_branch uuid, p_limit integer); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.customers_lookup_json(p_q text, p_branch uuid, p_limit integer) TO gold_app;


--
-- Name: FUNCTION customers_page_json(p_q text, p_limit integer, p_offset integer); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.customers_page_json(p_q text, p_limit integer, p_offset integer) TO gold_app;


--
-- Name: FUNCTION customers_query_json(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.customers_query_json(p jsonb) TO gold_app;


--
-- Name: FUNCTION daily_account_json(p_branch uuid, p_date date); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.daily_account_json(p_branch uuid, p_date date) TO gold_app;


--
-- Name: FUNCTION daily_accounts_json(p_scope uuid[], p_branch uuid, p_date date); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.daily_accounts_json(p_scope uuid[], p_branch uuid, p_date date) TO gold_app;


--
-- Name: FUNCTION dash_base(p_ids uuid[], p_days integer, p_now timestamp with time zone); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.dash_base(p_ids uuid[], p_days integer, p_now timestamp with time zone) TO gold_app;


--
-- Name: FUNCTION dashboard_json(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.dashboard_json(p jsonb) TO gold_app;


--
-- Name: FUNCTION day_activity_json(p_day uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.day_activity_json(p_day uuid) TO gold_app;


--
-- Name: FUNCTION day_json(p_day uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.day_json(p_day uuid) TO gold_app;


--
-- Name: FUNCTION day_state(p_branch uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.day_state(p_branch uuid) TO gold_app;


--
-- Name: FUNCTION days_json(p_branch uuid, p_from date, p_to date, p_signoff text, p_limit integer); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.days_json(p_branch uuid, p_from date, p_to date, p_signoff text, p_limit integer) TO gold_app;


--
-- Name: FUNCTION debt_json(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.debt_json(p_id uuid) TO gold_app;


--
-- Name: FUNCTION debtors_at(p_branch uuid, p_t timestamp with time zone); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.debtors_at(p_branch uuid, p_t timestamp with time zone) TO gold_app;


--
-- Name: FUNCTION debts_json(p_branch uuid, p_direction text, p_open_only boolean, p_customer uuid, p_limit integer); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.debts_json(p_branch uuid, p_direction text, p_open_only boolean, p_customer uuid, p_limit integer) TO gold_app;


--
-- Name: FUNCTION declared(p jsonb, p_key text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.declared(p jsonb, p_key text) TO gold_app;


--
-- Name: FUNCTION delete_role(p_key text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.delete_role(p_key text) TO gold_app;


--
-- Name: FUNCTION device_key(p_user uuid, p_device text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.device_key(p_user uuid, p_device text) TO gold_app;


--
-- Name: FUNCTION discrepancies_json(p_scope uuid[], p_status text, p_branch uuid, p_limit integer); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.discrepancies_json(p_scope uuid[], p_status text, p_branch uuid, p_limit integer) TO gold_app;


--
-- Name: FUNCTION discrepancy_act(p_id uuid, p jsonb, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.discrepancy_act(p_id uuid, p jsonb, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION discrepancy_guard(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.discrepancy_guard() TO gold_app;


--
-- Name: FUNCTION discrepancy_json(p_id uuid, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.discrepancy_json(p_id uuid, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION has_text(value text, min_chars integer); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.has_text(value text, min_chars integer) TO gold_app;


--
-- Name: TABLE discrepancies; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.discrepancies TO gold_app;


--
-- Name: FUNCTION discrepancy_summary(d gold.discrepancies); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.discrepancy_summary(d gold.discrepancies) TO gold_app;


--
-- Name: FUNCTION effective_permissions(p_user uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.effective_permissions(p_user uuid) TO gold_app;


--
-- Name: FUNCTION ensure_customer(p_id uuid, p_name text, p_phone text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.ensure_customer(p_id uuid, p_name text, p_phone text) TO gold_app;


--
-- Name: FUNCTION ensure_customer(p_id uuid, p_name text, p_phone text, p_create boolean); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.ensure_customer(p_id uuid, p_name text, p_phone text, p_create boolean) TO gold_app;


--
-- Name: FUNCTION exchanges_json(p_branch uuid, p_limit integer); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.exchanges_json(p_branch uuid, p_limit integer) TO gold_app;


--
-- Name: FUNCTION expect_json(p_town uuid, p_customer uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.expect_json(p_town uuid, p_customer uuid) TO gold_app;


--
-- Name: FUNCTION fail(p_status integer, p_code text, p_message text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.fail(p_status integer, p_code text, p_message text) TO gold_app;


--
-- Name: FUNCTION feed_apply(p_base numeric, p_published timestamp with time zone, p_raw jsonb, p_actor uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.feed_apply(p_base numeric, p_published timestamp with time zone, p_raw jsonb, p_actor uuid) TO gold_app;


--
-- Name: FUNCTION feed_decide(p_event uuid, p_accept boolean); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.feed_decide(p_event uuid, p_accept boolean) TO gold_app;


--
-- Name: FUNCTION feed_missed_check(p_now timestamp with time zone); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.feed_missed_check(p_now timestamp with time zone) TO gold_app;


--
-- Name: FUNCTION feed_record(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.feed_record(p jsonb) TO gold_app;


--
-- Name: FUNCTION forbid_mutation(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.forbid_mutation() TO gold_app;


--
-- Name: FUNCTION guide_admin_json(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_admin_json() TO gold_app;


--
-- Name: FUNCTION guide_article_json(p_id uuid, p_include_draft boolean); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_article_json(p_id uuid, p_include_draft boolean) TO gold_app;


--
-- Name: TABLE guide_articles; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.guide_articles TO gold_app;


--
-- Name: FUNCTION guide_article_row(a gold.guide_articles, p_user uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_article_row(a gold.guide_articles, p_user uuid) TO gold_app;


--
-- Name: FUNCTION guide_check_blocks(b jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_check_blocks(b jsonb) TO gold_app;


--
-- Name: FUNCTION guide_delete_article(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_delete_article(p_id uuid) TO gold_app;


--
-- Name: FUNCTION guide_delete_category(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_delete_category(p_id uuid) TO gold_app;


--
-- Name: FUNCTION guide_json(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_json() TO gold_app;


--
-- Name: FUNCTION guide_mark_read(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_mark_read(p_id uuid) TO gold_app;


--
-- Name: FUNCTION guide_publish(p_id uuid, p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_publish(p_id uuid, p jsonb) TO gold_app;


--
-- Name: FUNCTION guide_readers_json(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_readers_json(p_id uuid) TO gold_app;


--
-- Name: FUNCTION guide_reminder_run(p_now timestamp with time zone); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_reminder_run(p_now timestamp with time zone) TO gold_app;


--
-- Name: FUNCTION guide_reminders_json(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_reminders_json() TO gold_app;


--
-- Name: FUNCTION guide_save_article(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_save_article(p jsonb) TO gold_app;


--
-- Name: FUNCTION guide_save_category(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_save_category(p jsonb) TO gold_app;


--
-- Name: FUNCTION guide_unpublish(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_unpublish(p_id uuid) TO gold_app;


--
-- Name: FUNCTION guide_unread_count(p_user uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.guide_unread_count(p_user uuid) TO gold_app;


--
-- Name: FUNCTION import_batches_json(p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.import_batches_json(p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION import_customers(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.import_customers(p jsonb) TO gold_app;


--
-- Name: FUNCTION import_history(p jsonb, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.import_history(p jsonb, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION import_opening(p jsonb, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.import_opening(p jsonb, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION import_undo(p_batch uuid, p_reason text, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.import_undo(p_batch uuid, p_reason text, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION in_scope(p_branch uuid, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.in_scope(p_branch uuid, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION interbranch_position_json(p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.interbranch_position_json(p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION iso(p timestamp with time zone); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.iso(p timestamp with time zone) TO gold_app;


--
-- Name: FUNCTION issue_loan(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.issue_loan(p jsonb) TO gold_app;


--
-- Name: FUNCTION item_booked_value(p_item uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.item_booked_value(p_item uuid) TO gold_app;


--
-- Name: FUNCTION karat_label(k numeric); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.karat_label(k numeric) TO gold_app;


--
-- Name: FUNCTION karat_stats_json(p_items uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.karat_stats_json(p_items uuid[]) TO gold_app;


--
-- Name: FUNCTION lines_json(p_source text, p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.lines_json(p_source text, p_id uuid) TO gold_app;


--
-- Name: FUNCTION lines_total(p_lines jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.lines_total(p_lines jsonb) TO gold_app;


--
-- Name: FUNCTION merge_customers(p_keep uuid, p_remove uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.merge_customers(p_keep uuid, p_remove uuid) TO gold_app;


--
-- Name: FUNCTION movement_json(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.movement_json(p_id uuid) TO gold_app;


--
-- Name: FUNCTION my_password_hash(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.my_password_hash() TO gold_app;


--
-- Name: FUNCTION my_security_json(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.my_security_json() TO gold_app;


--
-- Name: FUNCTION next_document_number(p_tenant uuid, p_kind text, p_branch uuid, p_date date); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.next_document_number(p_tenant uuid, p_kind text, p_branch uuid, p_date date) TO gold_app;


--
-- Name: FUNCTION notifications_json(p_limit integer, p_unread_only boolean); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.notifications_json(p_limit integer, p_unread_only boolean) TO gold_app;


--
-- Name: FUNCTION notifications_mark_read(p_ids uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.notifications_mark_read(p_ids uuid[]) TO gold_app;


--
-- Name: FUNCTION notify(p_tenant uuid, p_kind text, p_title text, p_body text, p_link text, p_branches uuid[], p_permission text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.notify(p_tenant uuid, p_kind text, p_title text, p_body text, p_link text, p_branches uuid[], p_permission text) TO gold_app;


--
-- Name: FUNCTION notify_user(p_tenant uuid, p_user uuid, p_kind text, p_title text, p_body text, p_link text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.notify_user(p_tenant uuid, p_user uuid, p_kind text, p_title text, p_body text, p_link text) TO gold_app;


--
-- Name: FUNCTION open_day(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.open_day(p jsonb) TO gold_app;


--
-- Name: FUNCTION open_day_id(p_branch uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.open_day_id(p_branch uuid) TO gold_app;


--
-- Name: FUNCTION other_holders(p_permission text, p_except uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.other_holders(p_permission text, p_except uuid) TO gold_app;


--
-- Name: FUNCTION pay_transaction(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.pay_transaction(p jsonb) TO gold_app;


--
-- Name: FUNCTION payment_guard(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.payment_guard() TO gold_app;


--
-- Name: FUNCTION payment_json(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.payment_json(p_id uuid) TO gold_app;


--
-- Name: FUNCTION pending_payments_json(p_branch uuid, p_role text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.pending_payments_json(p_branch uuid, p_role text) TO gold_app;


--
-- Name: FUNCTION person_json(p_user uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.person_json(p_user uuid) TO gold_app;


--
-- Name: FUNCTION post_cash(p_branch uuid, p_day uuid, p_at timestamp with time zone, p_lines jsonb, p_sign integer, p_source text, p_source_id uuid, p_memo text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.post_cash(p_branch uuid, p_day uuid, p_at timestamp with time zone, p_lines jsonb, p_sign integer, p_source text, p_source_id uuid, p_memo text) TO gold_app;


--
-- Name: FUNCTION post_custody(p_branch uuid, p_day uuid, p_at timestamp with time zone, p_top numeric, p_source text, p_source_id uuid, p_memo text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.post_custody(p_branch uuid, p_day uuid, p_at timestamp with time zone, p_top numeric, p_source text, p_source_id uuid, p_memo text) TO gold_app;


--
-- Name: FUNCTION post_goods(p_branch uuid, p_day uuid, p_at timestamp with time zone, p_top numeric, p_down numeric, p_value numeric, p_source text, p_source_id uuid, p_memo text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.post_goods(p_branch uuid, p_day uuid, p_at timestamp with time zone, p_top numeric, p_down numeric, p_value numeric, p_source text, p_source_id uuid, p_memo text) TO gold_app;


--
-- Name: FUNCTION post_transaction(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.post_transaction(p jsonb) TO gold_app;


--
-- Name: FUNCTION post_value(p_asset text, p_branch uuid, p_day uuid, p_at timestamp with time zone, p_delta numeric, p_source text, p_source_id uuid, p_memo text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.post_value(p_asset text, p_branch uuid, p_day uuid, p_at timestamp with time zone, p_delta numeric, p_source text, p_source_id uuid, p_memo text) TO gold_app;


--
-- Name: FUNCTION price_feed_json(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.price_feed_json() TO gold_app;


--
-- Name: FUNCTION price_feed_state(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.price_feed_state() TO gold_app;


--
-- Name: FUNCTION publish(p_tenant uuid, p_topic text, p_branches uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.publish(p_tenant uuid, p_topic text, p_branches uuid[]) TO gold_app;


--
-- Name: FUNCTION recall_transfer(p_id uuid, p_reason text, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.recall_transfer(p_id uuid, p_reason text, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION receive_transfer(p_id uuid, p jsonb, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.receive_transfer(p_id uuid, p jsonb, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION record_exchange(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.record_exchange(p jsonb) TO gold_app;


--
-- Name: FUNCTION record_movement(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.record_movement(p jsonb) TO gold_app;


--
-- Name: FUNCTION record_transfer_payment(p_id uuid, p jsonb, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.record_transfer_payment(p_id uuid, p jsonb, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION register_device_key(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.register_device_key(p jsonb) TO gold_app;


--
-- Name: FUNCTION release_transfer(p_id uuid, p jsonb, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.release_transfer(p_id uuid, p jsonb, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION repay_debt(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.repay_debt(p jsonb) TO gold_app;


--
-- Name: FUNCTION require_actor(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.require_actor() TO gold_app;


--
-- Name: FUNCTION reset_user_password(p_id uuid, p_hash text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.reset_user_password(p_id uuid, p_hash text) TO gold_app;


--
-- Name: FUNCTION resolve_payment(p_payment uuid, p_outcome text, p_scope uuid[], p_replacements jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.resolve_payment(p_payment uuid, p_outcome text, p_scope uuid[], p_replacements jsonb) TO gold_app;


--
-- Name: FUNCTION resolve_town(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.resolve_town(p jsonb) TO gold_app;


--
-- Name: FUNCTION return_collateral(p_id uuid, p_note text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.return_collateral(p_id uuid, p_note text) TO gold_app;


--
-- Name: FUNCTION revoke_refresh_family(p_hash bytea); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.revoke_refresh_family(p_hash bytea) TO gold_app;


--
-- Name: FUNCTION role_json(p_key text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.role_json(p_key text) TO gold_app;


--
-- Name: FUNCTION roles_json(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.roles_json() TO gold_app;


--
-- Name: FUNCTION rotate_refresh_token(p_old bytea, p_new bytea, p_expires timestamp with time zone, p_user_agent text, p_ip inet, p_grace interval); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.rotate_refresh_token(p_old bytea, p_new bytea, p_expires timestamp with time zone, p_user_agent text, p_ip inet, p_grace interval) TO gold_app;


--
-- Name: FUNCTION set_base_price(p_base numeric, p_published timestamp with time zone); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.set_base_price(p_base numeric, p_published timestamp with time zone) TO gold_app;


--
-- Name: FUNCTION set_guide_reminders(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.set_guide_reminders(p jsonb) TO gold_app;


--
-- Name: FUNCTION set_margin(p_branch uuid, p_margin numeric, p_approve boolean); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.set_margin(p_branch uuid, p_margin numeric, p_approve boolean) TO gold_app;


--
-- Name: FUNCTION set_price_feed_settings(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.set_price_feed_settings(p jsonb) TO gold_app;


--
-- Name: FUNCTION set_settings(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.set_settings(p jsonb) TO gold_app;


--
-- Name: FUNCTION setting(p_key text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.setting(p_key text) TO gold_app;


--
-- Name: FUNCTION setting_defaults(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.setting_defaults() TO gold_app;


--
-- Name: FUNCTION settings_json(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.settings_json() TO gold_app;


--
-- Name: FUNCTION signoff_day(p_day uuid, p_decision text, p_note text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.signoff_day(p_day uuid, p_decision text, p_note text) TO gold_app;


--
-- Name: FUNCTION staff_json(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.staff_json() TO gold_app;


--
-- Name: FUNCTION sync_apply(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.sync_apply(p jsonb) TO gold_app;


--
-- Name: FUNCTION sync_author(p_user uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.sync_author(p_user uuid) TO gold_app;


--
-- Name: FUNCTION sync_failure_kind(p_code text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.sync_failure_kind(p_code text) TO gold_app;


--
-- Name: FUNCTION sync_resolve(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.sync_resolve(p jsonb) TO gold_app;


--
-- Name: FUNCTION sync_review_json(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.sync_review_json() TO gold_app;


--
-- Name: FUNCTION sync_run(p_type text, p_payload jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.sync_run(p_type text, p_payload jsonb) TO gold_app;


--
-- Name: FUNCTION to_pay_json(p_branch uuid, p_search text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.to_pay_json(p_branch uuid, p_search text) TO gold_app;


--
-- Name: FUNCTION touch_updated_at(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.touch_updated_at() TO gold_app;


--
-- Name: FUNCTION town_key(p text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.town_key(p text) TO gold_app;


--
-- Name: FUNCTION towns_json(p_q text); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.towns_json(p_q text) TO gold_app;


--
-- Name: FUNCTION transaction_json(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transaction_json(p_id uuid) TO gold_app;


--
-- Name: FUNCTION transactions_export_json(p_branch uuid, p_from timestamp with time zone, p_to timestamp with time zone, p_limit integer); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transactions_export_json(p_branch uuid, p_from timestamp with time zone, p_to timestamp with time zone, p_limit integer) TO gold_app;


--
-- Name: FUNCTION transactions_json(p_branch uuid, p_limit integer); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transactions_json(p_branch uuid, p_limit integer) TO gold_app;


--
-- Name: FUNCTION transactions_search(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transactions_search(p jsonb) TO gold_app;


--
-- Name: FUNCTION transfer_add_item(p_transfer uuid, p_item uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transfer_add_item(p_transfer uuid, p_item uuid) TO gold_app;


--
-- Name: FUNCTION transfer_edit(p_id uuid, p jsonb, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transfer_edit(p_id uuid, p jsonb, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION transfer_event(p_transfer uuid, p_type text, p_data jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transfer_event(p_transfer uuid, p_type text, p_data jsonb) TO gold_app;


--
-- Name: TABLE transfers; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.transfers TO gold_app;


--
-- Name: FUNCTION transfer_for(p_id uuid, p_end text, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transfer_for(p_id uuid, p_end text, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION transfer_json(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transfer_json(p_id uuid) TO gold_app;


--
-- Name: FUNCTION transfer_note(p_id uuid, p_text text, p_scope uuid[]); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transfer_note(p_id uuid, p_text text, p_scope uuid[]) TO gold_app;


--
-- Name: FUNCTION transfer_set_collector_row(p_transfer uuid, c jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transfer_set_collector_row(p_transfer uuid, c jsonb) TO gold_app;


--
-- Name: FUNCTION transferable_items_json(p_branch uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transferable_items_json(p_branch uuid) TO gold_app;


--
-- Name: FUNCTION transfers_json(p_branch uuid, p_status text, p_direction text, p_limit integer); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.transfers_json(p_branch uuid, p_status text, p_direction text, p_limit integer) TO gold_app;


--
-- Name: FUNCTION trg_publish_day(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.trg_publish_day() TO gold_app;


--
-- Name: FUNCTION trg_publish_discrepancy(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.trg_publish_discrepancy() TO gold_app;


--
-- Name: FUNCTION trg_publish_payment(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.trg_publish_payment() TO gold_app;


--
-- Name: FUNCTION trg_publish_price(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.trg_publish_price() TO gold_app;


--
-- Name: FUNCTION trg_publish_quiet(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.trg_publish_quiet() TO gold_app;


--
-- Name: FUNCTION trg_publish_snapshot(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.trg_publish_snapshot() TO gold_app;


--
-- Name: FUNCTION trg_publish_transfers(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.trg_publish_transfers() TO gold_app;


--
-- Name: FUNCTION ts(p numeric); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.ts(p numeric) TO gold_app;


--
-- Name: FUNCTION update_branch(p_id uuid, p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.update_branch(p_id uuid, p jsonb) TO gold_app;


--
-- Name: FUNCTION update_customer(p_id uuid, p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.update_customer(p_id uuid, p jsonb) TO gold_app;


--
-- Name: FUNCTION update_role(p_key text, p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.update_role(p_key text, p jsonb) TO gold_app;


--
-- Name: FUNCTION update_user(p_id uuid, p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.update_user(p_id uuid, p jsonb) TO gold_app;


--
-- Name: FUNCTION user_admin_json(p_id uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.user_admin_json(p_id uuid) TO gold_app;


--
-- Name: FUNCTION user_branch_ids(p_user uuid); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.user_branch_ids(p_user uuid) TO gold_app;


--
-- Name: FUNCTION user_managers(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.user_managers() TO gold_app;


--
-- Name: FUNCTION users_admin_json(); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.users_admin_json() TO gold_app;


--
-- Name: FUNCTION valid_branch_ids(p jsonb); Type: ACL; Schema: gold; Owner: -
--

GRANT ALL ON FUNCTION gold.valid_branch_ids(p jsonb) TO gold_app;


--
-- Name: TABLE audit_events; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT ON TABLE gold.audit_events TO gold_app;


--
-- Name: TABLE branch_prices; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.branch_prices TO gold_app;


--
-- Name: TABLE business_days; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.business_days TO gold_app;


--
-- Name: TABLE collateral_holdings; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.collateral_holdings TO gold_app;


--
-- Name: TABLE debt_repayments; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT ON TABLE gold.debt_repayments TO gold_app;


--
-- Name: TABLE debts; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.debts TO gold_app;


--
-- Name: TABLE discrepancy_actions; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT ON TABLE gold.discrepancy_actions TO gold_app;


--
-- Name: TABLE drawer_movements; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT ON TABLE gold.drawer_movements TO gold_app;


--
-- Name: TABLE price_feed_events; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.price_feed_events TO gold_app;


--
-- Name: TABLE transaction_payments; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.transaction_payments TO gold_app;


--
-- Name: TABLE transactions; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.transactions TO gold_app;


--
-- Name: TABLE activity_feed; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.activity_feed TO gold_app;


--
-- Name: TABLE attachments; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT ON TABLE gold.attachments TO gold_app;


--
-- Name: SEQUENCE audit_events_id_seq; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,USAGE ON SEQUENCE gold.audit_events_id_seq TO gold_app;


--
-- Name: TABLE branches; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.branches TO gold_app;


--
-- Name: TABLE day_balances; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT ON TABLE gold.day_balances TO gold_app;


--
-- Name: TABLE day_reconciliations; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT ON TABLE gold.day_reconciliations TO gold_app;


--
-- Name: TABLE device_keys; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.device_keys TO gold_app;


--
-- Name: SEQUENCE discrepancy_actions_id_seq; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,USAGE ON SEQUENCE gold.discrepancy_actions_id_seq TO gold_app;


--
-- Name: TABLE document_counters; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.document_counters TO gold_app;


--
-- Name: TABLE formula_versions; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.formula_versions TO gold_app;


--
-- Name: TABLE guide_categories; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.guide_categories TO gold_app;


--
-- Name: TABLE guide_reads; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.guide_reads TO gold_app;


--
-- Name: TABLE guide_reminder_registry; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.guide_reminder_registry TO gold_app;


--
-- Name: TABLE guide_settings; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.guide_settings TO gold_app;


--
-- Name: TABLE idempotency_keys; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.idempotency_keys TO gold_app;


--
-- Name: TABLE import_batches; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.import_batches TO gold_app;


--
-- Name: TABLE ledger_entries; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT ON TABLE gold.ledger_entries TO gold_app;


--
-- Name: SEQUENCE ledger_entries_seq_seq; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,USAGE ON SEQUENCE gold.ledger_entries_seq_seq TO gold_app;


--
-- Name: TABLE notifications; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.notifications TO gold_app;


--
-- Name: TABLE origin_towns; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.origin_towns TO gold_app;


--
-- Name: TABLE price_feed_registry; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.price_feed_registry TO gold_app;


--
-- Name: TABLE price_feed_settings; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.price_feed_settings TO gold_app;


--
-- Name: TABLE price_snapshots; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.price_snapshots TO gold_app;


--
-- Name: TABLE refresh_tokens; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.refresh_tokens TO gold_app;


--
-- Name: TABLE role_permissions; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.role_permissions TO gold_app;


--
-- Name: TABLE roles; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.roles TO gold_app;


--
-- Name: TABLE schema_migrations; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.schema_migrations TO gold_app;


--
-- Name: TABLE sync_commands; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.sync_commands TO gold_app;


--
-- Name: TABLE tenant_settings; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.tenant_settings TO gold_app;


--
-- Name: TABLE tenants; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.tenants TO gold_app;


--
-- Name: TABLE transaction_items; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.transaction_items TO gold_app;


--
-- Name: TABLE transfer_events; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT ON TABLE gold.transfer_events TO gold_app;


--
-- Name: SEQUENCE transfer_events_id_seq; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,USAGE ON SEQUENCE gold.transfer_events_id_seq TO gold_app;


--
-- Name: TABLE transfer_goods_lines; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.transfer_goods_lines TO gold_app;


--
-- Name: TABLE transfer_payments; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT ON TABLE gold.transfer_payments TO gold_app;


--
-- Name: TABLE user_branches; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.user_branches TO gold_app;


--
-- Name: TABLE user_permission_overrides; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.user_permission_overrides TO gold_app;


--
-- Name: TABLE users; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.users TO gold_app;


--
-- Name: TABLE v_branch_timeline; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.v_branch_timeline TO gold_app;


--
-- Name: TABLE v_debts_outstanding; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.v_debts_outstanding TO gold_app;


--
-- Name: TABLE v_interbranch_position; Type: ACL; Schema: gold; Owner: -
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE gold.v_interbranch_position TO gold_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: gold; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE gold_migrator IN SCHEMA gold GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO gold_app;


--
-- PostgreSQL database dump complete
--

\unrestrict toQnRXmSx9vQRgV771LxnkYizUalTMGs8gMTAYVS6dfbM2FCwOP4O8xEFmssEAV

